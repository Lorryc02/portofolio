-- ============================================================
--  VMS — Voucher Management System
--  Script SQL PostgreSQL — Création des tables
--  Base : groupeffa_voucher
-- ============================================================

-- ── 1. TABLE USERS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    username    VARCHAR(100) PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL,
    prenom      VARCHAR(100) NOT NULL,
    email       VARCHAR(150) UNIQUE NOT NULL,
    userpassword VARCHAR(255) NOT NULL,
    userrole    VARCHAR(50)  NOT NULL
                CHECK (userrole IN ('SuperUser','Superviseur','Initiateur','Approbateur','Comptable')),
    titre       VARCHAR(100),
    ddl         DATE         DEFAULT CURRENT_DATE,
    statususer  VARCHAR(20)  DEFAULT 'Actif'
                CHECK (statususer IN ('Actif','Inactif'))
);

-- Utilisateur SuperUser par défaut
INSERT INTO users (username, nom, prenom, email, userpassword, userrole, titre, statususer)
VALUES ('admin@vms.com', 'Admin', 'Super', 'admin@vms.com', 'Admin@1234', 'SuperUser', 'Administrateur', 'Actif')
ON CONFLICT (username) DO NOTHING;


-- ── 2. TABLE CLIENT ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS client (
    refclient   SERIAL PRIMARY KEY,
    nomclient   VARCHAR(150) NOT NULL,
    email       VARCHAR(150) UNIQUE NOT NULL,
    adresse     VARCHAR(255),
    tel         INTEGER
);


-- ── 3. TABLE DEMANDE ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS demande (
    refdemande      VARCHAR(50)  PRIMARY KEY,
    datecreation    DATE         DEFAULT CURRENT_DATE,
    nbvouchers      INTEGER      NOT NULL CHECK (nbvouchers > 0),
    valeurvoucher   INTEGER      NOT NULL CHECK (valeurvoucher > 0),
    statusdemande   VARCHAR(30)  NOT NULL DEFAULT 'initié'
                    CHECK (statusdemande IN ('initié','approuvé','rejeté','annulé','payé')),
    "Initiateur"    VARCHAR(150),
    payeur          VARCHAR(150),
    approbateur     VARCHAR(150),
    refclient       VARCHAR(20)  NOT NULL
);


-- ── 4. TABLE VOUCHER ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS voucher (
    refvoucher      VARCHAR(50)  PRIMARY KEY,
    refdemande      VARCHAR(50)  REFERENCES demande(refdemande) ON DELETE CASCADE,
    valeur          INTEGER      NOT NULL CHECK (valeur > 0),
    datecreation    DATE         DEFAULT CURRENT_DATE,
    dateexpiration  DATE,
    statut          VARCHAR(20)  NOT NULL DEFAULT 'Actif'
                    CHECK (statut IN ('Actif','Expiré','Payé')),
    refclient       VARCHAR(20)
);

-- Index pour performance
CREATE INDEX IF NOT EXISTS idx_demande_statut   ON demande(statusdemande);
CREATE INDEX IF NOT EXISTS idx_voucher_statut   ON voucher(statut);
CREATE INDEX IF NOT EXISTS idx_voucher_demande  ON voucher(refdemande);
CREATE INDEX IF NOT EXISTS idx_client_email     ON client(email);

-- ============================================================
-- FIN DU SCRIPT
-- ============================================================
