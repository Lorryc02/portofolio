# VMS — Voucher Management System
## Guide d'intégration du projet

---

## Structure du projet Maven (IntelliJ)

```
src/
└── main/
    ├── java/
    │   └── org/example/
    │       ├── Main.java
    │       ├── controllers/
    │       │   ├── LoginController.java
    │       │   ├── DashboardController.java
    │       │   ├── OverviewController.java
    │       │   ├── InitierController.java
    │       │   ├── ValiderController.java
    │       │   ├── PaiementController.java
    │       │   ├── ModifierVoucherController.java
    │       │   ├── MessagesController.java
    │       │   ├── AjoutClientController.java
    │       │   ├── AjoutUserController.java
    │       │   ├── ModifierSupprimerClientsController.java
    │       │   └── ModifierSupprimerUserController.java
    │       ├── models/
    │       │   ├── User.java
    │       │   ├── Client.java
    │       │   ├── Demandes.java
    │       │   ├── Voucher.java
    │       │   ├── DatabaseConnection.java
    │       │   ├── UserDAO.java
    │       │   ├── ClientDAO.java
    │       │   ├── DemandeDAO.java
    │       │   ├── VoucherDAO.java
    │       │   └── UserSession.java
    │       ├── service/
    │       │   └── AuthService.java
    │       └── utils/
    │           └── Session.java
    └── resources/
        ├── views/
        │   ├── Login.fxml
        │   ├── Dashboard.fxml
        │   ├── overview.fxml
        │   ├── Initier.fxml
        │   ├── Valider.fxml
        │   ├── voucher_paiement.fxml
        │   ├── voucher_modifier.fxml
        │   ├── messages.fxml
        │   ├── AjoutClient.fxml
        │   ├── AjoutUser.fxml
        │   ├── modifierSupprimerClients.fxml
        │   └── modifierSupprimerUser.fxml
        └── styles/
            ├── login.css
            └── dashboard.css
```

---

## Rôles et accès

| Rôle         | Initier | Valider | Paiement | Modifier Voucher | Users | Clients |
|--------------|:-------:|:-------:|:--------:|:----------------:|:-----:|:-------:|
| SuperUser    | ✅      | ✅      | ✅       | ✅               | ✅    | ✅      |
| Superviseur  | ❌      | ❌      | ❌       | ✅               | ❌    | ✅      |
| Initiateur   | ✅      | ❌      | ❌       | ❌               | ❌    | ❌      |
| Approbateur  | ❌      | ✅      | ❌       | ❌               | ❌    | ❌      |
| Comptable    | ❌      | ❌      | ✅       | ❌               | ❌    | ❌      |

---

## Flux d'une demande de voucher

```
Initiateur → [initié]
     ↓
Approbateur → [approuvé] ou [rejeté]
     ↓
Comptable   → [payé]
```

---

## Base de données PostgreSQL

- **Host :** postgresql-groupeffa.alwaysdata.net:5432  
- **Base :** groupeffa_voucher  
- **User :** groupeffa  

Exécutez `schema_vms.sql` pour créer les tables.

### Compte SuperUser par défaut
- **Email :** admin@vms.com  
- **Mot de passe :** Admin@1234  

---

## Dépendances Maven à avoir dans pom.xml

```xml
<dependencies>
    <!-- JavaFX -->
    <dependency>
        <groupId>org.openjfx</groupId>
        <artifactId>javafx-controls</artifactId>
        <version>21</version>
    </dependency>
    <dependency>
        <groupId>org.openjfx</groupId>
        <artifactId>javafx-fxml</artifactId>
        <version>21</version>
    </dependency>

    <!-- PostgreSQL JDBC -->
    <dependency>
        <groupId>org.postgresql</groupId>
        <artifactId>postgresql</artifactId>
        <version>42.7.3</version>
    </dependency>
</dependencies>
```

---

## À faire pour compléter le projet

- [ ] Hachage des mots de passe (BCrypt recommandé)
- [ ] Génération automatique des vouchers depuis une demande payée
- [ ] Impression / export PDF des vouchers
- [ ] Persistance des messages en base de données
- [ ] Recherche dans les tables (barre de filtre)
- [ ] Pagination des tableaux
