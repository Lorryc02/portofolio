package org.example.models;

public class User {
    private String email;
    private String userpassword;
    private String userrole;
    private String nom;
    private String prenom;
    private String username;
    private String ddl;
    private String statususer;
    private String titre;

    public User() {}

    public User(String email, String userpassword, String userrole,
                String nom, String prenom, String username,
                String ddl, String statususer, String titre) {
        this.email       = email;
        this.userpassword = userpassword;
        this.userrole    = userrole;
        this.nom         = nom;
        this.prenom      = prenom;
        this.username    = username;
        this.ddl         = ddl;
        this.statususer  = statususer;
        this.titre       = titre;
    }

    public String getEmail()        { return email; }
    public void   setEmail(String v){ this.email = v; }

    public String getUserpassword()        { return userpassword; }
    public void   setUserpassword(String v){ this.userpassword = v; }

    public String getUserrole()        { return userrole; }
    public void   setUserrole(String v){ this.userrole = v; }

    public String getNom()        { return nom; }
    public void   setNom(String v){ this.nom = v; }

    public String getPrenom()        { return prenom; }
    public void   setPrenom(String v){ this.prenom = v; }

    public String getUsername()        { return username; }
    public void   setUsername(String v){ this.username = v; }

    public String getDdl()        { return ddl; }
    public void   setDdl(String v){ this.ddl = v; }

    public String getStatususer()        { return statususer; }
    public void   setStatususer(String v){ this.statususer = v; }

    public String getTitre()        { return titre; }
    public void   setTitre(String v){ this.titre = v; }

    @Override
    public String toString() {
        return prenom + " " + nom + " (" + userrole + ")";
    }
}
