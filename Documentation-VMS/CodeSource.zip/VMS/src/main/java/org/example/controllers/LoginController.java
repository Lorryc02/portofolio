package org.example.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.models.DatabaseConnection;
import org.example.models.User;
import org.example.models.UserSession;
import org.example.utils.Session;

import java.io.IOException;
import java.sql.*;

public class LoginController {

    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;

    @FXML
    private void handleLogin() {
        String email    = emailField.getText().trim();
        String password = passwordField.getText().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert("Veuillez remplir tous les champs.");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM users WHERE email = ? AND userpassword = ? AND statususer = 'Actif'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                User user = new User(
                        rs.getString("email"),
                        rs.getString("userpassword"),
                        rs.getString("userrole"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("username"),
                        rs.getString("ddl"),
                        rs.getString("statususer"),
                        rs.getString("titre")
                );
                // Stocker dans les deux sessions (compatibilité)
                Session.setUser(user);
                UserSession.getInstance().setCurrentUser(user);

                gotoDashboard();
            } else {
                showAlert("Email, mot de passe incorrect ou compte inactif.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur de connexion à la base de données : " + e.getMessage());
        }
    }

    private void gotoDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/Dashboard.fxml"));
            Scene scene = new Scene(loader.load(), 1400, 800);

            String css = getClass().getResource("/styles/dashboard.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("VMS • Tableau de bord — " + Session.getUser().getPrenom() + " " + Session.getUser().getNom());
            stage.setMaximized(true);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur lors du chargement du tableau de bord.");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Connexion");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
