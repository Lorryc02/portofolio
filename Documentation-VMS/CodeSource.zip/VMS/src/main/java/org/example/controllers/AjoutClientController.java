package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import org.example.models.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AjoutClientController {

    @FXML private TextField txtNom;
    @FXML private TextField txtEmail;
    @FXML private TextField txtAdresse;
    @FXML private TextField txtTelephone;

    @FXML
    private void saveClient() {
        String nom       = txtNom.getText().trim();
        String email     = txtEmail.getText().trim();
        String adresse   = txtAdresse.getText().trim();
        String telephone = txtTelephone.getText().trim();

        if (nom.isEmpty() || email.isEmpty() || adresse.isEmpty() || telephone.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champs requis", "Veuillez remplir tous les champs.");
            return;
        }

        if (!email.contains("@")) {
            showAlert(Alert.AlertType.ERROR, "Email invalide", "Veuillez saisir une adresse email valide.");
            return;
        }

        int tel;
        try {
            tel = Integer.parseInt(telephone);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Téléphone invalide", "Le numéro de téléphone doit être numérique.");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Vérifier si email client existe déjà
            PreparedStatement check = conn.prepareStatement("SELECT COUNT(*) FROM client WHERE email = ?");
            check.setString(1, email);
            ResultSet rs = check.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                showAlert(Alert.AlertType.ERROR, "Doublon", "Un client avec cet email existe déjà.");
                return;
            }

            String sql = "INSERT INTO client (nomclient, email, adresse, tel) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nom);
            stmt.setString(2, email);
            stmt.setString(3, adresse);
            stmt.setInt(4, tel);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "Client « " + nom + " » ajouté avec succès !");
                clearFields();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur base de données", "Impossible d'ajouter le client.\n" + e.getMessage());
        }
    }

    @FXML
    private void cancelAction() {
        clearFields();
    }

    private void clearFields() {
        txtNom.clear();
        txtEmail.clear();
        txtAdresse.clear();
        txtTelephone.clear();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
