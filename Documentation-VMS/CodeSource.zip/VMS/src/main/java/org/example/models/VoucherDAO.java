package org.example.models;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VoucherDAO {

    // Colonnes réelles confirmées depuis phpPgAdmin :
    // refvoucher, valeurvoucher, dateemission, dateexpiration,
    // statusvoucher, redeemedBy, refmagasin, refclient, redeemedOn, refdemande

    public List<Voucher> getAllVouchers() {
        List<Voucher> list = new ArrayList<>();
        String sql = "SELECT refvoucher, refdemande, valeurvoucher, " +
                     "dateemission, dateexpiration, statusvoucher, refclient " +
                     "FROM voucher ORDER BY dateemission DESC NULLS LAST";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
            System.out.println("✅ getAllVouchers: " + list.size() + " voucher(s)");
        } catch (SQLException e) {
            System.err.println("❌ Erreur getAllVouchers: " + e.getMessage());
            e.printStackTrace();
        }
        return list;
    }

    public List<Voucher> getVouchersByStatut(String statut) {
        List<Voucher> list = new ArrayList<>();
        String sql = "SELECT refvoucher, refdemande, valeurvoucher, " +
                     "dateemission, dateexpiration, statusvoucher, refclient " +
                     "FROM voucher WHERE statusvoucher = ? " +
                     "ORDER BY dateemission DESC NULLS LAST";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, statut);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("❌ Erreur getVouchersByStatut: " + e.getMessage());
        }
        return list;
    }

    public boolean updateStatut(String refVoucher, String statut) {
        String sql = "UPDATE voucher SET statusvoucher = ? WHERE refvoucher = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, statut);
            ps.setString(2, refVoucher);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Erreur updateStatut: " + e.getMessage());
            return false;
        }
    }

    public boolean updateVoucher(String refVoucher, int valeur, LocalDate dateExpiration) {
        String sql = "UPDATE voucher SET valeurvoucher = ?, dateexpiration = ? " +
                     "WHERE refvoucher = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, valeur);
            ps.setDate(2, Date.valueOf(dateExpiration));
            ps.setString(3, refVoucher);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Erreur updateVoucher: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteVoucher(String refVoucher) {
        String sql = "DELETE FROM voucher WHERE refvoucher = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, refVoucher);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Erreur deleteVoucher: " + e.getMessage());
            return false;
        }
    }

    public int marquerExpires() {
        String sql = "UPDATE voucher SET statusvoucher = 'Expiré' " +
                     "WHERE dateexpiration < CURRENT_DATE " +
                     "AND statusvoucher = 'Actif'";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            return stmt.executeUpdate(sql);
        } catch (SQLException e) {
            System.err.println("❌ Erreur marquerExpires: " + e.getMessage());
            return 0;
        }
    }

    public int countByStatut(String statut) {
        String sql = "SELECT COUNT(*) FROM voucher WHERE statusvoucher = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, statut);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("❌ Erreur countByStatut: " + e.getMessage());
        }
        return 0;
    }

    public int countAll() {
        String sql = "SELECT COUNT(*) FROM voucher";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("❌ Erreur countAll: " + e.getMessage());
        }
        return 0;
    }

    private Voucher map(ResultSet rs) throws SQLException {
        Date dateExp = rs.getDate("dateexpiration");
        Date dateCre = rs.getDate("dateemission");

        // refclient peut être null
        String refClient = rs.getString("refclient");
        if (refClient == null) refClient = "";

        String refDemande = rs.getString("refdemande");
        if (refDemande == null) refDemande = "";

        String statut = rs.getString("statusvoucher");
        if (statut == null) statut = "Actif";

        return new Voucher(
                rs.getString("refvoucher"),
                refDemande,
                rs.getInt("valeurvoucher"),
                dateCre != null ? dateCre.toLocalDate() : null,
                dateExp != null ? dateExp.toLocalDate() : null,
                statut,
                refClient
        );
    }
}
