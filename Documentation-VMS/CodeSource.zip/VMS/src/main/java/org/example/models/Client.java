package org.example.models;

import javafx.beans.property.*;

public class Client {
    private final IntegerProperty refClient;
    private final StringProperty  nomClient;
    private final StringProperty  email;
    private final StringProperty  adresse;
    private final IntegerProperty tel;

    public Client(int refClient, String nomClient, String email, String adresse, int tel) {
        this.refClient = new SimpleIntegerProperty(refClient);
        this.nomClient = new SimpleStringProperty(nomClient);
        this.email     = new SimpleStringProperty(email);
        this.adresse   = new SimpleStringProperty(adresse);
        this.tel       = new SimpleIntegerProperty(tel);
    }

    public int    getRefClient()             { return refClient.get(); }
    public IntegerProperty refClientProperty(){ return refClient; }

    public String getNomClient()             { return nomClient.get(); }
    public StringProperty nomClientProperty(){ return nomClient; }

    public String getEmail()             { return email.get(); }
    public StringProperty emailProperty(){ return email; }

    public String getAdresse()             { return adresse.get(); }
    public StringProperty adresseProperty(){ return adresse; }

    public int    getTel()             { return tel.get(); }
    public IntegerProperty telProperty(){ return tel; }

    @Override
    public String toString() { return nomClient.get() + " — " + tel.get(); }
}
