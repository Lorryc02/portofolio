package org.example.controllers;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.DirectoryChooser;
import org.example.models.DatabaseConnection;
import org.example.models.Voucher;
import org.example.models.VoucherDAO;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class ExportVoucherController {

    // Table
    @FXML private TableView<VoucherRow>            tableVouchers;
    @FXML private TableColumn<VoucherRow, Boolean> colCheck;
    @FXML private TableColumn<VoucherRow, String>  colRefVoucher;
    @FXML private TableColumn<VoucherRow, String>  colNomClient;
    @FXML private TableColumn<VoucherRow, Integer> colValeur;
    @FXML private TableColumn<VoucherRow, LocalDate> colDateExpiration;
    @FXML private TableColumn<VoucherRow, String>  colStatut;

    // Filtres
    @FXML private TextField  filtreClient;
    @FXML private DatePicker filtreDate;
    @FXML private ComboBox<String> filtreStatut;
    @FXML private Label      compteurLabel;

    // Sélection
    @FXML private CheckBox checkTout;
    @FXML private Label    selectionLabel;

    // Aperçu
    @FXML private ImageView qrPreview;
    @FXML private Label refVoucherLabel;
    @FXML private Label valeurLabel;
    @FXML private Label expirationLabel;
    @FXML private Label statutLabel;
    @FXML private Label nomClientLabel;

    private final VoucherDAO voucherDAO = new VoucherDAO();
    private ObservableList<VoucherRow> allRows = FXCollections.observableArrayList();
    private FilteredList<VoucherRow>   filteredRows;
    private Voucher selectedVoucher;

    // ── Classe interne : Voucher + case à cocher + nom client ──
    public static class VoucherRow {
        private final Voucher voucher;
        private final SimpleBooleanProperty selected = new SimpleBooleanProperty(false);
        private final String nomClient;

        public VoucherRow(Voucher v, String nomClient) {
            this.voucher    = v;
            this.nomClient  = nomClient;
        }
        public Voucher getVoucher()           { return voucher; }
        public String  getNomClient()         { return nomClient; }
        public boolean isSelected()           { return selected.get(); }
        public SimpleBooleanProperty selectedProperty() { return selected; }
    }

    @FXML
    public void initialize() {
        // Colonne checkbox
        colCheck.setCellValueFactory(row -> row.getValue().selectedProperty());
        colCheck.setCellFactory(CheckBoxTableCell.forTableColumn(colCheck));
        colCheck.setEditable(true);
        tableVouchers.setEditable(true);

        colRefVoucher.setCellValueFactory(r ->
                new javafx.beans.property.SimpleStringProperty(r.getValue().getVoucher().getRefVoucher()));
        colNomClient.setCellValueFactory(r ->
                new javafx.beans.property.SimpleStringProperty(r.getValue().getNomClient()));
        colValeur.setCellValueFactory(r ->
                new javafx.beans.property.SimpleObjectProperty<>(r.getValue().getVoucher().getValeur()));
        colDateExpiration.setCellValueFactory(r ->
                new javafx.beans.property.SimpleObjectProperty<>(r.getValue().getVoucher().getDateExpiration()));
        colStatut.setCellValueFactory(r ->
                new javafx.beans.property.SimpleStringProperty(r.getValue().getVoucher().getStatut()));

        // Colorer lignes selon statut
        tableVouchers.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(VoucherRow item, boolean empty) {
                super.updateItem(item, empty);
                if (item == null || empty) { setStyle(""); return; }
                switch (item.getVoucher().getStatut() != null ? item.getVoucher().getStatut() : "") {
                    case "Actif"  -> setStyle("-fx-background-color: #dcfce7;");
                    case "Expiré" -> setStyle("-fx-background-color: #fee2e2;");
                    case "Payé"   -> setStyle("-fx-background-color: #dbeafe;");
                    default       -> setStyle("");
                }
            }
        });

        // Aperçu au clic
        tableVouchers.getSelectionModel().selectedItemProperty().addListener((obs, old, sel) -> {
            if (sel != null) {
                selectedVoucher = sel.getVoucher();
                updatePreview(sel.getVoucher(), sel.getNomClient());
            }
        });

        // Mettre à jour le compteur de sélection à chaque changement de checkbox
        // (on écoute via les propriétés — on rafraîchit le label à chaque clic)
        tableVouchers.setOnMouseClicked(e -> updateSelectionLabel());

        // ComboBox statut
        filtreStatut.getItems().addAll("Tous", "Actif", "Expiré", "Payé");
        filtreStatut.setValue("Tous");

        // Chargement en arrière-plan pour ne pas bloquer l'UI
        compteurLabel.setText("Chargement...");
        new Thread(() -> {
            Map<String, String> clientCache = loadAllClients();
            List<Voucher> vouchers = voucherDAO.getAllVouchers();
            javafx.application.Platform.runLater(() -> {
                allRows.clear();
                for (Voucher v : vouchers) {
                    String nom = clientCache.getOrDefault(v.getRefClient(), "Client #" + v.getRefClient());
                    VoucherRow row = new VoucherRow(v, nom);
                    row.selectedProperty().addListener((obs, o, n) -> updateSelectionLabel());
                    allRows.add(row);
                }
                filteredRows = new FilteredList<>(allRows, r -> true);
                tableVouchers.setItems(filteredRows);
                compteurLabel.setText(filteredRows.size() + " résultat(s)");
                updateSelectionLabel();
            });
        }, "VoucherLoader").start();
    }

    // ── Chargement ────────────────────────────────────────────

    /** Charge tous les clients en une seule requête → Map<refclient, nomclient> */
    private Map<String, String> loadAllClients() {
        Map<String, String> map = new HashMap<>();
        String sql = "SELECT refclient, nomclient FROM client";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                map.put(String.valueOf(rs.getInt("refclient")), rs.getString("nomclient"));
            }
        } catch (SQLException e) {
            System.err.println("Erreur loadAllClients: " + e.getMessage());
        }
        return map;
    }

    // ── Filtres ───────────────────────────────────────────────

    @FXML
    private void appliquerFiltres() {
        String texteClient = filtreClient.getText().trim().toLowerCase();
        LocalDate date     = filtreDate.getValue();
        String statut      = filtreStatut.getValue();

        filteredRows.setPredicate(row -> {
            Voucher v = row.getVoucher();

            // Filtre client : par nom ou par refclient
            boolean matchClient = texteClient.isEmpty()
                    || row.getNomClient().toLowerCase().contains(texteClient)
                    || v.getRefClient().toLowerCase().contains(texteClient);

            // Filtre date expiration exacte
            boolean matchDate = (date == null)
                    || (v.getDateExpiration() != null && v.getDateExpiration().equals(date));

            // Filtre statut
            boolean matchStatut = (statut == null || "Tous".equals(statut))
                    || statut.equals(v.getStatut());

            return matchClient && matchDate && matchStatut;
        });

        compteurLabel.setText(filteredRows.size() + " résultat(s)");
        checkTout.setSelected(false);
        updateSelectionLabel();
    }

    @FXML
    private void reinitialiserFiltres() {
        filtreClient.clear();
        filtreDate.setValue(null);
        filtreStatut.setValue("Tous");
        filteredRows.setPredicate(r -> true);
        compteurLabel.setText(filteredRows.size() + " résultat(s)");
        // Décocher tout
        allRows.forEach(r -> r.selectedProperty().set(false));
        checkTout.setSelected(false);
        updateSelectionLabel();
    }

    @FXML
    private void toggleTout() {
        boolean cocher = checkTout.isSelected();
        // Cocher/décocher uniquement les lignes visibles (filtrées)
        filteredRows.forEach(r -> r.selectedProperty().set(cocher));
        updateSelectionLabel();
    }

    private void updateSelectionLabel() {
        long nb = allRows.stream().filter(VoucherRow::isSelected).count();
        selectionLabel.setText(nb + " sélectionné(s)");
    }

    // ── Export ────────────────────────────────────────────────

    @FXML
    private void exporterVoucher() {
        if (selectedVoucher == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise",
                    "Cliquez sur une ligne du tableau pour sélectionner un voucher.");
            return;
        }
        File dir = choisirDossier();
        if (dir == null) return;
        exporter(List.of(selectedVoucher), dir);
    }

    @FXML
    private void exporterSelection() {
        List<Voucher> selection = allRows.stream()
                .filter(VoucherRow::isSelected)
                .map(VoucherRow::getVoucher)
                .collect(Collectors.toList());

        if (selection.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection",
                    "Cochez les cases des vouchers que vous voulez exporter.");
            return;
        }
        File dir = choisirDossier();
        if (dir == null) return;
        exporter(selection, dir);
    }

    @FXML
    private void exporterFiltres() {
        List<Voucher> visibles = filteredRows.stream()
                .map(VoucherRow::getVoucher)
                .collect(Collectors.toList());

        if (visibles.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Aucun résultat",
                    "Aucun voucher ne correspond aux filtres appliqués.");
            return;
        }

        boolean confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Exporter " + visibles.size() + " voucher(s) filtrés ?",
                ButtonType.YES, ButtonType.NO)
                .showAndWait().orElse(ButtonType.NO) == ButtonType.YES;
        if (!confirm) return;

        File dir = choisirDossier();
        if (dir == null) return;
        exporter(visibles, dir);
    }

    @FXML
    private void rafraichir() {
        compteurLabel.setText("Chargement...");
        new Thread(() -> {
            Map<String, String> clientCache = loadAllClients();
            List<Voucher> vouchers = voucherDAO.getAllVouchers();
            javafx.application.Platform.runLater(() -> {
                allRows.clear();
                for (Voucher v : vouchers) {
                    String nom = clientCache.getOrDefault(v.getRefClient(), "Client #" + v.getRefClient());
                    VoucherRow row = new VoucherRow(v, nom);
                    row.selectedProperty().addListener((obs, o, n) -> updateSelectionLabel());
                    allRows.add(row);
                }
                filteredRows = new FilteredList<>(allRows, r -> true);
                tableVouchers.setItems(filteredRows);
                appliquerFiltres();
            });
        }, "VoucherRefresh").start();
    }

    private File choisirDossier() {
        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setTitle("Choisir le dossier de sauvegarde");
        return chooser.showDialog(tableVouchers.getScene().getWindow());
    }

    private void exporter(List<Voucher> vouchers, File dir) {
        int count = 0, errors = 0;
        for (Voucher v : vouchers) {
            try {
                String nom = getNomClient(v.getRefClient());
                BufferedImage img = generateVoucherImage(v, nom);
                String filename = "voucher_" + v.getRefVoucher().replace("-", "_") + ".png";
                ImageIO.write(img, "PNG", new File(dir, filename));
                count++;
            } catch (Exception e) {
                errors++;
                System.err.println("Erreur export " + v.getRefVoucher() + ": " + e.getMessage());
            }
        }
        String msg = count + " voucher(s) exporté(s) dans :\n" + dir.getAbsolutePath();
        if (errors > 0) msg += "\n⚠️ " + errors + " erreur(s)";
        showAlert(Alert.AlertType.INFORMATION, "Export terminé", msg);
    }

    // ── Aperçu ────────────────────────────────────────────────

    private void updatePreview(Voucher v, String nomClient) {
        refVoucherLabel.setText(v.getRefVoucher());
        valeurLabel.setText("Rs " + v.getValeur());
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        expirationLabel.setText(v.getDateExpiration() != null ? v.getDateExpiration().format(fmt) : "—");
        statutLabel.setText(v.getStatut() != null ? v.getStatut() : "—");
        nomClientLabel.setText(nomClient);

        // Couleur statut
        switch (v.getStatut() != null ? v.getStatut() : "") {
            case "Actif"  -> statutLabel.setStyle("-fx-font-size:13px;-fx-font-weight:700;-fx-text-fill:#059669;");
            case "Expiré" -> statutLabel.setStyle("-fx-font-size:13px;-fx-font-weight:700;-fx-text-fill:#dc2626;");
            case "Payé"   -> statutLabel.setStyle("-fx-font-size:13px;-fx-font-weight:700;-fx-text-fill:#2563eb;");
            default       -> statutLabel.setStyle("-fx-font-size:13px;-fx-font-weight:700;-fx-text-fill:#64748b;");
        }

        try {
            BufferedImage qrImg = generateQRCode(v.getRefVoucher(), 180);
            File tmp = File.createTempFile("qr_", ".png");
            tmp.deleteOnExit();
            ImageIO.write(qrImg, "PNG", tmp);
            qrPreview.setImage(new Image(tmp.toURI().toString()));
        } catch (IOException e) {
            System.err.println("Erreur aperçu QR: " + e.getMessage());
        }
    }

    // ── Génération image voucher ──────────────────────────────

    private BufferedImage generateVoucherImage(Voucher v, String nomClient) {
        int W = 620, H = 320;
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,      RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Fond blanc
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, W, H);

        // Bande gauche
        g.setColor(new Color(30, 58, 95));
        g.fillRect(0, 0, 10, H);

        // Header
        g.setColor(new Color(30, 58, 95));
        g.fillRect(10, 0, W - 10, 58);
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 20));
        g.drawString("VMS  —  Voucher Management System", 24, 36);
        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.setColor(new Color(180, 210, 255));
        g.drawString("Bon de valeur officiel", 24, 52);

        // Badge statut
        Color sc = switch (v.getStatut() != null ? v.getStatut() : "") {
            case "Actif"  -> new Color(5, 150, 105);
            case "Expiré" -> new Color(220, 38, 38);
            case "Payé"   -> new Color(37, 99, 235);
            default       -> new Color(100, 116, 139);
        };
        g.setColor(sc);
        g.fillRoundRect(W - 105, 14, 90, 26, 13, 13);
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 11));
        String st = v.getStatut() != null ? v.getStatut() : "—";
        g.drawString(st, W - 105 + (90 - g.getFontMetrics().stringWidth(st)) / 2, 32);

        // Infos
        int x = 24, y = 80;
        drawField(g, "RÉFÉRENCE",  v.getRefVoucher(), x, y);
        drawBigValue(g, "Rs " + v.getValeur(), x, y + 55);
        drawField(g, "CLIENT",     nomClient, x, y + 110);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        drawField(g, "EXPIRE LE",
                v.getDateExpiration() != null ? v.getDateExpiration().format(fmt) : "—", x, y + 155);

        // Séparateur
        g.setColor(new Color(220, 230, 240));
        float[] dash = {6f, 4f};
        g.setStroke(new BasicStroke(1.2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10f, dash, 0f));
        g.drawLine(370, 68, 370, H - 16);
        g.setStroke(new BasicStroke(1f));

        // QR
        BufferedImage qr = generateQRCode(v.getRefVoucher(), 210);
        g.setColor(new Color(248, 250, 252));
        g.fillRoundRect(378, 66, 220, 220, 10, 10);
        g.drawImage(qr, 383, 71, 210, 210, null);
        g.setColor(new Color(148, 163, 184));
        g.setFont(new Font("SansSerif", Font.PLAIN, 9));
        g.drawString("Scanner pour vérifier", 409, H - 8);

        // Bordure
        g.setColor(new Color(220, 230, 240));
        g.setStroke(new BasicStroke(1.2f));
        g.drawRect(0, 0, W - 1, H - 1);

        g.dispose();
        return img;
    }

    private void drawField(Graphics2D g, String label, String value, int x, int y) {
        g.setFont(new Font("SansSerif", Font.PLAIN, 10));
        g.setColor(new Color(148, 163, 184));
        g.drawString(label, x, y);
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        g.setColor(new Color(15, 23, 42));
        g.drawString(value != null ? value : "—", x, y + 16);
    }

    private void drawBigValue(Graphics2D g, String value, int x, int y) {
        g.setFont(new Font("SansSerif", Font.BOLD, 34));
        g.setColor(new Color(30, 58, 95));
        g.drawString(value, x, y);
    }

    private BufferedImage generateQRCode(String data, int size) {
        try {
            QRCodeWriter writer = new QRCodeWriter();
            BitMatrix matrix = writer.encode(data, BarcodeFormat.QR_CODE, size, size);
            return MatrixToImageWriter.toBufferedImage(matrix);
        } catch (WriterException e) {
            return new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
        }
    }

    // ── Helpers ───────────────────────────────────────────────

    private String getNomClient(String refClient) {
        if (refClient == null || refClient.isEmpty()) return "—";
        // refclient dans voucher est VARCHAR, dans client c'est INTEGER — on cast
        String[] queries = {
            "SELECT nomclient FROM client WHERE refclient = CAST(? AS INTEGER)",
            "SELECT nomclient FROM client WHERE CAST(refclient AS TEXT) = ?",
            "SELECT nomclient FROM client WHERE refclient::TEXT = ?"
        };
        for (String sql : queries) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, refClient.trim());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    String nom = rs.getString("nomclient");
                    return nom != null ? nom : "Client #" + refClient;
                }
            } catch (SQLException ignored) {}
        }
        return "Client #" + refClient;
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
