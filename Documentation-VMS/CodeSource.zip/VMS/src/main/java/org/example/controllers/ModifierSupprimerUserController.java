package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.models.User;
import org.example.models.DatabaseConnection;

import java.sql.*;

public class ModifierSupprimerUserController {

    @FXML private TableView<User> tableUsers;
    @FXML private TableColumn<User, String> colUsername;
    @FXML private TableColumn<User, String> colNom;
    @FXML private TableColumn<User, String> colPrenom;
    @FXML private TableColumn<User, String> colEmail;
    @FXML private TableColumn<User, String> colRole;

    @FXML private TextField usernameField;
    @FXML private TextField nomField;
    @FXML private TextField prenomField;
    @FXML private TextField emailField;
    @FXML private TextField roleField;

    private ObservableList<User> userList;

    @FXML
    public void initialize() {
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("userrole"));

        loadUsers();

        tableUsers.getSelectionModel().selectedItemProperty().addListener((obs, old, newSel) -> {
            if (newSel != null) {
                usernameField.setText(newSel.getUsername());
                nomField.setText(newSel.getNom());
                prenomField.setText(newSel.getPrenom());
                emailField.setText(newSel.getEmail());
                roleField.setText(newSel.getUserrole());
            }
        });
    }

    private void loadUsers() {
        userList = FXCollections.observableArrayList();
        String query = "SELECT username, nom, prenom, email, userrole, userpassword, ddl, statususer, titre FROM users ORDER BY nom";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                userList.add(new User(
                        rs.getString("email"),
                        rs.getString("userpassword"),
                        rs.getString("userrole"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("username"),
                        rs.getString("ddl"),
                        rs.getString("statususer"),
                        rs.getString("titre")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger les utilisateurs.");
        }
        tableUsers.setItems(userList);
    }

    @FXML
    private void modifierUser() {
        User selectedUser = tableUsers.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner un utilisateur.");
            return;
        }

        String query = "UPDATE users SET username=?, nom=?, prenom=?, email=?, userrole=? WHERE username=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(query)) {

            pst.setString(1, usernameField.getText().trim());
            pst.setString(2, nomField.getText().trim());
            pst.setString(3, prenomField.getText().trim());
            pst.setString(4, emailField.getText().trim());
            pst.setString(5, roleField.getText().trim());
            pst.setString(6, selectedUser.getUsername());

            int rows = pst.executeUpdate();
            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "Utilisateur modifié avec succès !");
                loadUsers();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de modifier l'utilisateur.\n" + e.getMessage());
        }
    }

    @FXML
    private void supprimerUser() {
        User selectedUser = tableUsers.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner un utilisateur.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Supprimer l'utilisateur " + selectedUser.getPrenom() + " " + selectedUser.getNom() + " ?",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirmation de suppression");
        confirm.setHeaderText(null);
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                String query = "DELETE FROM users WHERE username=?";
                try (Connection conn = DatabaseConnection.getConnection();
                     PreparedStatement pst = conn.prepareStatement(query)) {
                    pst.setString(1, selectedUser.getUsername());
                    pst.executeUpdate();
                    showAlert(Alert.AlertType.INFORMATION, "Supprimé", "Utilisateur supprimé avec succès.");
                    loadUsers();
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de supprimer l'utilisateur.");
                }
            }
        });
    }

    private void clearFields() {
        usernameField.clear();
        nomField.clear();
        prenomField.clear();
        emailField.clear();
        roleField.clear();
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
