package org.example;

import org.example.models.DatabaseConnection;
import java.sql.*;

/**
 * UTILITAIRE TEMPORAIRE — Affiche les vraies colonnes de chaque table.
 * Lance main() une seule fois pour voir la structure, puis supprime ce fichier.
 */
public class DebugSchema {

    public static void main(String[] args) throws Exception {
        try (Connection conn = DatabaseConnection.getConnection()) {
            printTable(conn, "demande");
            printTable(conn, "voucher");
            printTable(conn, "client");
            printTable(conn, "users");
        }
    }

    private static void printTable(Connection conn, String table) throws SQLException {
        System.out.println("\n=== TABLE : " + table.toUpperCase() + " ===");
        DatabaseMetaData meta = conn.getMetaData();
        ResultSet rs = meta.getColumns(null, null, table, null);
        while (rs.next()) {
            System.out.println("  " + rs.getString("COLUMN_NAME")
                    + "  [" + rs.getString("TYPE_NAME") + "]");
        }
        rs.close();
    }
}
