package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.example.utils.Session;

public class MessagesController {

    @FXML private TextArea chatArea;
    @FXML private TextField messageField;
    @FXML private Label userLabel;

    @FXML
    public void initialize() {
        if (Session.getUser() != null) {
            userLabel.setText(Session.getUser().getPrenom() + " " + Session.getUser().getNom());
        }

        // Message d'accueil
        chatArea.setEditable(false);
        chatArea.setText("── Messagerie interne VMS ──\n" +
                         "Fonctionnalité en cours de développement.\n" +
                         "Les messages seront sauvegardés en base de données prochainement.\n\n");
    }

    @FXML
    private void envoyerMessage() {
        String msg = messageField.getText().trim();
        if (msg.isEmpty()) return;

        String user = Session.getUser() != null
                ? Session.getUser().getPrenom() + " " + Session.getUser().getNom()
                : "Utilisateur";

        chatArea.appendText("[" + java.time.LocalTime.now().withNano(0) + "] " + user + " : " + msg + "\n");
        messageField.clear();
    }

    @FXML
    private void effacerMessages() {
        chatArea.clear();
    }
}
