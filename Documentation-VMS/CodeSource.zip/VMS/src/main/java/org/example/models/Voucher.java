package org.example.models;

import javafx.beans.property.*;
import java.time.LocalDate;

public class Voucher {

    private final StringProperty refVoucher;
    private final StringProperty refDemande;
    private final IntegerProperty valeur;
    private final ObjectProperty<LocalDate> dateCreation;
    private final ObjectProperty<LocalDate> dateExpiration;
    private final StringProperty statut;   // "Actif", "Expiré", "Payé"
    private final StringProperty refClient;

    public Voucher(String refVoucher, String refDemande, int valeur,
                   LocalDate dateCreation, LocalDate dateExpiration,
                   String statut, String refClient) {
        this.refVoucher      = new SimpleStringProperty(refVoucher);
        this.refDemande      = new SimpleStringProperty(refDemande);
        this.valeur          = new SimpleIntegerProperty(valeur);
        this.dateCreation    = new SimpleObjectProperty<>(dateCreation);
        this.dateExpiration  = new SimpleObjectProperty<>(dateExpiration);
        this.statut          = new SimpleStringProperty(statut);
        this.refClient       = new SimpleStringProperty(refClient);
    }

    // --- Properties ---
    public StringProperty refVoucherProperty()     { return refVoucher; }
    public StringProperty refDemandeProperty()     { return refDemande; }
    public IntegerProperty valeurProperty()        { return valeur; }
    public ObjectProperty<LocalDate> dateCreationProperty()   { return dateCreation; }
    public ObjectProperty<LocalDate> dateExpirationProperty() { return dateExpiration; }
    public StringProperty statutProperty()         { return statut; }
    public StringProperty refClientProperty()      { return refClient; }

    // --- Getters ---
    public String getRefVoucher()       { return refVoucher.get(); }
    public String getRefDemande()       { return refDemande.get(); }
    public int    getValeur()           { return valeur.get(); }
    public LocalDate getDateCreation()  { return dateCreation.get(); }
    public LocalDate getDateExpiration(){ return dateExpiration.get(); }
    public String getStatut()           { return statut.get(); }
    public String getRefClient()        { return refClient.get(); }

    // --- Setters ---
    public void setStatut(String s)              { statut.set(s); }
    public void setDateExpiration(LocalDate d)   { dateExpiration.set(d); }
    public void setValeur(int v)                 { valeur.set(v); }
}
