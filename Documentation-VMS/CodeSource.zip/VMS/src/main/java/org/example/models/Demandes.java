package org.example.models;

import javafx.beans.property.*;
import java.time.LocalDate;

public class Demandes {

    private final StringProperty            refDemande;
    private final ObjectProperty<LocalDate> dateCreation;
    private final IntegerProperty           nbVouchers;
    private final IntegerProperty           valeurVoucher;
    private final StringProperty            statusDemande;
    private final StringProperty            initiateur;
    private final StringProperty            payeur;
    private final StringProperty            approbateur;
    private final StringProperty            refClient;

    public Demandes(String refDemande, LocalDate dateCreation, int nbVouchers, int valeurVoucher,
                    String statusDemande, String initiateur, String payeur,
                    String approbateur, String refClient) {
        this.refDemande    = new SimpleStringProperty(refDemande);
        this.dateCreation  = new SimpleObjectProperty<>(dateCreation);
        this.nbVouchers    = new SimpleIntegerProperty(nbVouchers);
        this.valeurVoucher = new SimpleIntegerProperty(valeurVoucher);
        this.statusDemande = new SimpleStringProperty(statusDemande);
        this.initiateur    = new SimpleStringProperty(initiateur);
        this.payeur        = new SimpleStringProperty(payeur);
        this.approbateur   = new SimpleStringProperty(approbateur);
        this.refClient     = new SimpleStringProperty(refClient);
    }

    // Properties pour TableView
    public StringProperty            refDemandeProperty()    { return refDemande; }
    public ObjectProperty<LocalDate> dateCreationProperty()  { return dateCreation; }
    public IntegerProperty           nbVouchersProperty()    { return nbVouchers; }
    public IntegerProperty           valeurVoucherProperty() { return valeurVoucher; }
    public StringProperty            statusDemandeProperty() { return statusDemande; }
    public StringProperty            initiateurProperty()    { return initiateur; }
    public StringProperty            payeurProperty()        { return payeur; }
    public StringProperty            approbateurProperty()   { return approbateur; }
    public StringProperty            refClientProperty()     { return refClient; }

    // Getters
    public String    getRefDemande()    { return refDemande.get(); }
    public LocalDate getDateCreation()  { return dateCreation.get(); }
    public int       getNbVouchers()    { return nbVouchers.get(); }
    public int       getValeurVoucher() { return valeurVoucher.get(); }
    public String    getStatusDemande() { return statusDemande.get(); }
    public String    getInitiateur()    { return initiateur.get(); }
    public String    getPayeur()        { return payeur.get(); }
    public String    getApprobateur()   { return approbateur.get(); }
    public String    getRefClient()     { return refClient.get(); }
}
