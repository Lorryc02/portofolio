package org.example.models;

/**
 * Singleton pour stocker l'utilisateur connecté durant toute la session.
 * Utilisé par OverviewController pour compatibilité.
 * Préférer org.example.utils.Session pour les nouveaux controllers.
 */
public class UserSession {

    private static UserSession instance;
    private User currentUser;

    private UserSession() {}

    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
        // Synchroniser aussi avec Session
        org.example.utils.Session.setUser(user);
    }

    public User getCurrentUser() {
        // Si vide, essayer Session
        if (currentUser == null) {
            currentUser = org.example.utils.Session.getUser();
        }
        return currentUser;
    }

    public boolean isLoggedIn() {
        return getCurrentUser() != null;
    }

    public void clearSession() {
        this.currentUser = null;
        org.example.utils.Session.clear();
    }
}
