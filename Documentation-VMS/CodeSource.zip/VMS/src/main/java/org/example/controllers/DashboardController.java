package org.example.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.example.models.User;
import org.example.models.UserSession;
import org.example.utils.Session;

import java.io.IOException;

public class DashboardController {

    @FXML private AnchorPane contentArea;
    @FXML private Label userInfoLabel;

    // Liens du menu — visibilité selon rôle
    @FXML private Hyperlink linkInitier;
    @FXML private Hyperlink linkValider;
    @FXML private Hyperlink linkPaiement;
    @FXML private Hyperlink linkModifierVoucher;
    @FXML private Hyperlink linkAddUser;
    @FXML private Hyperlink linkEditUser;
    @FXML private Hyperlink linkAddClient;
    @FXML private Hyperlink linkEditClient;

    @FXML
    public void initialize() {
        User currentUser = Session.getUser();
        if (currentUser != null) {
            userInfoLabel.setText(currentUser.getPrenom() + " " + currentUser.getNom()
                    + "  •  " + currentUser.getUserrole());
            applyRoleVisibility(currentUser.getUserrole());
        } else {
            userInfoLabel.setText("Utilisateur inconnu");
        }

        try { goOverview(); } catch (IOException e) {
            System.err.println("Erreur chargement overview: " + e.getMessage());
        }
    }

    /**
     * Masque les sections du menu selon le rôle de l'utilisateur.
     * SuperUser voit tout. Les autres ont accès limité.
     */
    private void applyRoleVisibility(String role) {
        boolean isSuperUser  = role.equals("SuperUser");
        boolean isSuperviseur = role.equals("Superviseur");
        boolean isInitiateur  = role.equals("Initiateur");
        boolean isApprobateur = role.equals("Approbateur");
        boolean isComptable   = role.equals("Comptable");

        // Initier : Initiateur + SuperUser
        setVisible(linkInitier, isSuperUser || isInitiateur);

        // Valider : Approbateur + SuperUser
        setVisible(linkValider, isSuperUser || isApprobateur);

        // Paiement : Comptable + SuperUser
        setVisible(linkPaiement, isSuperUser || isComptable);

        // Modifier Voucher : SuperUser + Superviseur
        setVisible(linkModifierVoucher, isSuperUser || isSuperviseur);

        // Gestion utilisateurs : SuperUser uniquement
        setVisible(linkAddUser,  isSuperUser);
        setVisible(linkEditUser, isSuperUser);

        // Gestion clients : SuperUser + Superviseur
        setVisible(linkAddClient,  isSuperUser || isSuperviseur);
        setVisible(linkEditClient, isSuperUser || isSuperviseur);
    }

    private void setVisible(Hyperlink link, boolean visible) {
        if (link != null) {
            link.setVisible(visible);
            link.setManaged(visible);
        }
    }

    private void loadPage(String fxmlPath) throws IOException {
        Parent pane = FXMLLoader.load(getClass().getResource(fxmlPath));
        contentArea.getChildren().setAll(pane);
        AnchorPane.setTopAnchor(pane, 0.0);
        AnchorPane.setBottomAnchor(pane, 0.0);
        AnchorPane.setLeftAnchor(pane, 0.0);
        AnchorPane.setRightAnchor(pane, 0.0);
    }

    @FXML private void goOverview()        throws IOException { loadPage("/views/overview.fxml"); }
    @FXML private void goExport()        throws IOException { loadPage("/views/export_voucher.fxml"); }
    @FXML private void goInitier()         throws IOException { loadPage("/views/Initier.fxml"); }
    @FXML private void goValider()         throws IOException { loadPage("/views/Valider.fxml"); }
    @FXML private void goPaiement()        throws IOException { loadPage("/views/voucher_paiement.fxml"); }
    @FXML private void goModifierVoucher() throws IOException { loadPage("/views/voucher_modifier.fxml"); }
    @FXML private void goAddUser()         throws IOException { loadPage("/views/AjoutUser.fxml"); }
    @FXML private void goEditUser()        throws IOException { loadPage("/views/modifierSupprimerUser.fxml"); }
    @FXML private void goAddClient()       throws IOException { loadPage("/views/AjoutClient.fxml"); }
    @FXML private void goEditClient()      throws IOException { loadPage("/views/modifierSupprimerClients.fxml"); }

    @FXML
    private void handleLogout() {
        try {
            Session.clear();
            UserSession.getInstance().clearSession();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/Login.fxml"));
            Scene scene = new Scene(loader.load(), 860, 520);
            String css = getClass().getResource("/styles/login.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = (Stage) contentArea.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("VMS • Connexion");
            stage.setMaximized(false);
            stage.centerOnScreen();
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
