package org.example.models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClientDAO {

    public List<Client> getAllClients() {
        List<Client> clients = new ArrayList<>();
        String sql = "SELECT refclient, nomclient, email, adresse, tel FROM client ORDER BY nomclient";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) clients.add(map(rs));
        } catch (SQLException e) {
            System.err.println("Erreur getAllClients: " + e.getMessage());
        }
        return clients;
    }

    public List<Client> searchClients(String searchText) {
        List<Client> clients = new ArrayList<>();
        String sql = "SELECT refclient, nomclient, email, adresse, tel FROM client " +
                     "WHERE LOWER(nomclient) LIKE LOWER(?) OR CAST(tel AS TEXT) LIKE ? ORDER BY nomclient";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String pattern = "%" + searchText + "%";
            ps.setString(1, pattern);
            ps.setString(2, pattern);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) clients.add(map(rs));
        } catch (SQLException e) {
            System.err.println("Erreur searchClients: " + e.getMessage());
        }
        return clients;
    }

    public boolean addClient(String nom, String email, String adresse, int tel) {
        String sql = "INSERT INTO client (nomclient, email, adresse, tel) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nom);
            ps.setString(2, email);
            ps.setString(3, adresse);
            ps.setInt(4, tel);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erreur addClient: " + e.getMessage());
            return false;
        }
    }

    public Client getClientById(int refClient) {
        String sql = "SELECT refclient, nomclient, email, adresse, tel FROM client WHERE refclient = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, refClient);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) {
            System.err.println("Erreur getClientById: " + e.getMessage());
        }
        return null;
    }

    public int countClients() {
        String sql = "SELECT COUNT(*) FROM client";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Erreur countClients: " + e.getMessage());
        }
        return 0;
    }

    private Client map(ResultSet rs) throws SQLException {
        return new Client(
                rs.getInt("refclient"),
                rs.getString("nomclient"),
                rs.getString("email"),
                rs.getString("adresse"),
                rs.getInt("tel")
        );
    }
}
