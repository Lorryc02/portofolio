package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.example.models.DatabaseConnection;
import org.example.models.User;
import org.example.utils.Session;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class OverviewController {

    @FXML private Label demandesCount;
    @FXML private Label clientsCount;
    @FXML private Label vouchersCount;
    @FXML private Label enAttentePaiement;
    @FXML private Label enAttenteApprobation;
    @FXML private Label vouchersExpires;
    @FXML private Label welcomeMessage;

    @FXML
    public void initialize() {
        User currentUser = Session.getUser();
        if (currentUser != null) {
            welcomeMessage.setText("👋 Bienvenue, " + currentUser.getPrenom() + " " + currentUser.getNom() + " !");
        } else {
            welcomeMessage.setText("👋 Bienvenue sur VMS !");
        }
        loadStatistics();
    }

    private void loadStatistics() {
        try (Connection conn = DatabaseConnection.getConnection()) {

            // Total demandes
            demandesCount.setText(String.valueOf(queryCount(conn, "SELECT COUNT(*) FROM demande")));

            // Total clients
            clientsCount.setText(String.valueOf(queryCount(conn, "SELECT COUNT(*) FROM client")));

            // Total vouchers
            vouchersCount.setText(String.valueOf(queryCount(conn, "SELECT COUNT(*) FROM voucher")));

            // En attente paiement
            enAttentePaiement.setText(String.valueOf(
                    queryCount(conn, "SELECT COUNT(*) FROM demande WHERE statusdemande = 'approuvé'")));

            // En attente approbation
            enAttenteApprobation.setText(String.valueOf(
                    queryCount(conn, "SELECT COUNT(*) FROM demande WHERE statusdemande = 'initié'")));

            // Vouchers expirés
            vouchersExpires.setText(String.valueOf(
                    queryCount(conn, "SELECT COUNT(*) FROM voucher WHERE statut = 'Expiré'")));

        } catch (Exception e) {
            System.err.println("Erreur chargement statistiques: " + e.getMessage());
            demandesCount.setText("—");
            clientsCount.setText("—");
            vouchersCount.setText("—");
            enAttentePaiement.setText("—");
            enAttenteApprobation.setText("—");
            vouchersExpires.setText("—");
        }
    }

    private int queryCount(Connection conn, String sql) {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            // table peut ne pas encore exister
        }
        return 0;
    }
}
