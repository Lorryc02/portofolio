package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.models.Demandes;
import org.example.models.DemandeDAO;
import org.example.models.DatabaseConnection;
import org.example.utils.Session;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class PaiementController {

    @FXML private TableView<Demandes> tablePaiements;
    @FXML private TableColumn<Demandes, String>    colRefDemande;
    @FXML private TableColumn<Demandes, LocalDate> colDateCreation;
    @FXML private TableColumn<Demandes, Integer>   colNbVouchers;
    @FXML private TableColumn<Demandes, Integer>   colValeurVoucher;
    @FXML private TableColumn<Demandes, String>    colStatus;
    @FXML private TableColumn<Demandes, String>    colInitiateur;
    @FXML private TableColumn<Demandes, String>    colPayeur;
    @FXML private TableColumn<Demandes, String>    colRefClient;

    @FXML private Label totalLabel;
    @FXML private Label enAttentePaiementLabel;
    @FXML private Label paiementsValides;

    private final DemandeDAO demandeDAO = new DemandeDAO();

    @FXML
    public void initialize() {
        colRefDemande.setCellValueFactory(d -> d.getValue().refDemandeProperty());
        colDateCreation.setCellValueFactory(d -> d.getValue().dateCreationProperty());
        colNbVouchers.setCellValueFactory(d -> d.getValue().nbVouchersProperty().asObject());
        colValeurVoucher.setCellValueFactory(d -> d.getValue().valeurVoucherProperty().asObject());
        colStatus.setCellValueFactory(d -> d.getValue().statusDemandeProperty());
        colInitiateur.setCellValueFactory(d -> d.getValue().initiateurProperty());
        colPayeur.setCellValueFactory(d -> d.getValue().payeurProperty());
        colRefClient.setCellValueFactory(d -> d.getValue().refClientProperty());

        tablePaiements.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(Demandes item, boolean empty) {
                super.updateItem(item, empty);
                if (item == null || empty) { setStyle(""); return; }
                if ("payé".equals(item.getStatusDemande())) {
                    setStyle("-fx-background-color: #dcfce7;");
                } else if ("approuvé".equals(item.getStatusDemande())) {
                    setStyle("-fx-background-color: #fef9c3;");
                } else {
                    setStyle("");
                }
            }
        });

        loadDemandes();
    }

    private void loadDemandes() {
        List<Demandes> approuvees = demandeDAO.getDemandesByStatut("approuvé");
        List<Demandes> payees     = demandeDAO.getDemandesByStatut("payé");

        ObservableList<Demandes> list = FXCollections.observableArrayList();
        list.addAll(approuvees);
        list.addAll(payees);
        tablePaiements.setItems(list);

        if (totalLabel != null)             totalLabel.setText(String.valueOf(list.size()));
        if (enAttentePaiementLabel != null) enAttentePaiementLabel.setText(String.valueOf(approuvees.size()));
        if (paiementsValides != null)       paiementsValides.setText(String.valueOf(payees.size()));
    }

    @FXML
    private void validerPaiement() {
        Demandes selected = tablePaiements.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner une demande.");
            return;
        }
        if (!"approuvé".equals(selected.getStatusDemande())) {
            showAlert(Alert.AlertType.WARNING, "Action impossible",
                    "Seules les demandes 'approuvées' peuvent être payées.");
            return;
        }

        // Vérifier si des vouchers existent déjà pour cette demande
        if (vouchersDejaGeneres(selected.getRefDemande())) {
            showAlert(Alert.AlertType.WARNING, "Déjà généré",
                    "Des vouchers ont déjà été générés pour cette demande.");
            return;
        }

        String payeur = Session.getUser() != null ? Session.getUser().getUsername() : "comptable";

        // 1. Mettre à jour le statut
        boolean ok = demandeDAO.updateStatut(selected.getRefDemande(), "payé", payeur, "payeur");
        if (!ok) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de valider le paiement.");
            return;
        }

        // 2. Générer les vouchers automatiquement
        int nbGeneres = genererVouchers(selected);

        showAlert(Alert.AlertType.INFORMATION, "Paiement validé !",
                "Paiement validé avec succès !\n" + nbGeneres + " voucher(s) généré(s).");
        loadDemandes();
    }

    /**
     * Vérifie si des vouchers ont déjà été générés pour cette demande
     */
    private boolean vouchersDejaGeneres(String refDemande) {
        String sql = "SELECT COUNT(*) FROM voucher WHERE refdemande = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, refDemande);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) {
            System.err.println("Erreur vouchersDejaGeneres: " + e.getMessage());
        }
        return false;
    }

    /**
     * Génère N vouchers pour la demande payée et les insère dans la table voucher.
     * Utilise un batch INSERT pour la performance.
     */
    private int genererVouchers(Demandes demande) {
        int    nbVouchers = demande.getNbVouchers();
        int    valeur     = demande.getValeurVoucher();
        String refClient  = demande.getRefClient();
        String refDemande = demande.getRefDemande();
        LocalDate today   = LocalDate.now();
        LocalDate expiration = today.plusYears(1);

        // redeemedBy est NOT NULL dans la table
        String redeemedBy = Session.getUser() != null
                ? Session.getUser().getUsername() : "system";

        String sql = "INSERT INTO voucher " +
                "(refvoucher, valeurvoucher, dateemission, dateexpiration, " +
                "statusvoucher, \"redeemedBy\", refclient, refdemande) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        int count = 0;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            for (int i = 0; i < nbVouchers; i++) {
                String refVoucher = "VOU-" + UUID.randomUUID()
                        .toString().substring(0, 8).toUpperCase();

                ps.setString(1, refVoucher);
                ps.setInt(2, valeur);
                ps.setDate(3, Date.valueOf(today));
                ps.setDate(4, Date.valueOf(expiration));
                ps.setString(5, "Actif");
                ps.setString(6, redeemedBy);
                ps.setString(7, refClient);
                ps.setString(8, refDemande);
                ps.addBatch();
                count++;
            }

            ps.executeBatch();
            System.out.println("✅ " + count + " voucher(s) générés pour " + refDemande);

        } catch (SQLException e) {
            System.err.println("❌ Erreur génération vouchers: " + e.getMessage());
            e.printStackTrace();
            count = 0;
        }
        return count;
    }

    @FXML
    private void marquerEnAttente() {
        Demandes selected = tablePaiements.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner une demande.");
            return;
        }
        if ("payé".equals(selected.getStatusDemande())) {
            showAlert(Alert.AlertType.WARNING, "Action impossible",
                    "Impossible de remettre en attente une demande déjà payée avec vouchers générés.");
            return;
        }
        boolean ok = demandeDAO.updateStatut(selected.getRefDemande(), "approuvé", "", "payeur");
        if (ok) {
            showAlert(Alert.AlertType.INFORMATION, "Mis à jour", "Demande remise en attente de paiement.");
            loadDemandes();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de modifier le statut.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
