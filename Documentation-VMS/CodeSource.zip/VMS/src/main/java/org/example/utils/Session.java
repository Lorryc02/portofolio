package org.example.utils;

import org.example.models.User;

/**
 * Session statique pour stocker l'utilisateur connecté.
 * Source unique de vérité pour tous les controllers.
 */
public class Session {

    private static User currentUser;

    public static void setUser(User user) {
        currentUser = user;
    }

    public static User getUser() {
        return currentUser;
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    /**
     * Retourne le rôle de l'utilisateur connecté, ou "" si non connecté.
     */
    public static String getRole() {
        return currentUser != null ? currentUser.getUserrole() : "";
    }

    /**
     * Vérifie si l'utilisateur connecté a un rôle donné.
     */
    public static boolean hasRole(String... roles) {
        if (currentUser == null) return false;
        for (String r : roles) {
            if (currentUser.getUserrole().equals(r)) return true;
        }
        return false;
    }

    public static void clear() {
        currentUser = null;
    }
}
