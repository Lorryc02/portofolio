package org.example.models;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DemandeDAO {

    public boolean addDemande(String refDemande, int nbVouchers, int valeurVoucher,
                              String status, String initiateur, String refClient) {
        String sql = "INSERT INTO demande (refdemande, nbvouchers, valeurvoucher, " +
                     "statusdemande, \"Initiateur\", refclient, datecreation) " +
                     "VALUES (?, ?, ?, ?, ?, ?, CURRENT_DATE)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, refDemande);
            stmt.setInt(2, nbVouchers);
            stmt.setInt(3, valeurVoucher);
            stmt.setString(4, status);
            stmt.setString(5, initiateur);
            stmt.setString(6, refClient);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erreur addDemande: " + e.getMessage());
            return false;
        }
    }

    public List<Demandes> getAllDemandes() {
        List<Demandes> list = new ArrayList<>();
        // On utilise SELECT * puis on lit dynamiquement pour éviter
        // les erreurs de noms de colonnes
        String sql = "SELECT * FROM demande ORDER BY datecreation DESC NULLS LAST";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
            System.out.println("✅ getAllDemandes: " + list.size() + " demande(s)");
        } catch (SQLException e) {
            System.err.println("❌ Erreur getAllDemandes: " + e.getMessage());
        }
        return list;
    }

    public List<Demandes> getDemandesByStatut(String statut) {
        List<Demandes> list = new ArrayList<>();
        String sql = "SELECT * FROM demande WHERE statusdemande = ? ORDER BY datecreation DESC NULLS LAST";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, statut);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("❌ Erreur getDemandesByStatut: " + e.getMessage());
        }
        return list;
    }

    public boolean updateStatut(String refDemande, String statut, String acteur, String typeActeur) {
        String sql;
        boolean hasActeur = !typeActeur.isEmpty() && !acteur.isEmpty();

        switch (typeActeur) {
            case "approbateur" ->
                sql = "UPDATE demande SET statusdemande = ?, \"Approbateur\" = ? WHERE refdemande = ?";
            case "payeur" ->
                sql = "UPDATE demande SET statusdemande = ?, \"Payeur\" = ? WHERE refdemande = ?";
            default -> {
                sql = "UPDATE demande SET statusdemande = ? WHERE refdemande = ?";
                hasActeur = false;
            }
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, statut);
            if (hasActeur) {
                ps.setString(2, acteur);
                ps.setString(3, refDemande);
            } else {
                ps.setString(2, refDemande);
            }
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            // Essayer sans guillemets si ça échoue
            System.err.println("❌ Erreur updateStatut (avec guillemets): " + e.getMessage());
            return updateStatutFallback(refDemande, statut, acteur, typeActeur);
        }
    }

    private boolean updateStatutFallback(String refDemande, String statut, String acteur, String typeActeur) {
        // Version sans guillemets pour les colonnes
        String sql;
        boolean hasActeur = !typeActeur.isEmpty() && !acteur.isEmpty();
        switch (typeActeur) {
            case "approbateur" -> sql = "UPDATE demande SET statusdemande = ?, approbateur = ? WHERE refdemande = ?";
            case "payeur"      -> sql = "UPDATE demande SET statusdemande = ?, payeur = ? WHERE refdemande = ?";
            default -> { sql = "UPDATE demande SET statusdemande = ? WHERE refdemande = ?"; hasActeur = false; }
        }
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, statut);
            if (hasActeur) { ps.setString(2, acteur); ps.setString(3, refDemande); }
            else           { ps.setString(2, refDemande); }
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Erreur updateStatutFallback: " + e.getMessage());
            return false;
        }
    }

    public int countByStatut(String statut) {
        String sql = "SELECT COUNT(*) FROM demande WHERE statusdemande = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, statut);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("❌ Erreur countByStatut: " + e.getMessage());
        }
        return 0;
    }

    public int countAll() {
        String sql = "SELECT COUNT(*) FROM demande";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("❌ Erreur countAll: " + e.getMessage());
        }
        return 0;
    }

    // Mapper dynamiquement — lit les colonnes qui existent
    private Demandes mapRow(ResultSet rs) throws SQLException {
        ResultSetMetaData meta = rs.getMetaData();
        
        // Construire un set de noms de colonnes en minuscules
        java.util.Set<String> cols = new java.util.HashSet<>();
        for (int i = 1; i <= meta.getColumnCount(); i++) {
            cols.add(meta.getColumnName(i).toLowerCase());
        }

        Date d = rs.getDate("datecreation");
        
        // Lire Initiateur (peut être "Initiateur" ou "initiateur")
        String initiateur = safeGet(rs, cols, "Initiateur", "initiateur");
        String payeur     = safeGet(rs, cols, "Payeur",     "payeur");
        String approbateur= safeGet(rs, cols, "Approbateur","approbateur");

        return new Demandes(
                rs.getString("refdemande"),
                d != null ? d.toLocalDate() : null,
                rs.getInt("nbvouchers"),
                rs.getInt("valeurvoucher"),
                rs.getString("statusdemande"),
                initiateur,
                payeur,
                approbateur,
                rs.getString("refclient")
        );
    }

    /** Essaie plusieurs variantes de noms de colonnes */
    private String safeGet(ResultSet rs, java.util.Set<String> cols, String... names) {
        for (String name : names) {
            if (cols.contains(name.toLowerCase())) {
                try {
                    String v = rs.getString(name);
                    return v != null ? v : "";
                } catch (SQLException ignored) {}
            }
        }
        return "";
    }
}
