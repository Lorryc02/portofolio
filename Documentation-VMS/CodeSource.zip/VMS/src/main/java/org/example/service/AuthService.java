package org.example.service;

import org.example.models.User;
import org.example.models.UserDAO;
import org.example.utils.Session;

/**
 * Service d'authentification.
 * Utilisé par LoginController pour vérifier les identifiants.
 */
public class AuthService {

    private final UserDAO dao = new UserDAO();

    /**
     * Authentifie un utilisateur par email et mot de passe.
     * @return User si authentification réussie, null sinon.
     */
    public User login(String email, String password) {
        User user = dao.findByEmail(email);
        if (user != null && user.getUserpassword().equals(password)) {
            if (!"Actif".equals(user.getStatususer())) {
                return null; // compte inactif
            }
            Session.setUser(user);
            return user;
        }
        return null;
    }

    public void logout() {
        Session.clear();
    }
}
