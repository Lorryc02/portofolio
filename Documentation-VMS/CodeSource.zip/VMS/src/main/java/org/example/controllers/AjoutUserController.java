package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import org.example.models.DatabaseConnection;

public class AjoutUserController {

    @FXML private TextField nomField;
    @FXML private TextField prenomField;
    @FXML private TextField emailField;
    @FXML private TextField passwordField;
    @FXML private TextField titreField;
    @FXML private ComboBox<String> roleCombo;

    @FXML
    public void initialize() {
        roleCombo.getItems().addAll(
                "SuperUser",
                "Superviseur",
                "Initiateur",
                "Approbateur",
                "Comptable"
        );
    }

    @FXML
    private void ajouterUtilisateur() {
        String nom    = nomField.getText().trim();
        String prenom = prenomField.getText().trim();
        String email  = emailField.getText().trim();
        String pwd    = passwordField.getText().trim();
        String titre  = titreField.getText().trim();
        String role   = roleCombo.getValue();

        if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || pwd.isEmpty() || role == null) {
            showAlert(Alert.AlertType.WARNING, "Champs requis", "Veuillez remplir tous les champs obligatoires.");
            return;
        }

        if (!email.contains("@")) {
            showAlert(Alert.AlertType.ERROR, "Email invalide", "Veuillez saisir une adresse email valide.");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Vérifier si l'email existe déjà
            var checkStmt = conn.prepareStatement("SELECT COUNT(*) FROM users WHERE email = ?");
            checkStmt.setString(1, email);
            var rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                showAlert(Alert.AlertType.ERROR, "Email déjà utilisé", "Un utilisateur avec cet email existe déjà.");
                return;
            }

            String sql = "INSERT INTO users (username, nom, prenom, userrole, userpassword, ddl, titre, email, statususer) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, nom);
            stmt.setString(3, prenom);
            stmt.setString(4, role);
            stmt.setString(5, pwd);
            stmt.setDate(6, java.sql.Date.valueOf(LocalDate.now()));
            stmt.setString(7, titre);
            stmt.setString(8, email);
            stmt.setString(9, "Actif");
            stmt.executeUpdate();

            showAlert(Alert.AlertType.INFORMATION, "Succès", "Utilisateur " + prenom + " " + nom + " ajouté avec succès !");
            clearFields();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible d'ajouter l'utilisateur.\n" + e.getMessage());
        }
    }

    @FXML
    private void annuler() {
        clearFields();
    }

    private void clearFields() {
        nomField.clear();
        prenomField.clear();
        emailField.clear();
        passwordField.clear();
        titreField.clear();
        roleCombo.setValue(null);
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
