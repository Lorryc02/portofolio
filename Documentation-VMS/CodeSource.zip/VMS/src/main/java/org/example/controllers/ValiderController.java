package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.models.Demandes;
import org.example.models.DemandeDAO;
import org.example.utils.Session;

import java.time.LocalDate;
import java.util.List;

public class ValiderController {

    @FXML private TableView<Demandes> tableDemandes;
    @FXML private TableColumn<Demandes, String>    colRefDemande;
    @FXML private TableColumn<Demandes, LocalDate> colDateCreation;
    @FXML private TableColumn<Demandes, Integer>   colNbVouchers;
    @FXML private TableColumn<Demandes, Integer>   colValeurVoucher;
    @FXML private TableColumn<Demandes, String>    colStatus;
    @FXML private TableColumn<Demandes, String>    colInitiateur;
    @FXML private TableColumn<Demandes, String>    colPayeur;
    @FXML private TableColumn<Demandes, String>    colApprobateur;
    @FXML private TableColumn<Demandes, String>    colRefClient;

    private final DemandeDAO demandeDAO = new DemandeDAO();
    private ObservableList<Demandes> demandesList;

    @FXML
    public void initialize() {
        colRefDemande.setCellValueFactory(d -> d.getValue().refDemandeProperty());
        colDateCreation.setCellValueFactory(d -> d.getValue().dateCreationProperty());
        colNbVouchers.setCellValueFactory(d -> d.getValue().nbVouchersProperty().asObject());
        colValeurVoucher.setCellValueFactory(d -> d.getValue().valeurVoucherProperty().asObject());
        colStatus.setCellValueFactory(d -> d.getValue().statusDemandeProperty());
        colInitiateur.setCellValueFactory(d -> d.getValue().initiateurProperty());
        colPayeur.setCellValueFactory(d -> d.getValue().payeurProperty());
        colApprobateur.setCellValueFactory(d -> d.getValue().approbateurProperty());
        colRefClient.setCellValueFactory(d -> d.getValue().refClientProperty());

        // Colorer les lignes selon le statut
        tableDemandes.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(Demandes item, boolean empty) {
                super.updateItem(item, empty);
                if (item == null || empty) {
                    setStyle("");
                } else {
                    switch (item.getStatusDemande()) {
                        case "initié"   -> setStyle("-fx-background-color: #fef9c3;");
                        case "approuvé" -> setStyle("-fx-background-color: #dcfce7;");
                        case "rejeté"   -> setStyle("-fx-background-color: #fee2e2;");
                        case "annulé"   -> setStyle("-fx-background-color: #f1f5f9;");
                        default         -> setStyle("");
                    }
                }
            }
        });

        loadDemandes();
    }

    private void loadDemandes() {
        List<Demandes> data = demandeDAO.getAllDemandes();
        demandesList = FXCollections.observableArrayList(data);
        tableDemandes.setItems(demandesList);
    }

    @FXML
    private void validerDemande(ActionEvent event) {
        Demandes selected = tableDemandes.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner une demande.");
            return;
        }
        if (!"initié".equals(selected.getStatusDemande())) {
            showAlert(Alert.AlertType.WARNING, "Action impossible", "Seules les demandes 'initiées' peuvent être approuvées.");
            return;
        }
        String acteur = Session.getUser() != null ? Session.getUser().getUsername() : "approbateur";
        boolean ok = demandeDAO.updateStatut(selected.getRefDemande(), "approuvé", acteur, "approbateur");
        if (ok) {
            showAlert(Alert.AlertType.INFORMATION, "Succès", "Demande approuvée avec succès !");
            loadDemandes();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de valider la demande.");
        }
    }

    @FXML
    private void rejeterDemande(ActionEvent event) {
        Demandes selected = tableDemandes.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner une demande.");
            return;
        }
        if (!"initié".equals(selected.getStatusDemande())) {
            showAlert(Alert.AlertType.WARNING, "Action impossible", "Seules les demandes 'initiées' peuvent être rejetées.");
            return;
        }
        String acteur = Session.getUser() != null ? Session.getUser().getUsername() : "approbateur";
        boolean ok = demandeDAO.updateStatut(selected.getRefDemande(), "rejeté", acteur, "approbateur");
        if (ok) {
            showAlert(Alert.AlertType.INFORMATION, "Succès", "Demande rejetée.");
            loadDemandes();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de rejeter la demande.");
        }
    }

    @FXML
    private void annulerDemande(ActionEvent event) {
        Demandes selected = tableDemandes.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner une demande.");
            return;
        }
        if ("annulé".equals(selected.getStatusDemande())) {
            showAlert(Alert.AlertType.WARNING, "Déjà annulée", "Cette demande est déjà annulée.");
            return;
        }
        boolean ok = demandeDAO.updateStatut(selected.getRefDemande(), "annulé", "", "");
        if (ok) {
            showAlert(Alert.AlertType.INFORMATION, "Succès", "Demande annulée.");
            loadDemandes();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible d'annuler la demande.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
