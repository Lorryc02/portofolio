package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.example.models.Client;
import org.example.models.ClientDAO;
import org.example.models.DemandeDAO;
import org.example.utils.Session;

import java.util.List;
import java.util.UUID;

public class InitierController {

    @FXML private TextField clientNameField;
    @FXML private TextField voucherValueField;
    @FXML private TextField voucherCountField;
    @FXML private DatePicker validityDatePicker;
    @FXML private Button submitButton;
    @FXML private Button dropdownButton;
    @FXML private Button addClientButton;
    @FXML private Button searchButton;

    private final ClientDAO clientDAO = new ClientDAO();
    private final DemandeDAO demandeDAO = new DemandeDAO();
    private Client selectedClient;

    @FXML
    public void initialize() {
        submitButton.setOnAction(e -> createVoucherRequest());
        dropdownButton.setOnAction(e -> showClientDropdown());
        addClientButton.setOnAction(e -> showAddClientModal());
        searchButton.setOnAction(e -> showSearchModal());
    }

    // ---- DROPDOWN LISTE DE TOUS LES CLIENTS ----
    private void showClientDropdown() {
        List<Client> clients = clientDAO.getAllClients();
        if (clients.isEmpty()) {
            showAlert("Aucun client", "Aucun client trouvé dans la base de données.");
            return;
        }

        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Sélectionner un client");

        ListView<String> listView = new ListView<>();
        ObservableList<String> items = FXCollections.observableArrayList();
        for (Client c : clients) {
            items.add(c.getNomClient() + " — Tél : " + c.getTel());
        }
        listView.setItems(items);
        listView.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) {
                int idx = listView.getSelectionModel().getSelectedIndex();
                if (idx >= 0) {
                    selectedClient = clients.get(idx);
                    clientNameField.setText(selectedClient.getNomClient());
                    stage.close();
                }
            }
        });

        VBox vbox = new VBox(10,
                new Label("Double-cliquez pour sélectionner un client :"), listView);
        vbox.setPadding(new Insets(14));
        stage.setScene(new Scene(vbox, 420, 320));
        stage.showAndWait();
    }

    // ---- MODAL AJOUT NOUVEAU CLIENT ----
    private void showAddClientModal() {
        Stage modalStage = new Stage();
        modalStage.initModality(Modality.APPLICATION_MODAL);
        modalStage.setTitle("Ajouter un nouveau client");

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField nomField    = new TextField(); nomField.setPromptText("Nom complet");
        TextField emailField  = new TextField(); emailField.setPromptText("email@exemple.com");
        TextField adresseField = new TextField(); adresseField.setPromptText("Adresse");
        TextField telField    = new TextField(); telField.setPromptText("Téléphone");

        grid.add(new Label("Nom :"),      0, 0); grid.add(nomField,    1, 0);
        grid.add(new Label("Email :"),    0, 1); grid.add(emailField,  1, 1);
        grid.add(new Label("Adresse :"),  0, 2); grid.add(adresseField,1, 2);
        grid.add(new Label("Téléphone :"),0, 3); grid.add(telField,    1, 3);

        Button saveBtn   = new Button("Enregistrer");
        Button cancelBtn = new Button("Annuler");
        saveBtn.setStyle("-fx-background-color: #059669; -fx-text-fill: white; -fx-font-weight: 700; -fx-padding: 8 22; -fx-background-radius: 8;");
        cancelBtn.setStyle("-fx-background-color: #f1f5f9; -fx-text-fill: #475569; -fx-padding: 8 22; -fx-background-radius: 8;");

        saveBtn.setOnAction(e -> {
            try {
                String nom    = nomField.getText().trim();
                String email  = emailField.getText().trim();
                String adresse = adresseField.getText().trim();
                int tel       = Integer.parseInt(telField.getText().trim());

                if (nom.isEmpty() || email.isEmpty()) {
                    showAlert("Champs requis", "Le nom et l'email sont obligatoires.");
                    return;
                }
                if (clientDAO.addClient(nom, email, adresse, tel)) {
                    showAlert("Succès", "Client ajouté avec succès !");
                    modalStage.close();
                } else {
                    showAlert("Erreur", "Impossible d'ajouter le client.");
                }
            } catch (NumberFormatException ex) {
                showAlert("Erreur", "Le numéro de téléphone doit être numérique.");
            }
        });
        cancelBtn.setOnAction(e -> modalStage.close());

        HBox btns = new HBox(10, saveBtn, cancelBtn);
        btns.setAlignment(Pos.CENTER);
        grid.add(btns, 0, 4, 2, 1);

        modalStage.setScene(new Scene(grid, 420, 260));
        modalStage.showAndWait();
    }

    // ---- MODAL RECHERCHE CLIENT ----
    private void showSearchModal() {
        Stage searchStage = new Stage();
        searchStage.initModality(Modality.APPLICATION_MODAL);
        searchStage.setTitle("Rechercher un client");

        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(16));

        TextField searchField = new TextField();
        searchField.setPromptText("Nom ou numéro de téléphone...");

        ListView<String> resultList = new ListView<>();
        Label resultLabel = new Label("Tapez pour rechercher");

        final List<Client>[] results = new List[]{null};

        searchField.textProperty().addListener((obs, old, newVal) -> {
            if (newVal.trim().isEmpty()) {
                resultList.getItems().clear();
                resultLabel.setText("Tapez pour rechercher");
                return;
            }
            results[0] = clientDAO.searchClients(newVal.trim());
            ObservableList<String> items = FXCollections.observableArrayList();
            for (Client c : results[0]) {
                items.add(c.getNomClient() + " — Tél : " + c.getTel());
            }
            resultList.setItems(items);
            resultLabel.setText(results[0].size() + " résultat(s)");
        });

        resultList.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && results[0] != null) {
                int idx = resultList.getSelectionModel().getSelectedIndex();
                if (idx >= 0) {
                    selectedClient = results[0].get(idx);
                    clientNameField.setText(selectedClient.getNomClient());
                    searchStage.close();
                }
            }
        });

        vbox.getChildren().addAll(new Label("Rechercher un client :"), searchField, resultLabel, resultList);
        searchStage.setScene(new Scene(vbox, 450, 360));
        searchStage.showAndWait();
    }

    // ---- CRÉER LA DEMANDE ----
    private void createVoucherRequest() {
        if (selectedClient == null) {
            showAlert("Client manquant", "Veuillez sélectionner un client.");
            return;
        }
        if (voucherValueField.getText().isEmpty() || voucherCountField.getText().isEmpty()) {
            showAlert("Champs requis", "Veuillez remplir la valeur et le nombre de vouchers.");
            return;
        }

        try {
            int value = Integer.parseInt(voucherValueField.getText().trim());
            int count = Integer.parseInt(voucherCountField.getText().trim());

            if (value <= 0 || count <= 0) {
                showAlert("Valeur invalide", "La valeur et le nombre doivent être positifs.");
                return;
            }

            String refDemande = "DEM-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            String initiateur = Session.getUser() != null ? Session.getUser().getUsername() : "initiateur";
            String refClient  = String.valueOf(selectedClient.getRefClient());

            boolean ok = demandeDAO.addDemande(refDemande, count, value, "initié", initiateur, refClient);

            if (ok) {
                showAlert("Succès", "Demande " + refDemande + " créée avec succès !");
                clearForm();
            } else {
                showAlert("Erreur", "Impossible d'enregistrer la demande.");
            }

        } catch (NumberFormatException e) {
            showAlert("Erreur", "La valeur et le nombre doivent être des entiers valides.");
        }
    }

    private void clearForm() {
        clientNameField.clear();
        voucherValueField.clear();
        voucherCountField.clear();
        validityDatePicker.setValue(null);
        selectedClient = null;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
