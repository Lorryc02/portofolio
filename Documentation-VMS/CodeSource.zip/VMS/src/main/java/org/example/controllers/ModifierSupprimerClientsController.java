package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.models.Client;
import org.example.models.DatabaseConnection;

import java.sql.*;

public class ModifierSupprimerClientsController {

    @FXML private TableView<Client> clientsTable;
    @FXML private TableColumn<Client, Integer> colRef;
    @FXML private TableColumn<Client, String>  colNom;
    @FXML private TableColumn<Client, String>  colEmail;
    @FXML private TableColumn<Client, String>  colAdresse;
    @FXML private TableColumn<Client, Integer> colTel;

    @FXML private TextField txtNom;
    @FXML private TextField txtEmail;
    @FXML private TextField txtAdresse;
    @FXML private TextField txtTel;

    private ObservableList<Client> clientsList = FXCollections.observableArrayList();
    private Client selectedClient;

    @FXML
    public void initialize() {
        colRef.setCellValueFactory(data -> data.getValue().refClientProperty().asObject());
        colNom.setCellValueFactory(data -> data.getValue().nomClientProperty());
        colEmail.setCellValueFactory(data -> data.getValue().emailProperty());
        colAdresse.setCellValueFactory(data -> data.getValue().adresseProperty());
        colTel.setCellValueFactory(data -> data.getValue().telProperty().asObject());

        loadClients();

        clientsTable.getSelectionModel().selectedItemProperty().addListener((obs, old, newSel) -> {
            if (newSel != null) {
                selectedClient = newSel;
                txtNom.setText(newSel.getNomClient());
                txtEmail.setText(newSel.getEmail());
                txtAdresse.setText(newSel.getAdresse());
                txtTel.setText(String.valueOf(newSel.getTel()));
            }
        });
    }

    private void loadClients() {
        clientsList.clear();
        String query = "SELECT refclient, nomclient, email, adresse, tel FROM client ORDER BY nomclient";
        try (Connection conn = DatabaseConnection.getConnection();
             ResultSet rs = conn.createStatement().executeQuery(query)) {
            while (rs.next()) {
                clientsList.add(new Client(
                        rs.getInt("refclient"),
                        rs.getString("nomclient"),
                        rs.getString("email"),
                        rs.getString("adresse"),
                        rs.getInt("tel")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger les clients.");
        }
        clientsTable.setItems(clientsList);
    }

    @FXML
    private void modifierClient() {
        if (selectedClient == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner un client.");
            return;
        }
        try {
            int tel = Integer.parseInt(txtTel.getText().trim());
            String query = "UPDATE client SET nomclient=?, email=?, adresse=?, tel=? WHERE refclient=?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, txtNom.getText().trim());
                ps.setString(2, txtEmail.getText().trim());
                ps.setString(3, txtAdresse.getText().trim());
                ps.setInt(4, tel);
                ps.setInt(5, selectedClient.getRefClient());
                int rows = ps.executeUpdate();
                if (rows > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Succès", "Client modifié avec succès !");
                    loadClients();
                }
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Le téléphone doit être un nombre valide.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de modifier le client.");
        }
    }

    @FXML
    private void supprimerClient() {
        if (selectedClient == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner un client.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Supprimer le client " + selectedClient.getNomClient() + " ?",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText(null);
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                String query = "DELETE FROM client WHERE refclient=?";
                try (Connection conn = DatabaseConnection.getConnection();
                     PreparedStatement ps = conn.prepareStatement(query)) {
                    ps.setInt(1, selectedClient.getRefClient());
                    ps.executeUpdate();
                    showAlert(Alert.AlertType.INFORMATION, "Supprimé", "Client supprimé avec succès.");
                    loadClients();
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de supprimer le client.");
                }
            }
        });
    }

    private void clearFields() {
        txtNom.clear(); txtEmail.clear(); txtAdresse.clear(); txtTel.clear();
        selectedClient = null;
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
