package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.models.Voucher;
import org.example.models.VoucherDAO;
import org.example.utils.Session;

import java.time.LocalDate;
import java.util.List;

public class ModifierVoucherController {

    @FXML private TableView<Voucher> tableVouchers;
    @FXML private TableColumn<Voucher, String>    colRefVoucher;
    @FXML private TableColumn<Voucher, String>    colRefDemande;
    @FXML private TableColumn<Voucher, Integer>   colValeur;
    @FXML private TableColumn<Voucher, LocalDate> colDateCreation;
    @FXML private TableColumn<Voucher, LocalDate> colDateExpiration;
    @FXML private TableColumn<Voucher, String>    colStatut;
    @FXML private TableColumn<Voucher, String>    colRefClient;

    @FXML private TextField txtValeur;
    @FXML private DatePicker dateExpirationPicker;
    @FXML private Label statutLabel;

    private final VoucherDAO voucherDAO = new VoucherDAO();
    private ObservableList<Voucher> voucherList;
    private Voucher selectedVoucher;

    @FXML
    public void initialize() {
        colRefVoucher.setCellValueFactory(v -> v.getValue().refVoucherProperty());
        colRefDemande.setCellValueFactory(v -> v.getValue().refDemandeProperty());
        colValeur.setCellValueFactory(v -> v.getValue().valeurProperty().asObject());
        colDateCreation.setCellValueFactory(v -> v.getValue().dateCreationProperty());
        colDateExpiration.setCellValueFactory(v -> v.getValue().dateExpirationProperty());
        colStatut.setCellValueFactory(v -> v.getValue().statutProperty());
        colRefClient.setCellValueFactory(v -> v.getValue().refClientProperty());

        // Colorer selon statut
        tableVouchers.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(Voucher item, boolean empty) {
                super.updateItem(item, empty);
                if (item == null || empty) {
                    setStyle("");
                } else switch (item.getStatut()) {
                    case "Actif"  -> setStyle("-fx-background-color: #dcfce7;");
                    case "Expiré" -> setStyle("-fx-background-color: #fee2e2;");
                    case "Payé"   -> setStyle("-fx-background-color: #dbeafe;");
                    default       -> setStyle("");
                }
            }
        });

        // Sélection dans la table → remplir le formulaire
        tableVouchers.getSelectionModel().selectedItemProperty().addListener((obs, old, newSel) -> {
            if (newSel != null) {
                selectedVoucher = newSel;
                txtValeur.setText(String.valueOf(newSel.getValeur()));
                dateExpirationPicker.setValue(newSel.getDateExpiration());
                if (statutLabel != null) {
                    statutLabel.setText(newSel.getStatut());
                    switch (newSel.getStatut()) {
                        case "Actif"  -> statutLabel.setStyle("-fx-text-fill: #059669; -fx-font-weight: 700;");
                        case "Expiré" -> statutLabel.setStyle("-fx-text-fill: #dc2626; -fx-font-weight: 700;");
                        case "Payé"   -> statutLabel.setStyle("-fx-text-fill: #2563eb; -fx-font-weight: 700;");
                        default       -> statutLabel.setStyle("-fx-text-fill: #64748b;");
                    }
                }
            }
        });

        // Marquer les expirés automatiquement
        voucherDAO.marquerExpires();

        loadVouchers();
        checkRole();
    }

    private void checkRole() {
        // Seuls SuperUser et Superviseur peuvent modifier/supprimer
        String role = Session.getUser() != null ? Session.getUser().getUserrole() : "";
        boolean canEdit = role.equals("SuperUser") || role.equals("Superviseur");
        if (txtValeur != null) txtValeur.setDisable(!canEdit);
        if (dateExpirationPicker != null) dateExpirationPicker.setDisable(!canEdit);
    }

    private void loadVouchers() {
        List<Voucher> data = voucherDAO.getAllVouchers();
        voucherList = FXCollections.observableArrayList(data);
        tableVouchers.setItems(voucherList);
    }

    @FXML
    private void modifierVoucher() {
        if (selectedVoucher == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner un voucher.");
            return;
        }
        if (!canUserEdit()) { showAlert(Alert.AlertType.ERROR, "Accès refusé", "Vous n'avez pas les droits pour modifier."); return; }

        try {
            int valeur = Integer.parseInt(txtValeur.getText().trim());
            LocalDate dateExp = dateExpirationPicker.getValue();
            if (dateExp == null) { showAlert(Alert.AlertType.WARNING, "Champ requis", "Veuillez choisir une date d'expiration."); return; }

            boolean ok = voucherDAO.updateVoucher(selectedVoucher.getRefVoucher(), valeur, dateExp);
            if (ok) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "Voucher modifié avec succès !");
                voucherDAO.marquerExpires();
                loadVouchers();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de modifier le voucher.");
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "La valeur doit être un nombre entier.");
        }
    }

    @FXML
    private void supprimerVoucher() {
        if (selectedVoucher == null) {
            showAlert(Alert.AlertType.WARNING, "Sélection requise", "Veuillez sélectionner un voucher.");
            return;
        }
        if (!canUserEdit()) { showAlert(Alert.AlertType.ERROR, "Accès refusé", "Vous n'avez pas les droits pour supprimer."); return; }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Supprimer le voucher " + selectedVoucher.getRefVoucher() + " ?",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText(null);
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                boolean ok = voucherDAO.deleteVoucher(selectedVoucher.getRefVoucher());
                if (ok) {
                    showAlert(Alert.AlertType.INFORMATION, "Supprimé", "Voucher supprimé avec succès.");
                    selectedVoucher = null;
                    txtValeur.clear();
                    dateExpirationPicker.setValue(null);
                    loadVouchers();
                } else {
                    showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de supprimer le voucher.");
                }
            }
        });
    }

    @FXML
    private void rafraichir() {
        voucherDAO.marquerExpires();
        loadVouchers();
    }

    private boolean canUserEdit() {
        String role = Session.getUser() != null ? Session.getUser().getUserrole() : "";
        return role.equals("SuperUser") || role.equals("Superviseur");
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
