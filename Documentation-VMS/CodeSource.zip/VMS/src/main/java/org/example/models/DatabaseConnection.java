package org.example.models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL      = "jdbc:postgresql://postgresql-groupeffa.alwaysdata.net:5432/groupeffa_voucher";
    private static final String USER     = "groupeffa";
    private static final String PASSWORD = "1234@Ad$ffA";

    /**
     * Ouvre et retourne une nouvelle connexion à la base de données.
     * Utiliser dans un try-with-resources pour fermeture automatique.
     */
    public static Connection getConnection() {
        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            return conn;
        } catch (SQLException e) {
            System.err.println("❌ Erreur de connexion à la base de données : " + e.getMessage());
            return null;
        }
    }
}
