<?php
session_start();

// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "vehicules");

if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Vérifier les identifiants dans la base de données
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Connexion réussie
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_name'] = $user['name'];
            
            // Rediriger vers la page d'accueil
            header("Location: index.php");
            exit();
        } else {
            // Mot de passe incorrect
            $_SESSION['error'] = "Mot de passe incorrect";
            header("Location: login.php");
            exit();
        }
    } else {
        // Email non trouvé
        $_SESSION['error'] = "Email non trouvé";
        header("Location: login.php");
        exit();
    }
}

$conn->close();
?> 