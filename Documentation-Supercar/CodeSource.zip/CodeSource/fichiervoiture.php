<?php
session_start();

// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "vehicules");
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

// Récupération des voitures depuis la base de données
$sql = "SELECT * FROM voitures";
$result = $conn->query($sql);

// Conversion des résultats en format JSON pour JavaScript
$voitures = array();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $voitures[] = array(
            'id' => $row['id'],
            'name' => $row['marque'] . ' ' . $row['modele'],
            'image' => !empty($row['image_url']) ? $row['image_url'] : 'image/default.png',
            'description' => $row['description'],
            'price' => floatval($row['prix']),
            'type' => $row['type'],
            'marque' => strtolower($row['marque']),
            'stats' => array(
                'puissance' => intval($row['puissance']),
                'vitesse_max' => intval($row['vitesse_max']),
                'acceleration' => floatval($row['acceleration']),
                'nitro' => floatval($row['nitro'])
            )
        );
    }
}

// Inclure le header
include 'header.php';
?>

<style>
    body {
        background-color: #f8f9fa;
        font-family: 'Lato', sans-serif;
    }

    .car-container {
        max-width: 1200px;
        margin: 50px auto;
        padding: 30px;
        background-color: white;
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 100px;
    }

    .car-title {
        color: #001f3d;
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        text-align: center;
        margin-bottom: 30px;
    }

    .car-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        padding: 20px;
    }

    .car-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
    }

    .car-card:hover {
        transform: translateY(-5px);
    }

    .car-image {
        width: 100%;
        height: 200px;
        object-fit: cover;
    }

    .car-info {
        padding: 20px;
    }

    .car-brand {
        color: #001f3d;
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        margin-bottom: 10px;
    }

    .car-model {
        color: #666;
        font-size: 1.1em;
        margin-bottom: 15px;
    }

    .car-price {
        color: #d4af37;
        font-weight: 600;
        font-size: 1.2em;
        margin-bottom: 15px;
    }

    .car-type {
        color: #666;
        font-size: 0.9em;
        margin-bottom: 15px;
    }

    .btn-primary {
        background-color: #d4af37;
        border: none;
        border-radius: 20px;
        padding: 10px 20px;
        color: white;
        font-weight: 600;
        transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #8b0000;
        color: white;
    }

    .filters {
        margin-bottom: 30px;
        padding: 20px;
        background-color: white;
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .filter-group {
        margin-bottom: 15px;
    }

    .filter-label {
        display: block;
        margin-bottom: 5px;
        color: #001f3d;
        font-weight: 600;
    }

    .filter-input {
        width: 100%;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    .stat-bar {
        width: 100%;
        position: relative;
        margin-bottom: 15px;
    }

    .stat-bar span {
        font-weight: bold;
        display: block;
    }

    .progress-bar {
        height: 20px;
        border-radius: 5px;
    }

    .progress-bar-label {
        position: absolute;
        top: 2px;
        left: 10px;
        color: white;
        font-weight: bold;
    }

    .filter-card {
        background-color: #ffffff;
        border-radius: 15px;
        padding: 20px;
        margin-right: 15px;
        margin-bottom: 30px;
        transition: transform 0.3s ease;
        flex: 1 1 23%;
    }

    .filter-button {
        background-color: #d4af37;
        color: white;
        padding: 10px 20px;
        width: 100%;
        font-weight: 600;
        text-transform: uppercase;
        transition: background-color 0.3s ease;
        border: none;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .filter-button i {
        margin-right: 10px;
    }

    .filter-button:hover {
        background-color: #8b0000;
    }

    .filter-button:active {
        transform: scale(0.98);
    }
</style>

<!-- Filtres -->
<div class="container">
    <div class="filters">
        <div class="row">
            <div class="col-md-3">
                <div class="filter-group">
                    <label class="filter-label">Marque</label>
                    <select id="brandFilter" class="filter-input">
                        <option value="">Tous</option>
                        <option value="bmw">BMW</option>
                        <option value="porsche">Porsche</option>
                        <option value="mercedes">Mercedes</option>
                    </select>
                </div>
            </div>

            <div class="col-md-3">
                <div class="filter-group">
                    <label class="filter-label">Prix</label>
                    <select id="priceFilter" class="filter-input">
                        <option value="">Tous</option>
                        <option value="0-50000">0€ - 50 000€</option>
                        <option value="50001-100000">50 001€ - 100 000€</option>
                        <option value="100001-150000">100 001€ - 150 000€</option>
                    </select>
                </div>
            </div>

            <div class="col-md-3">
                <div class="filter-group">
                    <label class="filter-label">Type de voiture</label>
                    <select id="typeFilter" class="filter-input">
                        <option value="">Tous</option>
                        <option value="SUV">SUV</option>
                        <option value="Coupé">Coupé</option>
                        <option value="Cabriolet">Cabriolet</option>
                        <option value="Sport">Sport</option>
                        <option value="Electric">Electric</option>
                        <option value="Compact">Compact</option>
                    </select>
                </div>
            </div>

            <div class="col-md-3">
                <div class="filter-card">
                    <button id="filterBtn" class="filter-button">
                        <i class="fas fa-search"></i> Rechercher
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Liste des voitures -->
<div class="container">
    <div class="car-container">
        <h2 class="car-title">Nos Véhicules</h2>
        <div class="car-grid" id="carList">
            <!-- Les voitures seront affichées ici via JavaScript -->
        </div>
    </div>
</div>

<script>
    // Modèles de voitures depuis la base de données
    const allCars = <?php echo json_encode($voitures); ?>;

    // Fonction pour afficher les voitures en fonction des filtres
    function showFilteredCars() {
        const carList = document.getElementById('carList');
        if (!carList) {
            console.error('Element carList non trouvé');
            return;
        }
        
        carList.innerHTML = ''; // Réinitialiser la liste des voitures

        const brandFilter = document.getElementById('brandFilter').value.toLowerCase();
        const priceFilter = document.getElementById('priceFilter').value;
        const typeFilter = document.getElementById('typeFilter').value.toLowerCase();

        let filteredCars = allCars;

        // Appliquer les filtres
        if (brandFilter || priceFilter || typeFilter) {
            filteredCars = allCars.filter(car => {
                let shouldInclude = true;

                // Filtrer selon la marque
                if (brandFilter) {
                    shouldInclude = shouldInclude && car.marque === brandFilter;
                }

                // Filtrer selon le prix
                if (priceFilter) {
                    const [minPrice, maxPrice] = priceFilter.split('-').map(Number);
                    const carPrice = parseFloat(car.price);
                    shouldInclude = shouldInclude && carPrice >= minPrice && carPrice <= maxPrice;
                }

                // Filtrer selon le type
                if (typeFilter) {
                    shouldInclude = shouldInclude && car.type.toLowerCase() === typeFilter;
                }

                return shouldInclude;
            });
        }

        // Affichage des voitures filtrées
        if (filteredCars.length === 0) {
            carList.innerHTML = '<div class="col-12 text-center"><p>Aucune voiture ne correspond à vos critères</p></div>';
            return;
        }

        filteredCars.forEach(car => {
            const carCard = document.createElement('div');
            carCard.className = 'car-card';
            carCard.innerHTML = `
                <img src="${car.image}" alt="${car.name}" class="car-image" onerror="this.src='image/default.png'">
                <div class="car-info">
                    <h3 class="car-brand">${car.name}</h3>
                    <p>${car.description}</p>
                    <p class="car-price">${car.price.toLocaleString('fr-FR')} €</p>
                    <p class="car-type">${car.type}</p>

                    <!-- Statistiques de la voiture -->
                    <div class="stat-bar">
                        <span>Puissance: ${car.stats.puissance} ch</span>
                        <div class="progress stat">
                            <div class="progress-bar" style="width: ${Math.min(car.stats.puissance / 10, 100)}%"></div>
                        </div>
                    </div>

                    <div class="stat-bar">
                        <span>Vitesse max: ${car.stats.vitesse_max} km/h</span>
                        <div class="progress stat">
                            <div class="progress-bar" style="width: ${Math.min(car.stats.vitesse_max / 3, 100)}%"></div>
                        </div>
                    </div>

                    <div class="stat-bar">
                        <span>Accélération: ${car.stats.acceleration} s</span>
                        <div class="progress stat">
                            <div class="progress-bar" style="width: ${Math.min((10 - car.stats.acceleration) * 10, 100)}%"></div>
                        </div>
                    </div>

                    <div class="stat-bar">
                        <span>Nitro: ${car.stats.nitro}</span>
                        <div class="progress stat">
                            <div class="progress-bar" style="width: ${Math.min(car.stats.nitro * 10, 100)}%"></div>
                        </div>
                    </div>

                    <a href="demande-essai.php?marque=${encodeURIComponent(car.marque)}&modele=${encodeURIComponent(car.name)}&type=${encodeURIComponent(car.type)}" class="btn btn-primary">Réserver un essai</a>
                </div>
            `;
            carList.appendChild(carCard);
        });
    }

    // Appliquer les filtres lors du clic sur le bouton
    document.getElementById('filterBtn').addEventListener('click', showFilteredCars);

    // Appliquer les filtres lors du changement de valeur des filtres
    document.getElementById('brandFilter').addEventListener('change', showFilteredCars);
    document.getElementById('priceFilter').addEventListener('change', showFilteredCars);
    document.getElementById('typeFilter').addEventListener('change', showFilteredCars);

    // Afficher toutes les voitures au départ
    document.addEventListener('DOMContentLoaded', function() {
        showFilteredCars();
    });
</script>

<?php
// Fermeture de la connexion
$conn->close();
?>
</body>
</html>