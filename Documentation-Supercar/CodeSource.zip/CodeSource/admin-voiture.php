<?php 
include 'header-admin.php'; 

// Connexion MySQL AlwaysData
$conn = new mysqli(
    "mysql-lorryc.alwaysdata.net",
    "lorryc",
    "Mauritius5516",
    "lorryc_vehicules"
);

if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

// Fonction pour gérer l'upload d'image
function uploadImage($file, $target_dir = "Image/") {
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $imageFileType = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
    $check = getimagesize($file["tmp_name"]);
    
    if ($check === false) return false;
    if ($file["size"] > 5000000) return false;
    if (!in_array($imageFileType, ["jpg", "png", "jpeg", "gif"])) return false;
    
    $new_filename = uniqid() . '.' . $imageFileType;
    $target_file = $target_dir . $new_filename;
    
    if (move_uploaded_file($file["tmp_name"], $target_file)) 
        return $target_file;
    return false;
}

// Traitement des actions CRUD
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $marque = $_POST['marque'];
                $modele = $_POST['modele'];
                $description = $_POST['description'];
                $prix = (int)$_POST['prix'];
                $type = $_POST['type'];
                $puissance = $_POST['puissance'];
                $vitesse_max = $_POST['vitesse_max'];
                $acceleration = $_POST['acceleration'];
                $nitro = $_POST['nitro'];
                $image_url = '';
                
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $image_url = uploadImage($_FILES['image']);
                }
                
                $query = "INSERT INTO voitures (marque, modele, description, prix, type, puissance, vitesse_max, acceleration, nitro, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sssisiiiss", $marque, $modele, $description, $prix, $type, $puissance, $vitesse_max, $acceleration, $nitro, $image_url);
                $stmt->execute();
                $_SESSION['message'] = "Voiture ajoutée avec succès.";
                break;

            case 'edit':
                $id = (int)$_POST['id'];
                $marque = $_POST['marque'];
                $modele = $_POST['modele'];
                $description = $_POST['description'];
                $type = $_POST['type'];
                $puissance = $_POST['puissance'];
                $vitesse_max = $_POST['vitesse_max'];
                $acceleration = $_POST['acceleration'];
                $nitro = $_POST['nitro'];
                $nouveau_prix = (int)$_POST['prix'];

                // ============================================================
                // RÈGLES MÉTIER SUR LE PRIX (CÔTÉ SERVEUR)
                // ============================================================
                // 1. Récupérer le prix INITIAL depuis la BDD
                $stmt_prix = $conn->prepare("SELECT prix FROM voitures WHERE id = ?");
                $stmt_prix->bind_param("i", $id);
                $stmt_prix->execute();
                $prix_initial = (int)$stmt_prix->get_result()->fetch_assoc()['prix'];
                $stmt_prix->close();

                // 2. Plafond = basé sur le prix INITIAL uniquement
                // 100000 * 1.20 = 120000 exact
                // 99999 * 1.20 = 119998.8 → floor = 119998
                $plafond_fixe = (int)floor($prix_initial * 1.20);

                // 3. Interdire la diminution du prix (par rapport au prix initial)
                if ($nouveau_prix < $prix_initial) {
                    $_SESSION['error'] = "❌ Modification refusée : le prix ne peut pas être inférieur au prix initial de " . number_format($prix_initial, 0, ',', ' ') . " €.";
                    echo "<script>window.location.href = 'admin-voiture.php';</script>";
                    exit();
                }

                // 4. Interdire un dépassement du plafond +20%
                if ($nouveau_prix > $plafond_fixe) {
                    $_SESSION['error'] = "❌ Augmentation refusée : le prix ne peut pas dépasser " . number_format($plafond_fixe, 0, ',', ' ') . " € " . "(+20% du prix initial de " . number_format($prix_initial, 0, ',', ' ') . " €).";
                    echo "<script>window.location.href = 'admin-voiture.php';</script>";
                    exit();
                }

                // ============================================================
                $prix = $nouveau_prix;
                $image_url = $_POST['current_image'];

                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $new_image_url = uploadImage($_FILES['image']);
                    if ($new_image_url) {
                        if ($image_url && file_exists($image_url)) 
                            unlink($image_url);
                        $image_url = $new_image_url;
                    }
                }

                $query = "UPDATE voitures SET marque=?, modele=?, description=?, prix=?, type=?, puissance=?, vitesse_max=?, acceleration=?, nitro=?, image_url=? WHERE id=?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sssisiiissi", $marque, $modele, $description, $prix, $type, $puissance, $vitesse_max, $acceleration, $nitro, $image_url, $id);
                $stmt->execute();
                $_SESSION['message'] = "Voiture modifiée avec succès.";
                break;

            case 'delete':
                $id = (int)$_POST['id'];
                $stmt = $conn->prepare("SELECT image_url FROM voitures WHERE id=?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $row = $stmt->get_result()->fetch_assoc();
                
                if ($row['image_url'] && file_exists($row['image_url'])) 
                    unlink($row['image_url']);
                
                $stmt2 = $conn->prepare("DELETE FROM voitures WHERE id=?");
                $stmt2->bind_param("i", $id);
                $stmt2->execute();
                $_SESSION['message'] = "Voiture supprimée avec succès.";
                break;
        }
        echo "<script>window.location.href = 'admin-voiture.php';</script>";
        exit();
    }
}

// Afficher message succès
if (isset($_SESSION['message'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert"> ' . $_SESSION['message'] . ' <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> </div>';
    unset($_SESSION['message']);
}

// Afficher message erreur
if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"> ' . $_SESSION['error'] . ' <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> </div>';
    unset($_SESSION['error']);
}

// Récupération des voitures
$result = $conn->query("SELECT * FROM voitures ORDER BY marque, modele");
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Gestion des Voitures</h2>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addVoitureModal">
            <i class="fas fa-plus"></i> Ajouter une voiture
        </button>
    </div>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Marque</th>
                    <th>Modèle</th>
                    <th>Prix initial</th>
                    <th>Plafond (+20%)</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()):
                    $prix_initial_row = (int)$row['prix'];
                    $plafond_fixe_row = (int)floor($prix_initial_row * 1.20);
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td>
                        <?php if ($row['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($row['image_url']); ?>" style="max-width:100px;">
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['marque']); ?></td>
                    <td><?php echo htmlspecialchars($row['modele']); ?></td>
                    <td><?php echo number_format($prix_initial_row, 0, ',', ' '); ?> €</td>
                    <td class="text-warning font-weight-bold">
                        <?php echo number_format($plafond_fixe_row, 0, ',', ' '); ?> €
                    </td>
                    <td><?php echo htmlspecialchars($row['type']); ?></td>
                    <td>
                        <button class="btn btn-sm btn-info edit-btn"
                                data-id="<?php echo $row['id']; ?>"
                                data-marque="<?php echo htmlspecialchars($row['marque']); ?>"
                                data-modele="<?php echo htmlspecialchars($row['modele']); ?>"
                                data-description="<?php echo htmlspecialchars($row['description']); ?>"
                                data-prix="<?php echo $prix_initial_row; ?>"
                                data-plafond="<?php echo $plafond_fixe_row; ?>"
                                data-type="<?php echo htmlspecialchars($row['type']); ?>"
                                data-puissance="<?php echo $row['puissance']; ?>"
                                data-vitesse="<?php echo $row['vitesse_max']; ?>"
                                data-acceleration="<?php echo $row['acceleration']; ?>"
                                data-nitro="<?php echo $row['nitro']; ?>"
                                data-image="<?php echo htmlspecialchars($row['image_url']); ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo $row['id']; ?>">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Ajout -->
<div class="modal fade" id="addVoitureModal" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une voiture</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label>Marque</label>
                        <input type="text" class="form-control" name="marque" required>
                    </div>
                    <div class="form-group">
                        <label>Modèle</label>
                        <input type="text" class="form-control" name="modele" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" name="description" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Prix</label>
                        <input type="number" class="form-control" name="prix" step="1" min="0" required>
                    </div>
                    <div class="form-group">
                        <label>Type</label>
                        <input type="text" class="form-control" name="type" required>
                    </div>
                    <div class="form-group">
                        <label>Puissance (ch)</label>
                        <input type="number" class="form-control" name="puissance" required>
                    </div>
                    <div class="form-group">
                        <label>Vitesse max (km/h)</label>
                        <input type="number" class="form-control" name="vitesse_max" required>
                    </div>
                    <div class="form-group">
                        <label>Accélération (0-100 km/h)</label>
                        <input type="number" class="form-control" name="acceleration" step="0.1" required>
                    </div>
                    <div class="form-group">
                        <label>Nitro</label>
                        <input type="number" class="form-control" name="nitro" step="0.1" required>
                    </div>
                    <div class="form-group">
                        <label>Image</label>
                        <input type="file" class="form-control-file" name="image" accept="image/*" required>
                        <small class="form-text text-muted">JPG, PNG, JPEG, GIF — max 5MB</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Ajouter</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Modification -->
<div class="modal fade" id="editVoitureModal" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une voiture</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="editForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" id="edit_id">
                    <input type="hidden" name="current_image" id="edit_current_image">
                    <!-- ✅ Champs cachés pour stocker les valeurs FIXES -->
                    <input type="hidden" id="edit_prix_initial">
                    <input type="hidden" id="edit_plafond_fixe">

                    <div class="form-group">
                        <label>Marque</label>
                        <input type="text" class="form-control" name="marque" id="edit_marque" required>
                    </div>
                    <div class="form-group">
                        <label>Modèle</label>
                        <input type="text" class="form-control" name="modele" id="edit_modele" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" name="description" id="edit_description" required></textarea>
                    </div>

                    <div class="form-group">
                        <label>Prix</label>
                        <input type="number" class="form-control" name="prix" id="edit_prix" step="1" required>
                        <small id="prix_info" class="form-text text-muted"></small>
                        <div id="prix_alerte" class="alert alert-danger mt-2" style="display:none;"></div>
                    </div>

                    <div class="form-group">
                        <label>Type</label>
                        <input type="text" class="form-control" name="type" id="edit_type" required>
                    </div>
                    <div class="form-group">
                        <label>Puissance (ch)</label>
                        <input type="number" class="form-control" name="puissance" id="edit_puissance" required>
                    </div>
                    <div class="form-group">
                        <label>Vitesse max (km/h)</label>
                        <input type="number" class="form-control" name="vitesse_max" id="edit_vitesse" required>
                    </div>
                    <div class="form-group">
                        <label>Accélération (0-100 km/h)</label>
                        <input type="number" class="form-control" name="acceleration" id="edit_acceleration" step="0.1" required>
                    </div>
                    <div class="form-group">
                        <label>Nitro</label>
                        <input type="number" class="form-control" name="nitro" id="edit_nitro" step="0.1" required>
                    </div>
                    <div class="form-group">
                        <label>Image actuelle</label>
                        <div id="edit_current_image_preview"></div>
                    </div>
                    <div class="form-group">
                        <label>Nouvelle image (optionnel)</label>
                        <input type="file" class="form-control-file" name="image" accept="image/*">
                        <small class="form-text text-muted">JPG, PNG, JPEG, GIF — max 5MB</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary" id="btn_submit_edit">Modifier</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Suppression -->
<div class="modal fade" id="deleteVoitureModal" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmer la suppression</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div class="modal-body">
                <p>Êtes-vous sûr de vouloir supprimer cette voiture ?</p>
            </div>
            <div class="modal-footer">
                <form method="POST">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="delete_id">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-danger">Supprimer</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        // ✅ Ouverture du modal d'édition
        $('.edit-btn').click(function () {
            var prixInitial = parseInt($(this).data('prix'));      // Prix INITIAL (fixe)
            var plafondFixe = parseInt($(this).data('plafond'));   // Plafond FIXE (ne change jamais)

            $('#edit_id').val($(this).data('id'));
            $('#edit_marque').val($(this).data('marque'));
            $('#edit_modele').val($(this).data('modele'));
            $('#edit_description').val($(this).data('description'));
            
            // ✅ Stocker les valeurs FIXES
            $('#edit_prix_initial').val(prixInitial);
            $('#edit_plafond_fixe').val(plafondFixe);
            
            // Afficher le prix initial dans l'input
            $('#edit_prix').val(prixInitial);
            
            $('#edit_type').val($(this).data('type'));
            $('#edit_puissance').val($(this).data('puissance'));
            $('#edit_vitesse').val($(this).data('vitesse'));
            $('#edit_acceleration').val($(this).data('acceleration'));
            $('#edit_nitro').val($(this).data('nitro'));
            
            // ✅ Afficher l'information de prix avec VALEURS FIXES
            $('#prix_info').text(
                'Prix initial : ' + prixInitial.toLocaleString('fr-FR') + ' €' +
                ' | Minimum : ' + prixInitial.toLocaleString('fr-FR') + ' €' +
                ' | Maximum autorisé (+20%) : ' + plafondFixe.toLocaleString('fr-FR') + ' €'
            );
            
            $('#prix_alerte').hide();
            $('#btn_submit_edit').prop('disabled', false);
            
            var imageUrl = $(this).data('image');
            $('#edit_current_image').val(imageUrl);
            $('#edit_current_image_preview').html(
                imageUrl ? '<img src="' + imageUrl + '" alt="Voiture" style="max-width:200px;">' : '<p>Aucune image</p>'
            );
            
            $('#editVoitureModal').modal('show');
        });

        // ✅ Vérification en temps réel — utilise les VALEURS FIXES
        $('#edit_prix').on('input', function () {
            var prixInitial = parseInt($('#edit_prix_initial').val());    // FIXE
            var plafondFixe = parseInt($('#edit_plafond_fixe').val());    // FIXE
            var nouveauPrix = parseInt($(this).val());

            if (isNaN(nouveauPrix)) {
                $('#prix_alerte').hide();
                $('#btn_submit_edit').prop('disabled', true);
                return;
            }

            if (nouveauPrix < prixInitial) {
                $('#prix_alerte').text('⚠️ Impossible de diminuer le prix. Minimum : ' + prixInitial.toLocaleString('fr-FR') + ' €').show();
                $('#btn_submit_edit').prop('disabled', true);
                $(this).addClass('is-invalid');
            } else if (nouveauPrix > plafondFixe) {
                $('#prix_alerte').text('⚠️ Prix trop élevé ! Maximum autorisé : ' + plafondFixe.toLocaleString('fr-FR') + ' € (+20%)').show();
                $('#btn_submit_edit').prop('disabled', true);
                $(this).addClass('is-invalid');
            } else {
                $('#prix_alerte').hide();
                $('#btn_submit_edit').prop('disabled', false);
                $(this).removeClass('is-invalid');
            }
        });

        // ✅ Vérification finale avant soumission — utilise les VALEURS FIXES
        $('#editForm').on('submit', function (e) {
            var prixInitial = parseInt($('#edit_prix_initial').val());    // FIXE
            var plafondFixe = parseInt($('#edit_plafond_fixe').val());    // FIXE
            var nouveauPrix = parseInt($('#edit_prix').val());

            if (nouveauPrix < prixInitial) {
                e.preventDefault();
                alert('Modification refusée : le prix ne peut pas être inférieur à ' + prixInitial.toLocaleString('fr-FR') + ' €.');
            } else if (nouveauPrix > plafondFixe) {
                e.preventDefault();
                alert('Modification refusée : le prix ne peut pas d��passer ' + plafondFixe.toLocaleString('fr-FR') + ' € (+20%).');
            }
        });

        // Suppression
        $('.delete-btn').click(function () {
            $('#delete_id').val($(this).data('id'));
            $('#deleteVoitureModal').modal('show');
        });
    });
</script>

</body>
</html>