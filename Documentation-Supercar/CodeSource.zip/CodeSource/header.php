<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supercar - Vente de Voitures de Luxe</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&family=Lato:wght@400&family=Playfair+Display:wght@400&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* Navbar container */
        .navbar {
            background-color: #001f3d; /* Bleu nuit */
            transition: all 0.3s ease-in-out;
        }

        /* Centre les éléments de la navbar */
        .navbar-nav.mx-auto {
            display: flex;
            justify-content: center;
            flex-grow: 1;
        }

        /* Le logo s'adapte à la taille de la navbar */
        .navbar-logo {
            max-height: 150px;
            width: auto;
            transition: transform 0.3s ease-in-out;
        }

        /* Animation de survol du logo */
        .navbar-logo:hover {
            transform: scale(1.1);
        }

        /* Style des liens */
        .navbar-nav .nav-link {
            color: white;
            font-size: 16px;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            letter-spacing: 1px;
            transition: color 0.3s ease, transform 0.3s ease;
        }

        /* Animation au survol des liens */
        .navbar-nav .nav-link:hover {
            color: #d4af37; /* Or métallique */
            transform: translateY(-5px); /* Légère élévation */
        }

        /* Effet sur la barre de recherche */
        .search-input {
            width: 200px;
            border-radius: 20px;
            padding: 5px 15px;
            transition: width 0.5s ease, opacity 0.5s ease;
        }

        .search-input:focus {
            width: 250px;
            opacity: 1;
        }

        .btn-search {
            background-color: #d4af37; /* Couleur or métallique */
            color: white;
            border: none;
            border-radius: 20px;
            padding: 0 15px;
            height: 38px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-search i {
            font-size: 18px;
        }

        /* Style pour le nom de l'utilisateur et le lien de déconnexion */
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-name {
            color: #d4af37;
            font-weight: 600;
            margin-right: 15px;
        }

        .user-icon {
            color: #d4af37;
            font-size: 1.2em;
        }

        /* Animation du bouton hamburger */
        .navbar-toggler-icon {
            background-color: #d4af37;
            transition: transform 0.3s ease;
        }

        .navbar-toggler.collapsed .navbar-toggler-icon {
            transform: rotate(90deg);
        }

        /* Ajout de la transition de la navbar */
        .navbar-scrolled {
            background-color: #d4af37; /* Or métallique */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="index.php">
            <img src="image/Logo.png" alt="Logo" class="navbar-logo">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                    <a class="nav-link" href="index.php">Accueil</a>
                </li>
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'fichiervoiture.php' ? 'active' : ''; ?>">
                    <a class="nav-link" href="fichiervoiture.php">Voitures</a>
                </li>
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'service.php' ? 'active' : ''; ?>">
                    <a class="nav-link" href="service.php">Services</a>
                </li>
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'fichieressai.php' ? 'active' : ''; ?>">
                    <a class="nav-link" href="fichieressai.php">Demande d'essai</a>
                </li>

                <!-- Barre de recherche -->
                <!--<li class="nav-item">
                    <div class="input-group mx-3">
                        <input type="text" class="form-control search-input" placeholder="Rechercher une voiture">
                        <div class="input-group-append">
                            <button class="btn btn-search" type="button">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>x
                    </div>
                </li>-->
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : ''; ?>">
                    <a class="nav-link" href="contact.php">Contactez nous</a>
                </li>
            </ul>
            <!-- Section utilisateur -->
            <ul class="navbar-nav">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <div class="user-info">
                            <i class="fas fa-user user-icon"></i>
                            <span class="user-name"><?php echo htmlspecialchars($_SESSION['user_prenom']); ?></span>
                            <a class="nav-link" href="logout.php">Se déconnecter</a>
                        </div>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Se connecter</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <script>
        // Animation de la navbar au scroll
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                document.querySelector('.navbar').classList.add('navbar-scrolled');
            } else {
                document.querySelector('.navbar').classList.remove('navbar-scrolled');
            }
        });
    </script>
</body>
</html> 