<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    exit();
}

// Connexion à la base de données
require 'bdconnect.php'; // Assurez-vous que ce fichier existe

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer les données du formulaire
    $user_id = $_SESSION['user_id']; // ID de l'utilisateur connecté
    $marque = $_POST['brand'];
    $modele = $_POST['carModel'];
    $date_essai = $_POST['testDate'];
    $heure_essai = $_POST['testTime'];
    $lieu_essai = $_POST['location'];
    $commentaire = $_POST['comments'];

    // Préparer la requête d'insertion
    $stmt = $pdo->prepare("INSERT INTO demandes_essai (user_id, marque, modele, date_essai, heure_essai, lieu_essai, commentaire) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bindParam(1, $user_id);
    $stmt->bindParam(2, $marque);
    $stmt->bindParam(3, $modele);
    $stmt->bindParam(4, $date_essai);
    $stmt->bindParam(5, $heure_essai);
    $stmt->bindParam(6, $lieu_essai);
    $stmt->bindParam(7, $commentaire);

    // Exécuter la requête
    if ($stmt->execute()) {
        // Rediriger vers une page de confirmation ou afficher un message de succès
        header("Location: confirmation_demande.php"); // Redirection vers la page de confirmation
        exit();
    } else {
        $error = "Une erreur est survenue lors de la soumission de votre demande.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation de la demande</title>
</head>
<body>
    <h1>Demande d'essai</h1>

    <?php if (isset($error)) { echo "<p>$error</p>"; } ?>

    <p>Votre demande d'essai a été envoyée avec succès.</p>

    <p><a href="voiture.php">Retour à la page des voitures</a></p>
</body>
</html>
