<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'fichieressai.php';
    header('Location: login.php');
    exit;
}

// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Variables pour stocker les messages
$error = null;
$success = null;

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Récupération des données du formulaire
        $user_id = $_SESSION['user_id'];
        $marque = $_POST['carBrand'];
        $modele = $_POST['carModel'];
        $date_essai = $_POST['testDate'];
        $heure_essai = $_POST['testTime'];
        $lieu_essai = $_POST['location'];
        $commentaire = isset($_POST['comments']) ? $_POST['comments'] : '';

        // Vérifier si une demande existe déjà pour cette date et heure
        $check_query = "SELECT id FROM demandes_essai WHERE date_essai = ? AND heure_essai = ?";
        if (!($check_stmt = $mysqli->prepare($check_query))) {
            throw new Exception("Erreur de préparation de la requête: " . $mysqli->error);
        }
        
        $check_stmt->bind_param("ss", $date_essai, $heure_essai);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows > 0) {
            throw new Exception("Un essai est déjà prévu à cette date et heure. Veuillez choisir un autre créneau.");
        }
        $check_stmt->close();

        // Insérer la demande d'essai
        $insert_query = "INSERT INTO demandes_essai (user_id, marque, modele, date_essai, heure_essai, lieu_essai, commentaire) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        if (!($insert_stmt = $mysqli->prepare($insert_query))) {
            throw new Exception("Erreur de préparation de la requête d'insertion: " . $mysqli->error);
        }

        $insert_stmt->bind_param("issssss", $user_id, $marque, $modele, $date_essai, $heure_essai, $lieu_essai, $commentaire);
        
        if (!$insert_stmt->execute()) {
            throw new Exception("Erreur lors de l'insertion: " . $insert_stmt->error);
        }

        $success = "Votre demande d'essai a été enregistrée avec succès!";
        $insert_stmt->close();

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Récupération des voitures
$voitures_query = "SELECT DISTINCT marque, modele FROM voitures ORDER BY marque, modele";
$voitures_result = $mysqli->query($voitures_query);

if (!$voitures_result) {
    die("Erreur lors de la récupération des voitures: " . $mysqli->error);
}

$voitures = [];
while ($row = $voitures_result->fetch_assoc()) {
    if (!isset($voitures[$row['marque']])) {
        $voitures[$row['marque']] = [];
    }
    $voitures[$row['marque']][] = [
        'modele' => $row['modele']
    ];
}

// Inclure le header après tout le traitement
include 'header.php';
?>

<!-- Afficher les messages de succès ou d'erreur -->
<?php if ($success): ?>
    <div class="success-message">
        <?php echo $success; ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="error-message">
        <?php echo $error; ?>
    </div>
<?php endif; ?>

<script>
// Données des voitures récupérées de la base de données
const voituresData = <?php echo json_encode($voitures); ?>;

function updateModelOptions() {
    const brand = document.getElementById('carBrand').value;
    const modelSelect = document.getElementById('carModel');
    modelSelect.innerHTML = '<option value="" disabled selected>Sélectionner un modèle</option>';
    
    if (brand && voituresData[brand]) {
        voituresData[brand].forEach(voiture => {
            const option = document.createElement('option');
            option.value = voiture.id; // On utilise l'ID de la voiture comme valeur
            option.innerText = voiture.modele;
            modelSelect.appendChild(option);
        });
    }
}

document.querySelector('form').addEventListener('submit', function(e) {
    const date = document.getElementById('testDate').value;
    const time = document.getElementById('testTime').value;
    const today = new Date();
    const selectedDate = new Date(date);

    // Vérifier si la date est dans le passé
    if (selectedDate < today) {
        e.preventDefault();
        alert('Veuillez sélectionner une date future pour l\'essai.');
        return;
    }

    // Vérifier si une marque et un modèle sont sélectionnés
    const marque = document.getElementById('carBrand').value;
    const modele = document.getElementById('carModel').value;
    if (!marque || !modele) {
        e.preventDefault();
        alert('Veuillez sélectionner une marque et un modèle de voiture.');
        return;
    }
});
</script>

<style>
    body {
        background-image: url('Image/bg-essai.png');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        font-family: 'Lato', sans-serif;
    }

    .container {
        max-width: 600px;
        margin: 50px auto;
        padding: 30px;
    }

    .form-container {
        background-color: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        margin-bottom: 100px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        padding: 30px;
    }

    h1, .text-center {
        color: white;
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        text-align: center;
        margin-bottom: 30px;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
    }

    .form-group {
        margin-bottom: 20px;
    }

    label {
        color: white;
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
    }

    .form-control, select, textarea {
        width: 100%;
        padding: 12px 20px;
        border-radius: 20px;
        border: 2px solid rgba(255, 255, 255, 0.2);
        background-color: rgba(255, 255, 255, 0.1);
        color: white;
        backdrop-filter: blur(5px);
        transition: all 0.3s ease;
    }

    .form-control:focus, select:focus, textarea:focus {
        border-color: #d4af37;
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.25);
        outline: none;
    }

    select option {
        background-color: rgba(0, 31, 61, 0.9);
        color: white;
    }

    .btn-reserver {
        background-color: #d4af37;
        color: white;
        border: none;
        border-radius: 20px;
        padding: 12px 30px;
        width: 100%;
        font-weight: 600;
        text-transform: uppercase;
        transition: background-color 0.3s ease;
        margin-top: 20px;
    }

    .btn-reserver:hover {
        background-color: #8b0000;
        color: white;
    }

    /* Style pour les messages d'erreur et de succès */
    .error-message, .success-message {
        color: white;
        text-align: center;
        margin-bottom: 20px;
        padding: 10px;
        border-radius: 10px;
        backdrop-filter: blur(5px);
    }

    .error-message {
        background-color: rgba(220, 53, 69, 0.2);
        border: 1px solid rgba(220, 53, 69, 0.3);
    }

    .success-message {
        background-color: rgba(40, 167, 69, 0.2);
        border: 1px solid rgba(40, 167, 69, 0.3);
    }

    /* Adaptation pour la grille existante */
    .grid {
        display: grid;
        gap: 20px;
    }

    .grid-cols-2 {
        grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 768px) {
        .grid-cols-2 {
            grid-template-columns: 1fr;
        }
    }

    /* Ajustement des listes déroulantes */
    select.form-control {
        height: 50px; /* Augmentation de la hauteur */
        padding: 12px 20px;
        font-size: 16px; /* Taille de police plus lisible */
        line-height: 1.5;
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 15px center;
        background-size: 15px;
        padding-right: 40px; /* Espace pour la flèche */
    }

    /* Style pour les options du select */
    select.form-control option {
        padding: 12px;
        font-size: 16px;
        background-color: rgba(0, 31, 61, 0.95); /* Fond plus foncé pour meilleure lisibilité */
        color: white;
    }

    /* Ajustement au survol des options */
    select.form-control option:hover {
        background-color: rgba(212, 175, 55, 0.8);
    }

    /* Style spécifique pour le placeholder du select */
    select.form-control option[value=""][disabled] {
        color: rgba(255, 255, 255, 0.5);
    }

    /* Amélioration de la visibilité du texte sélectionné */
    select.form-control {
        color: white;
        font-weight: 500;
        text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
    }
</style>

<div class="container">
    <div class="form-container">
        <h1>Réservez votre essai</h1>
        <p class="text-center">Remplissez ce formulaire pour réserver un essai de voiture personnalisé.</p>

        <form action="" method="POST" class="space-y-6">
            <div class="form-group">
                <label for="carBrand">Marque</label>
                <select id="carBrand" name="carBrand" class="form-control" required onchange="updateModelOptions()">
                    <option value="" disabled selected>Sélectionner une marque</option>
                    <?php foreach (array_keys($voitures) as $marque): ?>
                        <option value="<?php echo $marque; ?>"><?php echo $marque; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="carModel">Modèle de voiture</label>
                <select id="carModel" name="carModel" class="form-control" required>
                    <option value="" disabled selected>Sélectionner un modèle</option>
                </select>
            </div>

            <div class="grid grid-cols-2 gap-6">
                <div class="form-group">
                    <label for="testDate">Date de l'essai</label>
                    <input type="date" id="testDate" name="testDate" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="testTime">Heure de l'essai</label>
                    <input type="time" id="testTime" name="testTime" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label for="location">Lieu de l'essai</label>
                <select id="location" name="location" class="form-control" required>
                    <option value="Port Louis">Port Louis</option>
                    <option value="Beau bassin">Beau bassin</option>
                    <option value="Quatre Bornes">Quatre Bornes</option>
                </select>
            </div>

            <div class="form-group">
                <label for="comments">Commentaire supplémentaire</label>
                <textarea id="comments" name="comments" rows="4" class="form-control" placeholder="Si vous avez des demandes particulières"></textarea>
            </div>

            <div class="form-group">
                <button type="submit" class="btn-reserver">
                    Réserver mon essai
                </button>
            </div>
        </form>
    </div>
</div>

