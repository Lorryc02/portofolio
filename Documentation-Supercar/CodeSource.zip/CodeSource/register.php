<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Connexion à la base de données
    $mysqli = new mysqli("localhost", "root", "", "vehicules");
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    // Récupérer les données du formulaire
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = "client"; // Par défaut, le rôle est "client"

    // Insérer l'utilisateur dans la base de données
    $stmt = $mysqli->prepare("INSERT INTO users (email, mot_de_passe, role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $password, $role);
    if ($stmt->execute()) {
        header("Location: Login.php"); // Rediriger vers la page de connexion
        exit();
    } else {
        $error = "Une erreur est survenue. Veuillez réessayer.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
</head>
<body>
    <form method="POST" action="register.php">
        <label for="email">Email :</label>
        <input type="email" name="email" required>
        <label for="password">Mot de passe :</label>
        <input type="password" name="password" required>
        <button type="submit">S'inscrire</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>
