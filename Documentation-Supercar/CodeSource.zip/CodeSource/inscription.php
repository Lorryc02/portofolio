<?php
session_start();

// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Traitement du formulaire d'inscription
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $numero = $_POST['numero'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Vérifier si les mots de passe correspondent
    if ($password !== $confirm_password) {
        $error = "Les mots de passe ne correspondent pas.";
    } else {
        // Vérifier si l'email existe déjà
        $stmt = $mysqli->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = "Cet email est déjà utilisé.";
        } else {
            // Hasher le mot de passe
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insérer le nouvel utilisateur
            $stmt = $mysqli->prepare("INSERT INTO users (nom, prenom, email, numero, mot_de_passe) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $nom, $prenom, $email, $numero, $hashed_password);
            
            if ($stmt->execute()) {
                $_SESSION['success'] = "Inscription réussie ! Vous pouvez maintenant vous connecter.";
                header("Location: login.php");
                exit();
            } else {
                $error = "Erreur lors de l'inscription.";
            }
        }
        $stmt->close();
    }
}

// Inclure le header
include 'header.php';
?>

<style>
    body {
        background-image: url('Image/bg-inscri.webp');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        font-family: 'Lato', sans-serif;
    }

    .register-container {
        max-width: 400px;
        margin: 50px auto;
        padding: 30px;
        background-color: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        margin-bottom: 100px;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .register-title {
        color: white;
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        text-align: center;
        margin-bottom: 30px;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
    }

    .form-control {
        border-radius: 20px;
        padding: 12px 20px;
        margin-bottom: 20px;
        border: 2px solid #e9ecef;
    }

    .form-control:focus {
        border-color: #d4af37;
        box-shadow: none;
    }

    .btn-register {
        background-color: #d4af37;
        color: white;
        border: none;
        border-radius: 20px;
        padding: 12px 30px;
        width: 100%;
        font-weight: 600;
        text-transform: uppercase;
        transition: background-color 0.3s ease;
    }

    .btn-register:hover {
        background-color: #8b0000;
        color: white;
    }

    .login-link {
        text-align: center;
        margin-top: 20px;
    }

    .login-link a {
        color: #d4af37;
        text-decoration: none;
    }

    .login-link a:hover {
        color: #8b0000;
    }

    .error-message {
        color: #dc3545;
        text-align: center;
        margin-bottom: 20px;
    }

    .footer {
        background-color: #001f3d;
        color: white;
        padding: 20px 0;
        position: fixed;
        bottom: 0;
        width: 100%;
        z-index: 1000;
    }

    .footer .social-icons a {
        color: white;
        margin-right: 10px;
        font-size: 20px;
    }
</style>

<!-- Formulaire d'inscription -->
<div class="container">
    <div class="register-container">
        <h2 class="register-title">Inscription</h2>
        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label>Nom</label>
                <input type="text" class="form-control" name="nom" required>
            </div>
            <div class="form-group">
                <label>Prénom</label>
                <input type="text" class="form-control" name="prenom" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="form-group">
                <label>Numéro de téléphone</label>
                <input type="tel" class="form-control" name="numero" required>
            </div>
            <div class="form-group">
                <label>Mot de passe</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <div class="form-group">
                <label>Confirmer le mot de passe</label>
                <input type="password" class="form-control" name="confirm_password" required>
            </div>
            <button type="submit" class="btn btn-register">S'inscrire</button>
        </form>
        <div class="login-link">
            <p>Déjà un compte ? <a href="login.php">Connectez-vous</a></p>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="footer text-center">
    <div class="container">
        <p>&copy; Supercar. Tous droits réservés.</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>