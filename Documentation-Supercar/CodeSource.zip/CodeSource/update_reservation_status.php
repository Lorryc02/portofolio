<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Vérification de la session
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['error' => 'Accès non autorisé']);
    exit();
}

// Vérification des données POST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id']) && isset($_POST['status'])) {
    $mysqli = new mysqli("localhost", "root", "", "vehicules");
    
    if ($mysqli->connect_error) {
        echo json_encode(['error' => 'Erreur de connexion à la base de données']);
        exit();
    }
    
    $id = intval($_POST['id']);
    $status = $_POST['status'];
    
    // Vérification du statut valide
    if (!in_array($status, ['confirmee', 'annulee', 'en_attente'])) {
        echo json_encode(['error' => 'Statut invalide']);
        exit();
    }
    
    $query = "UPDATE reservations_services SET statut = ? WHERE id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("si", $status, $id);
    
    if ($stmt->execute()) {
        echo 'success';
    } else {
        echo json_encode(['error' => 'Erreur lors de la mise à jour']);
    }
    
    $mysqli->close();
} else {
    echo json_encode(['error' => 'Paramètres manquants']);
}
?> 