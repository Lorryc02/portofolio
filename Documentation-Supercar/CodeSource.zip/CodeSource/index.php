<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'header.php';
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vente de Voitures - Page d'Accueil</title>
    <!-- Lien vers les polices -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&family=Lato:wght@400&family=Playfair+Display:wght@400&display=swap" rel="stylesheet">
    
    <!-- Lien vers le CSS de Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Lien vers FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* Styles personnalisés */
        body {
            font-family: 'Lato', sans-serif;
            background-color: #e1e1e1;
            color: #001f3d;
        }

        h1, h2, h3 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
        }

        blockquote {
            font-family: 'Playfair Display', serif;
            font-style: italic;
            color: #8b0000;
        }

        .hero-section {
            position: relative;
            width: 100%;
            height: 100vh;
            overflow: hidden;
        }

        .hero-section video {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }

        .hero-content {
            position: relative;
            z-index: 1;
            text-align: center;
            color: white;
            padding: 80px 0;
            opacity: 0;
            animation: fadeIn 2s forwards;
        }




.feature-block:hover {
    transform: scale(1.05);
}

.feature-icon {
    font-size: 40px;
    margin-bottom: 10px;
}
.service-card {
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    background-color: #f8f9fa;
    transition: transform 0.3s ease-in-out;
    margin-bottom: 30px;
}

.service-card:hover {
    transform: scale(1.05);
}

.service-card img {
    border-radius: 10px 10px 0 0;
    height: 200px;
    object-fit: cover;
}

.service-card .btn {
    background-color: #d4af37;
    color: white;
    padding: 10px 20px;
    border-radius: 20px;
    text-transform: uppercase;
    font-weight: bold;
}

.service-card .btn:hover {
    background-color: #8b0000;
}


        .testimonial-section {
            background-color: #f8f9fa;
            padding: 60px 0;
        }

        .testimonial-card {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            padding: 20px;
            background-color: white;
        }

        .footer {
            background-color: #001f3d;
            color: white;
            padding: 20px 0;
        }

        .footer .social-icons a {
            color: white;
            margin-right: 10px;
            font-size: 20px;
        }

        .search-input {
            width: 200px;
            border-radius: 20px;
            padding: 5px 15px;
        }

        .search-icon {
            position: absolute;
            right: 10px;
            top: 5px;
            color: #007bff;
        }

       /* Navbar container */
.navbar {
    background-color: #001f3d; /* Bleu nuit */
    transition: all 0.3s ease-in-out;
}

/* Centre les éléments de la navbar */
.navbar-nav.mx-auto {
    display: flex;
    justify-content: center;
    flex-grow: 1;
}

/* Le logo s'adapte à la taille de la navbar */
.navbar-logo {
    max-height: 150px;
    width: auto;
    transition: transform 0.3s ease-in-out;
}

/* Animation de survol du logo */
.navbar-logo:hover {
    transform: scale(1.1);
}

/* Style des liens */
.navbar-nav .nav-link {
    color: white;
    font-size: 16px;
    font-family: 'Montserrat', sans-serif;
    font-weight: 600;
    letter-spacing: 1px;
    transition: color 0.3s ease, transform 0.3s ease;
}

/* Animation au survol des liens */
.navbar-nav .nav-link:hover {
    color: #d4af37; /* Or métallique */
    transform: translateY(-5px); /* Légère élévation */
}

/* Effet sur la barre de recherche */
.search-input {
    width: 0;
    opacity: 0;
    transition: width 0.5s ease, opacity 0.5s ease;
}

.nav-item.active .search-input {
    width: 200px;
    opacity: 1;
}

/* Effet sur la barre de recherche */
.search-container {
    display: inline-block;  /* Positionner la barre de recherche entre les éléments */
}

.search-input {
    width: 200px;
    opacity: 1;
    transition: width 0.5s ease, opacity 0.5s ease;
}

.search-input:focus {
    width: 250px;  /* Augmente la largeur au focus */
    opacity: 1;
}
.btn-search {
    background-color: #d4af37; /* Couleur or métallique */
    color: white;
    border: none;
    border-radius: 20px;
    padding: 0 15px;
    height: 38px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn-search i {
    font-size: 18px; /* Ajuste la taille de l'icône pour la rendre proportionnelle */
}

/* "Se connecter" reste aligné à droite */
.navbar-nav:last-child {
    margin-left: auto;
}

/* Animation du bouton hamburger */
.navbar-toggler-icon {
    background-color: #d4af37;
    transition: transform 0.3s ease;
}

.navbar-toggler.collapsed .navbar-toggler-icon {
    transform: rotate(90deg);
}

/* Ajout de la transition de la navbar */
.navbar-scrolled {
    background-color: #d4af37; /* Or métallique */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}

        .input-group-append .input-group-text {
            background-color: #e1e1e1;
        }

        .hero-slider {
            position: relative;
            width: 100%;
            height: 100vh; /* garde la hauteur plein écran */
            overflow: hidden;
            background: #000;
            margin-bottom: 50px; /* Ajoute de l'espace après le slider */
        }

        /* Ajuster le z-index pour que les thumbnails restent au-dessus */
        .thumbnail-container {
            position: fixed; /* changer en absolute si vous ne voulez pas que les thumbnails suivent le scroll */
            bottom: 30px;
            right: 30px;
            z-index: 1000;
        }

        /* Assurer que la section service est visible */
        .service-section {
            position: relative;
            z-index: 1;
            background: #fff; /* ou la couleur de votre choix */
            padding: 80px 0;
        }
    </style>
</head>

<body>

    <!-- Remplacer la section hero-section par ce nouveau slider -->
    <section >
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

            a{
                text-decoration: none;
            }
            /* carousel */
            .carousel{
                height: 100vh;
                margin-top: -50px;
                width: 100vw;
                overflow: hidden;
                position: relative;
            }
            .carousel .list .item{
                width: 100%;
                height: 100%;
                position: absolute;
                inset: 0 0 0 0;
            }
            .carousel .list .item img{
                width: 100%;
                height: 100%;
                object-fit: cover;
            }
            .carousel .list .item .content{
                position: absolute;
                top: 20%;
                width: 1140px;
                max-width: 80%;
                left: 50%;
                transform: translateX(-50%);
                padding-right: 30%;
                box-sizing: border-box;
                color: #fff;
                text-shadow: 0 5px 10px #0004;
            }
            .carousel .list .item .author{
                font-weight: bold;
                letter-spacing: 10px;
            }
            .carousel .list .item .title,
            .carousel .list .item .topic{
                font-size: 5em;
                font-weight: bold;
                line-height: 1.3em;
            }
            .carousel .list .item .topic{
                color: #f1683a;
            }
            .carousel .list .item .buttons{
                display: grid;
                grid-template-columns: repeat(2, 130px);
                grid-template-rows: 40px;
                gap: 5px;
                margin-top: 20px;
            }
            .carousel .list .item .buttons button{
                border: none;
                background-color: #eee;
                letter-spacing: 3px;
                font-family: Poppins;
                font-weight: 500;
            }
            .carousel .list .item .buttons button:nth-child(2){
                background-color: transparent;
                border: 1px solid #fff;
                color: #eee;
            }
            /* thumbail */
            .thumbnail{
                position: absolute;
                bottom: 50px;
                left: 50%;
                width: max-content;
                z-index: 100;
                display: flex;
                gap: 20px;
            }
            .thumbnail .item{
                width: 150px;
                height: 220px;
                flex-shrink: 0;
                position: relative;
            }
            .thumbnail .item img{
                width: 100%;
                height: 100%;
                object-fit: cover;
                border-radius: 20px;
            }
            .thumbnail .item .content{
                color: #fff;
                position: absolute;
                bottom: 10px;
                left: 10px;
                right: 10px;
            }
            .thumbnail .item .content .title{
                font-weight: 500;
            }
            .thumbnail .item .content .description{
                font-weight: 300;
            }
            /* arrows */
            .arrows{
                position: absolute;
                top: 80%;
                right: 52%;
                z-index: 100;
                width: 300px;
                max-width: 30%;
                display: flex;
                gap: 10px;
                align-items: center;
            }
            .arrows button{
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background-color: #eee4;
                border: none;
                color: #fff;
                font-family: monospace;
                font-weight: bold;
                transition: .5s;
            }
            .arrows button:hover{
                background-color: #fff;
                color: #000;
            }

            /* animation */
            .carousel .list .item:nth-child(1){
                z-index: 1;
            }

            /* animation text in first item */

            .carousel .list .item:nth-child(1) .content .author,
            .carousel .list .item:nth-child(1) .content .title,
            .carousel .list .item:nth-child(1) .content .topic,
            .carousel .list .item:nth-child(1) .content .des,
            .carousel .list .item:nth-child(1) .content .buttons
            {
                transform: translateY(50px);
                filter: blur(20px);
                opacity: 0;
                animation: showContent .5s 1s linear 1 forwards;
            }
            @keyframes showContent{
                to{
                    transform: translateY(0px);
                    filter: blur(0px);
                    opacity: 1;
                }
            }
            .carousel .list .item:nth-child(1) .content .title{
                animation-delay: 1.2s!important;
            }
            .carousel .list .item:nth-child(1) .content .topic{
                animation-delay: 1.4s!important;
            }
            .carousel .list .item:nth-child(1) .content .des{
                animation-delay: 1.6s!important;
            }
            .carousel .list .item:nth-child(1) .content .buttons{
                animation-delay: 1.8s!important;
            }
            /* create animation when next click */
            .carousel.next .list .item:nth-child(1) img{
                width: 150px;
                height: 220px;
                position: absolute;
                bottom: 50px;
                left: 50%;
                border-radius: 30px;
                animation: showImage .5s linear 1 forwards;
            }
            @keyframes showImage{
                to{
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    border-radius: 0;
                }
            }

            .carousel.next .thumbnail .item:nth-last-child(1){
                overflow: hidden;
                animation: showThumbnail .5s linear 1 forwards;
            }
            .carousel.prev .list .item img{
                z-index: 100;
            }
            @keyframes showThumbnail{
                from{
                    width: 0;
                    opacity: 0;
                }
            }
            .carousel.next .thumbnail{
                animation: effectNext .5s linear 1 forwards;
            }

            @keyframes effectNext{
                from{
                    transform: translateX(150px);
                }
            }

            /* running time */

            .carousel .time{
                position: absolute;
                z-index: 1000;
                width: 0%;
                height: 3px;
                background-color: #f1683a;
                left: 0;
                top: 0;
            }

            .carousel.next .time,
            .carousel.prev .time{
                animation: runningTime 3s linear 1 forwards;
            }
            @keyframes runningTime{
                from{ width: 100%}
                to{width: 0}
            }


            /* prev click */

            .carousel.prev .list .item:nth-child(2){
                z-index: 2;
            }

            .carousel.prev .list .item:nth-child(2) img{
                animation: outFrame 0.5s linear 1 forwards;
                position: absolute;
                bottom: 0;
                left: 0;
            }
            @keyframes outFrame{
                to{
                    width: 150px;
                    height: 220px;
                    bottom: 50px;
                    left: 50%;
                    border-radius: 20px;
                }
            }

            .carousel.prev .thumbnail .item:nth-child(1){
                overflow: hidden;
                opacity: 0;
                animation: showThumbnail .5s linear 1 forwards;
            }
            .carousel.next .arrows button,
            .carousel.prev .arrows button{
                pointer-events: none;
            }
            .carousel.prev .list .item:nth-child(2) .content .author,
            .carousel.prev .list .item:nth-child(2) .content .title,
            .carousel.prev .list .item:nth-child(2) .content .topic,
            .carousel.prev .list .item:nth-child(2) .content .des,
            .carousel.prev .list .item:nth-child(2) .content .buttons
            {
                animation: contentOut 1.5s linear 1 forwards!important;
            }

            @keyframes contentOut{
                to{
                    transform: translateY(-150px);
                    filter: blur(20px);
                    opacity: 0;
                }
            }
            @media screen and (max-width: 678px) {
                .carousel .list .item .content{
                    padding-right: 0;
                }
                .carousel .list .item .content .title{
                    font-size: 30px;
                }
            }
        </style>

        <div class="carousel">
            <!-- list item -->
            <div class="list">
                <?php for($i = 1; $i <= 8; $i++): 
                    $num = str_pad($i, 2, '0', STR_PAD_LEFT); // Convertit 1 en 01, 2 en 02, etc.
                ?>
                <div class="item">
                    <img src="Image/s<?php echo $num; ?>.jpg" alt="Slide <?php echo $i; ?>">
                    <div class="content">
                        <div class="author"></div>
                        <div class="title">Supercar</div>
                        <div class="topic"></div>
                        <div class="des">
                            <!-- lorem 50 -->
                        </div>
                        <div class="buttons">
                            <button>SEE MORE</button>
                            <button>SUBSCRIBE</button>
                        </div>
                    </div>
                </div>
                <?php endfor; ?>
                
            </div>
            <!-- list thumnail -->
            <div class="thumbnail">
                <?php for($i = 1; $i <= 8; $i++): 
                    $num = str_pad($i, 2, '0', STR_PAD_LEFT); // Convertit 1 en 01, 2 en 02, etc.
                ?>
                        <div class="item">
                            <img src="Image/s<?php echo $num; ?>.jpg" alt="Slide <?php echo $i; ?>">
                            <div class="content">
                                <div class="title">
                                    Luxury Car <?php echo $i; ?>
                                </div>
                                <div class="description">
                                    Top car in the world
                                </div>
                            </div>
                        </div>
                <?php endfor; ?>
            </div>
            <!-- next prev -->

            <div class="arrows">
                <button id="prev"><</button>
                <button id="next">></button>
            </div>
            <!-- time running -->
            <div class="time"></div>
        </div>
    
    </section>

    <!-- Pourquoi Choisir Nos Voitures -->
    <section class="container py-5 fade-in">
    <h2 class="text-center mb-5">Pourquoi choisir nos voitures ?</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="text-center feature-block" style="background-color: #001f3d; color: white;">
                <div class="feature-icon mb-3">
                    <i class="fas fa-cogs"></i>
                </div>
                <h4>Qualité supérieure</h4>
                <p>Nos véhicules sont soigneusement sélectionnés pour offrir une qualité irréprochable.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="text-center feature-block" style="background-color: #d4af37; color: white;">
                <div class="feature-icon mb-3">
                    <i class="fas fa-handshake"></i>
                </div>
                <h4>Service Client Premium</h4>
                <p>Nous vous offrons un accompagnement personnalisé tout au long de votre achat.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="text-center feature-block" style="background-color: #8b0000; color: white;">
                <div class="feature-icon mb-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <h4>Options de Financement</h4>
                <p>Des solutions de financement flexibles pour rendre l'achat de votre voiture plus accessible.</p>
            </div>
        </div>
    </div>
</section>

<!-- Section Service -->
<section class="container py-5 fade-in">
    <h2 class="text-center mb-5">Nos Services</h2>
    <div class="row">
        <!-- Essai de voiture -->
        <div class="col-md-4">
            <div class="service-card">
                <img src="image/3.png" alt="Essai de voiture" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title">Essai de voiture</h5>
                    <p class="card-text">3000 Rs</p>
                    <a href="#" class="btn btn-primary">Réserver</a>
                </div>
            </div>
        </div>
        <!-- Entretien voiture -->
        <div class="col-md-4">
            <div class="service-card">
                <img src="image/2.png" alt="Entretien voiture" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title">Entretien voiture</h5>
                    <p class="card-text">5000 Rs</p>
                    <a href="#" class="btn btn-primary">Réserver</a>
                </div>
            </div>
        </div>
        <!-- Polissage carrosserie -->
        <div class="col-md-4">
            <div class="service-card">
                <img src="image/4.png" alt="Polissage carrosserie" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title">Polissage carrosserie</h5>
                    <p class="card-text">10.000 Rs</p>
                    <a href="#" class="btn btn-primary">Réserver</a>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- Testimonials Section -->
    <section class="testimonial-section">
        <div class="container">
            <h2 class="text-center mb-5">Témoignages clients</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="testimonial-card">
                        <p>"Excellente expérience, je recommande vivement ce site. Le processus d'achat était simple et rapide."</p>
                        <footer class="blockquote-footer">Lorryc Razafimahefa</footer>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="testimonial-card">
                        <p>"J'ai trouvé la voiture de mes rêves à un prix abordable. Un service impeccable !"</p>
                        <footer class="blockquote-footer">Marc Sivona</footer>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="testimonial-card">
                        <p>"Très satisfait de l'achat, livraison rapide et service après-vente au top."</p>
                        <footer class="blockquote-footer">John peeters</footer>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer text-center">
        <div class="container">
            <p>&copy; Supercar. Tous droits réservés.</p>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
            </div>
        </div>
    </footer>

    <!-- Lien vers le JavaScript de Bootstrap et FontAwesome -->
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="app.js"></script>
</body>

</html>
