<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    // Sauvegarder les paramètres dans la session
    $_SESSION['essai_params'] = [
        'marque' => isset($_GET['marque']) ? $_GET['marque'] : '',
        'modele' => isset($_GET['modele']) ? $_GET['modele'] : '',
        'type' => isset($_GET['type']) ? $_GET['type'] : ''
    ];
    $_SESSION['error'] = "Veuillez vous connecter pour réserver un essai.";
    $_SESSION['redirect_after_login'] = 'demande-essai.php';
    header("Location: login.php");
    exit();
}

// Récupérer les paramètres soit de l'URL, soit de la session
if (isset($_GET['marque']) && isset($_GET['modele']) && isset($_GET['type'])) {
    $marque = htmlspecialchars($_GET['marque']);
    $modele = htmlspecialchars($_GET['modele']);
    $type = htmlspecialchars($_GET['type']);
} elseif (isset($_SESSION['essai_params'])) {
    // Récupérer les paramètres sauvegardés
    $marque = htmlspecialchars($_SESSION['essai_params']['marque']);
    $modele = htmlspecialchars($_SESSION['essai_params']['modele']);
    $type = htmlspecialchars($_SESSION['essai_params']['type']);
    // Nettoyer les paramètres de la session
    unset($_SESSION['essai_params']);
} else {
    $marque = '';
    $modele = '';
    $type = '';
}

// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date_essai = $_POST['date_essai'];
    $heure_essai = $_POST['heure_essai'];
    $lieu_essai = $_POST['lieu_essai'];
    $commentaire = $_POST['commentaire'];

    // Insérer la demande d'essai
    $stmt = $mysqli->prepare("INSERT INTO demandes_essai (user_id, marque, modele, date_essai, heure_essai, lieu_essai, commentaire) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssss", $_SESSION['user_id'], $marque, $modele, $date_essai, $heure_essai, $lieu_essai, $commentaire);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Votre demande d'essai a été enregistrée avec succès !";
        header("Location: fichiervoiture.php");
        exit();
    } else {
        $error = "Erreur lors de l'enregistrement de la demande.";
    }
}

// Inclure le header
include 'header.php';
?>

<style>
    body {
        background-image: url('Image/bg-essai.png');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        font-family: 'Lato', sans-serif;
    }

    .test-drive-container {
        max-width: 600px;
        margin: 50px auto;
        padding: 30px;
        background-color: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        margin-bottom: 100px;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .test-drive-title {
        color: white;
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        text-align: center;
        margin-bottom: 30px;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
    }

    .form-control {
        border-radius: 20px;
        padding: 12px 20px;
        margin-bottom: 20px;
        border: 2px solid #e9ecef;
    }

    .form-control:focus {
        border-color: #d4af37;
        box-shadow: none;
    }

    .btn-submit {
        background-color: #d4af37;
        color: white;
        border: none;
        border-radius: 20px;
        padding: 12px 30px;
        width: 100%;
        font-weight: 600;
        text-transform: uppercase;
        transition: background-color 0.3s ease;
    }

    .btn-submit:hover {
        background-color: #8b0000;
        color: white;
    }

    .footer {
        background-color: #001f3d;
        color: white;
        padding: 20px 0;
        position: fixed;
        bottom: 0;
        width: 100%;
        z-index: 1000;
    }

    .footer .social-icons a {
        color: white;
        margin-right: 10px;
        font-size: 20px;
    }

    .error-message {
        color: #dc3545;
        text-align: center;
        margin-bottom: 20px;
    }

    .success-message {
        color: #28a745;
        text-align: center;
        margin-bottom: 20px;
    }
</style>
    
        <!-- Formulaire de demande d'essai -->
<div class="container">
    <div class="test-drive-container">
        <h2 class="test-drive-title">Demande d'essai</h2>
        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <!-- Informations pré-remplies -->
            <div class="form-group">
                <label>Marque</label>
                <input type="text" class="form-control" value="<?php echo $marque; ?>" readonly>
            </div>
            <div class="form-group">
                <label>Modèle</label>
                <input type="text" class="form-control" value="<?php echo $modele; ?>" readonly>
            </div>
            <div class="form-group">
                <label>Type</label>
                <input type="text" class="form-control" value="<?php echo $type; ?>" readonly>
            </div>

            <!-- Champs à remplir -->
            <div class="form-group">
                <label>Date d'essai</label>
                <input type="date" class="form-control" name="date_essai" required min="<?php echo date('Y-m-d'); ?>">
                </div>
            <div class="form-group">
                <label>Heure d'essai</label>
                <input type="time" class="form-control" name="heure_essai" required>
                </div>
            <div class="form-group">
                <label>Lieu d'essai</label>
                <input type="text" class="form-control" name="lieu_essai" required placeholder="Adresse du lieu d'essai">
            </div>
            <div class="form-group">
                <label>Commentaire (optionnel)</label>
                <textarea class="form-control" name="commentaire" rows="3"></textarea>
                </div>
            <button type="submit" class="btn btn-submit">Soumettre la demande</button>
        </form>
                </div>
            </div>

<!-- Footer -->
<footer class="footer text-center">
    <div class="container">
        <p>&copy; Supercar. Tous droits réservés.</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
