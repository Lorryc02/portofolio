<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifier si l'utilisateur est connecté et est un admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - Supercar</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&family=Lato:wght@400&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Lato', sans-serif;
            background-color: #f8f9fa;
        }

        .navbar {
            background-color: #001f3d;
            padding: 1rem;
        }

        .navbar-brand {
            color: #d4af37 !important;
            font-weight: 600;
        }

        .nav-link {
            color: white !important;
            margin: 0 10px;
            transition: color 0.3s ease;
        }

        .nav-link:hover {
            color: #d4af37 !important;
        }

        .nav-link.active {
            color: #d4af37 !important;
        }

        .user-info {
            color: white;
            display: flex;
            align-items: center;
        }

        .user-info i {
            color: #d4af37;
            margin-right: 10px;
        }

        .logout-btn {
            color: #d4af37;
            text-decoration: none;
            margin-left: 15px;
        }

        .logout-btn:hover {
            color: #8b0000;
        }

        .sidebar {
            background-color: #001f3d;
            min-height: calc(100vh - 56px);
            padding: 20px 0;
        }

        .sidebar .nav-link {
            color: white;
            padding: 10px 20px;
            margin: 5px 0;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .sidebar .nav-link:hover {
            background-color: #d4af37;
            color: #001f3d !important;
        }

        .sidebar .nav-link.active {
            background-color: #d4af37;
            color: #001f3d !important;
        }

        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
        }

        .main-content {
            padding: 20px;
        }
    </style>
</head>
<body>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>

    <!-- Header spécifique pour le dashboard -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="dashboard.php">
            <i class="fas fa-car"></i> Supercar Admin
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Tableau de bord</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin-voiture.php">Voitures</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="admin-service.php">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin-demandes.php">Demande d'essai</a>
                </li>
            </ul>
            <div class="user-info">
                <i class="fas fa-user"></i>
                <span><?php echo $_SESSION['user_prenom']; ?></span>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Se déconnecter
                </a>
            </div>
        </div>
    </nav>

    <!--<div class="container-fluid">
        <div class="row">-->
            <!-- Sidebar -->
        <!--    <div class="col-md-3 col-lg-2 sidebar">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Tableau de bord
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin-voiture.php' ? 'active' : ''; ?>" href="admin-voiture.php">
                            <i class="fas fa-car"></i> Voitures
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin-service.php' ? 'active' : ''; ?>" href="admin-service.php">
                            <i class="fas fa-cogs"></i> Services
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin-demandes.php' ? 'active' : ''; ?>" href="admin-demandes.php">
                            <i class="fas fa-calendar-check"></i> Demandes d'essai
                        </a>
                    </li>

                </ul>
            </div>-->

            <!-- Main Content -->
            <!--<div class="col-md-9 col-lg-10 main-content"> -->