<?php
include 'header-admin.php';

// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Récupération des statistiques
$stats = array();

// Nombre total de voitures
$query = "SELECT COUNT(*) as total FROM voitures";
$result = $mysqli->query($query);
$stats['voitures'] = $result ? $result->fetch_assoc()['total'] : 0;

// Nombre de services actifs
$query = "SELECT COUNT(*) as total FROM services";
$result = $mysqli->query($query);
$stats['services'] = $result ? $result->fetch_assoc()['total'] : 0;

// Nombre de demandes d'essai
$query = "SELECT COUNT(*) as total FROM demandes_essai";
$result = $mysqli->query($query);
$stats['demandes'] = $result ? $result->fetch_assoc()['total'] : 0;

// Récupérer le nombre total de services
$query = "SELECT COUNT(*) as total FROM services";
$result = $mysqli->query($query);
$total_services = $result->fetch_assoc()['total'];

// Récupérer le nombre de réservations de services
$query = "SELECT COUNT(*) as total FROM reservations_services";
$result = $mysqli->query($query);
$total_reservations = $result->fetch_assoc()['total'];

// Récupérer les derniers services ajoutés
$query = "SELECT * FROM services ORDER BY date_creation DESC LIMIT 3";
$result = $mysqli->query($query);
$derniers_services = $result->fetch_all(MYSQLI_ASSOC);

// Récupérer les dernières réservations de services
$query = "SELECT rs.*, s.nom as service_nom, u.nom as user_nom, u.prenom as user_prenom 
          FROM reservations_services rs 
          LEFT JOIN services s ON rs.service_id = s.id 
          LEFT JOIN users u ON rs.user_id = u.id 
          ORDER BY rs.date_creation DESC LIMIT 5";
$result = $mysqli->query($query);
$dernieres_reservations = $result->fetch_all(MYSQLI_ASSOC);
?>

<div class="container-fluid">
    <h2 class="mb-4">Tableau de bord</h2>

    <!-- Cartes de statistiques -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Voitures</h5>
                    <p class="card-text display-4"><?php echo $stats['voitures']; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Services</h5>
                    <p class="card-text display-4"><?php echo $total_services; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Demandes d'essai</h5>
                    <p class="card-text display-4"><?php echo $stats['demandes']; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5 class="card-title">Réservations</h5>
                    <p class="card-text display-4"><?php echo $total_reservations; ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Dernières réservations de services -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Dernières réservations de services</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Service</th>
                                    <th>Client</th>
                                    <th>Date</th>
                                    <th>Heure</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($dernieres_reservations)): ?>
                                    <?php foreach($dernieres_reservations as $reservation): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($reservation['service_nom']); ?></td>
                                            <td><?php echo htmlspecialchars($reservation['user_prenom'] . ' ' . $reservation['user_nom']); ?></td>
                                            <td><?php echo date('d/m/Y', strtotime($reservation['date_reservation'])); ?></td>
                                            <td><?php echo date('H:i', strtotime($reservation['heure_reservation'])); ?></td>
                                            
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Aucune réservation trouvée</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <!-- Dernières demandes d'essai -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Dernières demandes d'essai</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Client</th>
                                    <th>Voiture</th>
                                    <th>Date d'essai</th>
                                    <th>Heure</th>
                                    <th>Lieu</th>
                                    <th>Commentaire</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT d.*, u.prenom, u.nom 
                                         FROM demandes_essai d 
                                         JOIN users u ON d.user_id = u.id 
                                         ORDER BY d.date_demande DESC LIMIT 5";
                                $result = $mysqli->query($query);
                                if ($result && $result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?php echo date('d/m/Y', strtotime($row['date_demande'])); ?></td>
                                    <td><?php echo htmlspecialchars($row['prenom'] . ' ' . $row['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($row['marque'] . ' ' . $row['modele']); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($row['date_essai'])); ?></td>
                                    <td><?php echo $row['heure_essai']; ?></td>
                                    <td><?php echo htmlspecialchars($row['lieu_essai']); ?></td>
                                    <td><?php echo htmlspecialchars($row['commentaire']); ?></td>
                                </tr>
                                <?php 
                                    endwhile;
                                } else {
                                    echo '<tr><td colspan="7" class="text-center">Aucune demande d\'essai trouvée</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function voirDemande(id) {
    // Fonction pour voir les détails d'une demande
    window.location.href = 'admin-demandes.php?id=' + id;
}
</script>

</div>
</body>
</html> 