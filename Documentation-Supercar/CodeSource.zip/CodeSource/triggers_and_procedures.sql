-- Triggers et proc�dures propos�es pour la base 'vehicules'
USE vehicules;
DELIMITER $$

-- 1) Trigger: emp�cher doublon date+heure pour demandes_essai
CREATE TRIGGER trg_demandes_essai_before_insert
BEFORE INSERT ON demandes_essai
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1 FROM demandes_essai
        WHERE date_essai = NEW.date_essai
          AND heure_essai = NEW.heure_essai
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cr�neau d�j� r�serv� : date et heure occup�es.';
    END IF;
END$$

-- 2) Proc�dure: insertion s�curis�e d'une demande d'essai
CREATE PROCEDURE sp_insert_demande_essai(
    IN p_user_id INT,
    IN p_marque VARCHAR(100),
    IN p_modele VARCHAR(100),
    IN p_date_essai DATE,
    IN p_heure_essai TIME,
    IN p_lieu_essai VARCHAR(100),
    IN p_commentaire TEXT
)
BEGIN
    -- V�rifie le cr�neau
    IF EXISTS (
        SELECT 1 FROM demandes_essai
        WHERE date_essai = p_date_essai
          AND heure_essai = p_heure_essai
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cr�neau d�j� r�serv� : date et heure occup�es.';
    ELSE
        INSERT INTO demandes_essai (user_id, marque, modele, date_essai, heure_essai, lieu_essai, commentaire)
        VALUES (p_user_id, p_marque, p_modele, p_date_essai, p_heure_essai, p_lieu_essai, p_commentaire);
    END IF;
END$$

-- 3) Proc�dure: mise � jour centralis�e du statut d'une r�servation de service
CREATE PROCEDURE sp_update_reservation_status(
    IN p_id INT,
    IN p_status ENUM('en_attente','confirmee','annulee')
)
BEGIN
    -- Valide le statut
    IF p_status NOT IN ('en_attente','confirmee','annulee') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Statut invalide.';
    ELSE
        UPDATE reservations_services
        SET statut = p_status
        WHERE id = p_id;
    END IF;
END$$

-- 4) Optionnel : table d'audit + trigger pour historiser changements de statut
-- (d�commenter et appliquer seulement si vous approuvez un changement structurel)
-- CREATE TABLE IF NOT EXISTS reservation_status_history (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     reservation_id INT NOT NULL,
--     old_status ENUM('en_attente','confirmee','annulee'),
--     new_status ENUM('en_attente','confirmee','annulee'),
--     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );
--
-- CREATE TRIGGER trg_reservations_services_after_update
-- AFTER UPDATE ON reservations_services
-- FOR EACH ROW
-- BEGIN
--     IF NOT (OLD.statut <=> NEW.statut) THEN
--         INSERT INTO reservation_status_history (reservation_id, old_status, new_status)
--         VALUES (OLD.id, OLD.statut, NEW.statut);
--     END IF;
-- END$$

DELIMITER ;

--CALL sp_insert_demande_essai(
   -- 4, 
   -- 'bmw', 
    --'BMW M4 Competition', 
    --'2025-11-18', 
    --'07:00:00', 
    ---'Port Louis', 
    --'TEST DOUBLON'
--);