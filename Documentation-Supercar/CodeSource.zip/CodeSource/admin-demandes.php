<?php
include 'header-admin.php';

// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Traitement des actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'edit':
                $id = $_POST['id'];
                $user_id = $_POST['user_id'];
                $marque = $_POST['marque'];
                $modele = $_POST['modele'];
                $date_essai = $_POST['date_essai'];
                $heure_essai = $_POST['heure_essai'];
                $lieu_essai = $_POST['lieu_essai'];
                $commentaire = $_POST['commentaire'];

                $query = "UPDATE demandes_essai SET user_id=?, marque=?, modele=?, date_essai=?, heure_essai=?, lieu_essai=?, commentaire=? WHERE id=?";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param("issssssi", $user_id, $marque, $modele, $date_essai, $heure_essai, $lieu_essai, $commentaire, $id);
                $stmt->execute();
                break;

            case 'delete':
                $id = $_POST['id'];
                $query = "DELETE FROM demandes_essai WHERE id = ?";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param("i", $id);
                $stmt->execute();
                break;
        }
        header("Location: admin-demandes.php");
        exit();
    }
}

// Récupération des demandes d'essai
$query = "SELECT d.*, u.nom, u.prenom, u.email, u.numero 
          FROM demandes_essai d 
          LEFT JOIN users u ON d.user_id = u.id 
          ORDER BY d.date_demande DESC";
$result = $mysqli->query($query);

if (!$result) {
    die("Erreur dans la requête : " . $mysqli->error);
}

// Récupération des utilisateurs pour le formulaire d'ajout
$users_query = "SELECT id, prenom, nom FROM users ORDER BY prenom, nom";
$users_result = $mysqli->query($users_query);
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Gestion des Demandes d'Essai</h2>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addDemandeModal">
            <i class="fas fa-plus"></i> Nouvelle demande
        </button>
    </div>

    <!-- Table des demandes -->
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Email</th>
                    <th>Téléphone</th>
                    <th>Voiture</th>
                    <th>Date d'essai</th>
                    <th>Heure</th>
                    <th>Lieu</th>
                    <th>Commentaire</th>
                    <th>Date demande</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['prenom'] . ' ' . $row['nom']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['numero']); ?></td>
                        <td><?php echo htmlspecialchars($row['marque'] . ' ' . $row['modele']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($row['date_essai'])); ?></td>
                        <td><?php echo $row['heure_essai']; ?></td>
                        <td><?php echo htmlspecialchars($row['lieu_essai']); ?></td>
                        <td><?php echo htmlspecialchars($row['commentaire']); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($row['date_demande'])); ?></td>
                        <td>
                            <button class="btn btn-sm btn-info edit-btn" 
                                    data-id="<?php echo $row['id']; ?>"
                                    data-user-id="<?php echo $row['user_id']; ?>"
                                    data-marque="<?php echo htmlspecialchars($row['marque']); ?>"
                                    data-modele="<?php echo htmlspecialchars($row['modele']); ?>"
                                    data-date="<?php echo $row['date_essai']; ?>"
                                    data-heure="<?php echo $row['heure_essai']; ?>"
                                    data-lieu="<?php echo htmlspecialchars($row['lieu_essai']); ?>"
                                    data-commentaire="<?php echo htmlspecialchars($row['commentaire']); ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo $row['id']; ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11" class="text-center">Aucune demande d'essai trouvée</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Ajout -->
<div class="modal fade" id="addDemandeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nouvelle demande d'essai</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label>Client</label>
                        <select class="form-control" name="user_id" required>
                            <option value="">Sélectionner un client</option>
                            <?php while ($user = $users_result->fetch_assoc()): ?>
                            <option value="<?php echo $user['id']; ?>">
                                <?php echo htmlspecialchars($user['prenom'] . ' ' . $user['nom']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Marque</label>
                        <input type="text" class="form-control" name="marque" required>
                    </div>
                    <div class="form-group">
                        <label>Modèle</label>
                        <input type="text" class="form-control" name="modele" required>
                    </div>
                    <div class="form-group">
                        <label>Date d'essai</label>
                        <input type="date" class="form-control" name="date_essai" required>
                    </div>
                    <div class="form-group">
                        <label>Heure d'essai</label>
                        <input type="time" class="form-control" name="heure_essai" required>
                    </div>
                    <div class="form-group">
                        <label>Lieu d'essai</label>
                        <input type="text" class="form-control" name="lieu_essai" required>
                    </div>
                    <div class="form-group">
                        <label>Commentaire</label>
                        <textarea class="form-control" name="commentaire" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Ajouter</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Modification -->
<div class="modal fade" id="editDemandeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier la demande d'essai</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="form-group">
                        <label>Client</label>
                        <select class="form-control" name="user_id" id="edit_user_id" required>
                            <option value="">Sélectionner un client</option>
                            <?php 
                            $users_result->data_seek(0);
                            while ($user = $users_result->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $user['id']; ?>">
                                <?php echo htmlspecialchars($user['prenom'] . ' ' . $user['nom']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Marque</label>
                        <input type="text" class="form-control" name="marque" id="edit_marque" required>
                    </div>
                    <div class="form-group">
                        <label>Modèle</label>
                        <input type="text" class="form-control" name="modele" id="edit_modele" required>
                    </div>
                    <div class="form-group">
                        <label>Date d'essai</label>
                        <input type="date" class="form-control" name="date_essai" id="edit_date" required>
                    </div>
                    <div class="form-group">
                        <label>Heure d'essai</label>
                        <input type="time" class="form-control" name="heure_essai" id="edit_heure" required>
                    </div>
                    <div class="form-group">
                        <label>Lieu d'essai</label>
                        <input type="text" class="form-control" name="lieu_essai" id="edit_lieu" required>
                    </div>
                    <div class="form-group">
                        <label>Commentaire</label>
                        <textarea class="form-control" name="commentaire" id="edit_commentaire" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Modifier</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Suppression -->
<div class="modal fade" id="deleteDemandeModal" tabindex="-1" role="dialog" aria-labelledby="deleteDemandeModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteDemandeModalLabel">Confirmer la suppression</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Êtes-vous sûr de vouloir supprimer cette demande d'essai ?</p>
            </div>
            <div class="modal-footer">
                <form method="POST">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="delete_id">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-danger">Supprimer</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Gestion du bouton d'édition
    $('.edit-btn').click(function() {
        var id = $(this).data('id');
        $('#edit_id').val(id);
        $('#edit_user_id').val($(this).data('user-id'));
        $('#edit_marque').val($(this).data('marque'));
        $('#edit_modele').val($(this).data('modele'));
        $('#edit_date').val($(this).data('date'));
        $('#edit_heure').val($(this).data('heure'));
        $('#edit_lieu').val($(this).data('lieu'));
        $('#edit_commentaire').val($(this).data('commentaire'));
        $('#editDemandeModal').modal('show');
    });

    // Gestion du bouton de suppression
    $('.delete-btn').click(function() {
        var id = $(this).data('id');
        $('#delete_id').val(id);
        $('#deleteDemandeModal').modal('show');
    });
});
</script>

</div>
</body>
</html> 