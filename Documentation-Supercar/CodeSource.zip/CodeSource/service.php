<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'header.php';

// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");

if ($mysqli->connect_error) {
    die("Erreur de connexion : " . $mysqli->connect_error);
}

// Traitement de la réservation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'reserver') {
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['error'] = "Vous devez être connecté pour réserver un service.";
        header("Location: login.php");
        exit();
    }

    $service_id = $_POST['service_id'];
    $date_reservation = $_POST['date_reservation'];
    $heure_reservation = $_POST['heure_reservation'];
    $user_id = $_SESSION['user_id'];

    // Vérifier si la date et l'heure sont disponibles
    $query = "SELECT COUNT(*) as count FROM reservations_services 
              WHERE service_id = ? AND date_reservation = ? AND heure_reservation = ? AND statut != 'annulee'";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("iss", $service_id, $date_reservation, $heure_reservation);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['count'] > 0) {
        $_SESSION['error'] = "Ce créneau horaire est déjà réservé. Veuillez choisir une autre date ou heure.";
    } else {
        // Insérer la réservation
        $query = "INSERT INTO reservations_services (user_id, service_id, date_reservation, heure_reservation) 
                  VALUES (?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("iiss", $user_id, $service_id, $date_reservation, $heure_reservation);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Votre réservation a été enregistrée avec succès.";
        } else {
            $_SESSION['error'] = "Une erreur est survenue lors de la réservation.";
        }
    }
}

// Récupération des services depuis la base de données
$query = "SELECT * FROM services ORDER BY prix ASC";
$result = $mysqli->query($query);
?>

<style>
    /* Styles personnalisés */
    body {
        font-family: 'Lato', sans-serif;
        background-color: #e1e1e1;
        color: #001f3d;
    }

    h1, h2, h3 {
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
    }

    blockquote {
        font-family: 'Playfair Display', serif;
        font-style: italic;
        color: #8b0000;
    }

    .service-card {
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        background-color: #f8f9fa;
        transition: transform 0.3s ease-in-out;
        margin-bottom: 30px;
        height: 100%;
    }

    .service-card:hover {
        transform: scale(1.05);
    }

    .service-card img {
        border-radius: 10px 10px 0 0;
        height: 200px;
        object-fit: cover;
    }

    .service-card .btn {
        background-color: #d4af37;
        color: white;
        padding: 10px 20px;
        border-radius: 20px;
        text-transform: uppercase;
        font-weight: bold;
    }

    .service-card .btn:hover {
        background-color: #8b0000;
    }

    .service-card .card-body {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: calc(100% - 200px);
    }

    .service-card .card-text {
        margin-bottom: 1rem;
    }

    .service-card .description {
        color: #666;
        font-size: 0.9rem;
        margin-bottom: 1rem;
    }

    .service-card .prix {
        font-size: 1.2rem;
        font-weight: bold;
        color: #d4af37;
    }

    .footer {
        background-color: #001f3d;
        color: white;
        padding: 20px 0;
    }

    .footer .social-icons a {
        color: white;
        margin-right: 10px;
        font-size: 20px;
    }

    .search-input {
        width: 200px;
        border-radius: 20px;
        padding: 5px 15px;
    }

    .search-icon {
        position: absolute;
        right: 10px;
        top: 5px;
        color: #007bff;
    }

    /* Navbar container */
    .navbar {
        background-color: #001f3d; /* Bleu nuit */
        transition: all 0.3s ease-in-out;
    }

    /* Centre les éléments de la navbar */
    .navbar-nav.mx-auto {
        display: flex;
        justify-content: center;
        flex-grow: 1;
    }

    /* Le logo s'adapte à la taille de la navbar */
    .navbar-logo {
        max-height: 150px;
        width: auto;
        transition: transform 0.3s ease-in-out;
    }

    /* Animation de survol du logo */
    .navbar-logo:hover {
        transform: scale(1.1);
    }

    /* Style des liens */
    .navbar-nav .nav-link {
        color: white;
        font-size: 16px;
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        letter-spacing: 1px;
        transition: color 0.3s ease, transform 0.3s ease;
    }

    /* Animation au survol des liens */
    .navbar-nav .nav-link:hover {
        color: #d4af37; /* Or métallique */
        transform: translateY(-5px); /* Légère élévation */
    }

    /* Effet sur la barre de recherche */
    .search-input {
        width: 0;
        opacity: 0;
        transition: width 0.5s ease, opacity 0.5s ease;
    }

    .nav-item.active .search-input {
        width: 200px;
        opacity: 1;
    }

    /* Effet sur la barre de recherche */
    .search-container {
        display: inline-block;  /* Positionner la barre de recherche entre les éléments */
    }

    .search-input {
        width: 200px;
        opacity: 1;
        transition: width 0.5s ease, opacity 0.5s ease;
    }

    .search-input:focus {
        width: 250px;  /* Augmente la largeur au focus */
        opacity: 1;
    }
    .btn-search {
        background-color: #d4af37; /* Couleur or métallique */
        color: white;
        border: none;
        border-radius: 20px;
        padding: 0 15px;
        height: 38px;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .btn-search i {
        font-size: 18px; /* Ajuste la taille de l'icône pour la rendre proportionnelle */
    }

    /* "Se connecter" reste aligné à droite */
    .navbar-nav:last-child {
        margin-left: auto;
    }

    /* Animation du bouton hamburger */
    .navbar-toggler-icon {
        background-color: #d4af37;
        transition: transform 0.3s ease;
    }

    .navbar-toggler.collapsed .navbar-toggler-icon {
        transform: rotate(90deg);
    }

    /* Ajout de la transition de la navbar */
    .navbar-scrolled {
        background-color: #d4af37; /* Or métallique */
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    }

    .input-group-append .input-group-text {
        background-color: #e1e1e1;
    }
</style>

<!-- Section Service -->
<section class="container py-5">
    <h2 class="text-center mb-5">Nos Services</h2>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php 
            echo $_SESSION['error'];
            unset($_SESSION['error']);
            ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php 
            echo $_SESSION['success'];
            unset($_SESSION['success']);
            ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="row">
        <?php if ($result->num_rows > 0): ?>
            <?php while($service = $result->fetch_assoc()): ?>
                <div class="col-md-4">
                    <div class="service-card">
                        <img src="<?php echo htmlspecialchars($service['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($service['nom']); ?>" 
                             class="card-img-top">
                        <div class="card-body">
                            <div>
                                <h5 class="card-title"><?php echo htmlspecialchars($service['nom']); ?></h5>
                                <p class="description"><?php echo htmlspecialchars($service['description']); ?></p>
                                <p class="prix"><?php echo number_format($service['prix'], 2); ?> Rs</p>
                            </div>
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <button type="button" class="btn btn-primary" 
                                        data-toggle="modal" 
                                        data-target="#reservationModal<?php echo $service['id']; ?>">
                                    Réserver
                                </button>
                            <?php else: ?>
                                <a href="login.php" class="btn btn-primary">Se connecter pour réserver</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Modal de réservation -->
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="modal fade" id="reservationModal<?php echo $service['id']; ?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Réserver <?php echo htmlspecialchars($service['nom']); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="" method="POST">
                                    <div class="modal-body">
                                        <input type="hidden" name="action" value="reserver">
                                        <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                        
                                        <div class="form-group">
                                            <label for="date_reservation">Date de réservation</label>
                                            <input type="date" class="form-control" id="date_reservation" 
                                                   name="date_reservation" required 
                                                   min="<?php echo date('Y-m-d'); ?>">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="heure_reservation">Heure de réservation</label>
                                            <select class="form-control" id="heure_reservation" name="heure_reservation" required>
                                                <?php
                                                for ($h = 9; $h <= 17; $h++) {
                                                    echo "<option value='" . sprintf("%02d:00:00", $h) . "'>" . 
                                                         sprintf("%02d:00", $h) . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                        <button type="submit" class="btn btn-primary">Confirmer la réservation</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center">
                <p>Aucun service disponible pour le moment.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Footer -->
<footer class="footer text-center">
    <div class="container">
        <p>&copy; Supercar. Tous droits réservés.</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
    </div>
</footer>

<!-- Lien vers le JavaScript de Bootstrap et FontAwesome -->
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
