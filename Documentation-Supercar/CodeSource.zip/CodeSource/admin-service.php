<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'header-admin.php';
?>

<!-- Scripts JavaScript -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");

if ($mysqli->connect_error) {
    die("Erreur de connexion : " . $mysqli->connect_error);
}

// Fonction pour gérer l'upload d'images
function uploadImage($file, $target_dir = "image/") {
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_file = $target_dir . basename($file["name"]);
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    
    // Vérifier si c'est une vraie image
    $check = getimagesize($file["tmp_name"]);
    if($check === false) {
        return false;
    }
    
    // Vérifier la taille du fichier (max 5MB)
    if ($file["size"] > 5000000) {
        return false;
    }
    
    // Autoriser certains formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
        return false;
    }
    
    // Générer un nom de fichier unique
    $new_filename = uniqid() . '.' . $imageFileType;
    $target_file = $target_dir . $new_filename;
    
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return $target_file;
    }
    return false;
}

// Traitement des actions CRUD
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $nom = $_POST['nom'];
                $description = $_POST['description'];
                $prix = $_POST['prix'];
                
                // Gérer l'upload de l'image
                $image_url = '';
                if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $image_url = uploadImage($_FILES['image']);
                }

                $query = "INSERT INTO services (nom, description, prix, image_url) VALUES (?, ?, ?, ?)";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param("ssds", $nom, $description, $prix, $image_url);
                $stmt->execute();
                $_SESSION['message'] = "Service ajouté avec succès.";
                break;

            case 'edit':
                $id = $_POST['id'];
                $nom = $_POST['nom'];
                $description = $_POST['description'];
                $prix = $_POST['prix'];
                
                // Gérer l'upload de la nouvelle image si fournie
                $image_url = $_POST['current_image'];
                if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $new_image_url = uploadImage($_FILES['image']);
                    if($new_image_url) {
                        // Supprimer l'ancienne image si elle existe
                        if($image_url && file_exists($image_url)) {
                            unlink($image_url);
                        }
                        $image_url = $new_image_url;
                    }
                }

                $query = "UPDATE services SET nom=?, description=?, prix=?, image_url=? WHERE id=?";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param("ssdsi", $nom, $description, $prix, $image_url, $id);
                $stmt->execute();
                $_SESSION['message'] = "Service modifié avec succès.";
                break;

            case 'delete':
                $id = $_POST['id'];
                // Récupérer l'URL de l'image avant la suppression
                $query = "SELECT image_url FROM services WHERE id=?";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                
                // Supprimer l'image du serveur
                if($row['image_url'] && file_exists($row['image_url'])) {
                    unlink($row['image_url']);
                }
                
                // Supprimer l'enregistrement de la base de données
                $query = "DELETE FROM services WHERE id=?";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $_SESSION['message'] = "Service supprimé avec succès.";
                break;
        }
        echo "<script>window.location.href = 'admin-service.php';</script>";
        exit();
    }
}

// Afficher le message s'il existe
if (isset($_SESSION['message'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            ' . $_SESSION['message'] . '
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
          </div>';
    unset($_SESSION['message']);
}

// Récupération des services
$query = "SELECT * FROM services ORDER BY nom";
$result = $mysqli->query($query);

// Récupération des réservations de services
$query = "SELECT rs.*, s.nom as service_nom, u.nom as user_nom, u.prenom as user_prenom, u.email, u.numero 
         FROM reservations_services rs 
         LEFT JOIN services s ON rs.service_id = s.id 
         LEFT JOIN users u ON rs.user_id = u.id 
         ORDER BY rs.date_reservation DESC";
$reservations = $mysqli->query($query);
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Gestion des Services</h2>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addServiceModal">
            <i class="fas fa-plus"></i> Ajouter un service
        </button>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Prix</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while($service = $result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <?php if($service['image_url']): ?>
                                            <img src="<?php echo htmlspecialchars($service['image_url']); ?>" 
                                                 alt="<?php echo htmlspecialchars($service['nom']); ?>" 
                                                 style="width: 50px; height: 50px; object-fit: cover;">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($service['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($service['description']); ?></td>
                                    <td><?php echo number_format($service['prix'], 2); ?> Rs</td>
                                    <td>
                                        <button class="btn btn-sm btn-info edit-btn" 
                                                data-id="<?php echo $service['id']; ?>"
                                                data-nom="<?php echo htmlspecialchars($service['nom']); ?>"
                                                data-description="<?php echo htmlspecialchars($service['description']); ?>"
                                                data-prix="<?php echo $service['prix']; ?>"
                                                data-image="<?php echo htmlspecialchars($service['image_url']); ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger delete-btn" 
                                                data-id="<?php echo $service['id']; ?>"
                                                data-nom="<?php echo htmlspecialchars($service['nom']); ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Aucun service trouvé</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Réservations des Services</h2>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Service</th>
                            <th>Client</th>
                            <th>Contact</th>
                            <th>Date</th>
                            <th>Heure</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($reservations->num_rows > 0): ?>
                            <?php while($reservation = $reservations->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($reservation['service_nom']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['user_prenom'] . ' ' . $reservation['user_nom']); ?></td>
                                    <td>
                                        Email: <?php echo htmlspecialchars($reservation['email']); ?><br>
                                        Tél: <?php echo htmlspecialchars($reservation['numero']); ?>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($reservation['date_reservation'])); ?></td>
                                    <td><?php echo date('H:i', strtotime($reservation['heure_reservation'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center">Aucune réservation trouvée</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Ajout Service -->
<div class="modal fade" id="addServiceModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter un service</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="form-group">
                        <label for="nom">Nom du service</label>
                        <input type="text" class="form-control" id="nom" name="nom" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="prix">Prix (Rs)</label>
                        <input type="number" class="form-control" id="prix" name="prix" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="image">Image</label>
                        <input type="file" class="form-control-file" id="image" name="image" accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Ajouter</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Modification Service -->
<div class="modal fade" id="editServiceModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier le service</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" id="edit_id">
                    <input type="hidden" name="current_image" id="edit_current_image">
                    
                    <div class="form-group">
                        <label for="edit_nom">Nom du service</label>
                        <input type="text" class="form-control" id="edit_nom" name="nom" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_description">Description</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="3" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_prix">Prix (Rs)</label>
                        <input type="number" class="form-control" id="edit_prix" name="prix" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_image">Nouvelle image (optionnel)</label>
                        <input type="file" class="form-control-file" id="edit_image" name="image" accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Modifier</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Confirmation Suppression -->
<div class="modal fade" id="deleteServiceModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmer la suppression</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Êtes-vous sûr de vouloir supprimer le service "<span id="delete_nom"></span>" ?</p>
            </div>
            <div class="modal-footer">
                <form action="" method="POST">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="delete_id">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-danger">Supprimer</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Gestion du bouton d'édition
    $('.edit-btn').click(function() {
        var id = $(this).data('id');
        var nom = $(this).data('nom');
        var description = $(this).data('description');
        var prix = $(this).data('prix');
        var image = $(this).data('image');
        
        $('#edit_id').val(id);
        $('#edit_nom').val(nom);
        $('#edit_description').val(description);
        $('#edit_prix').val(prix);
        $('#edit_current_image').val(image);
        
        $('#editServiceModal').modal('show');
    });
    
    // Gestion du bouton de suppression
    $('.delete-btn').click(function() {
        var id = $(this).data('id');
        var nom = $(this).data('nom');
        
        $('#delete_id').val(id);
        $('#delete_nom').text(nom);
        
        $('#deleteServiceModal').modal('show');
    });

    // Gestion du changement de statut
    $('.update-status').click(function() {
        var id = $(this).data('id');
        var status = $(this).data('status');
        var button = $(this);
        
        if(confirm('Êtes-vous sûr de vouloir ' + (status == 'confirmee' ? 'confirmer' : 'annuler') + ' cette réservation ?')) {
            $.ajax({
                url: 'update_reservation_status.php',
                type: 'POST',
                data: {
                    id: id,
                    status: status
                },
                success: function(response) {
                    if(response === 'success') {
                        location.reload();
                    } else {
                        alert('Une erreur est survenue lors de la mise à jour du statut.');
                    }
                },
                error: function() {
                    alert('Une erreur est survenue lors de la communication avec le serveur.');
                }
            });
        }
    });
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.slide');
    const thumbnails = document.querySelectorAll('.thumbnail');
    const prevButton = document.querySelector('.nav-button.prev');
    const nextButton = document.querySelector('.nav-button.next');
    let currentSlide = 0;
    let isAnimating = false;

    function showSlide(index) {
        if (isAnimating) return;
        isAnimating = true;

        slides.forEach(slide => {
            slide.classList.remove('active');
            slide.style.zIndex = 0;
        });
        thumbnails.forEach(thumb => thumb.classList.remove('active'));

        const currentSlideElement = slides[currentSlide];
        const nextSlideElement = slides[index];
        
        // Positionnement du nouveau slide
        nextSlideElement.style.zIndex = 2;
        nextSlideElement.classList.add('active');
        thumbnails[index].classList.add('active');

        // Animation terminée
        setTimeout(() => {
            isAnimating = false;
            currentSlide = index;
        }, 1000);
    }

    function nextSlide() {
        const next = (currentSlide + 1) % slides.length;
        showSlide(next);
    }

    function prevSlide() {
        const prev = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(prev);
    }

    // Navigation par boutons
    prevButton.addEventListener('click', prevSlide);
    nextButton.addEventListener('click', nextSlide);

    // Navigation par miniatures
    thumbnails.forEach((thumb, index) => {
        thumb.addEventListener('click', () => {
            if (index !== currentSlide) {
                showSlide(index);
            }
        });
    });

    // Défilement automatique
    let slideInterval = setInterval(nextSlide, 5000);

    // Pause au survol
    document.querySelector('.hero-slider').addEventListener('mouseenter', () => {
        clearInterval(slideInterval);
    });

    document.querySelector('.hero-slider').addEventListener('mouseleave', () => {
        slideInterval = setInterval(nextSlide, 5000);
    });
});
</script>
