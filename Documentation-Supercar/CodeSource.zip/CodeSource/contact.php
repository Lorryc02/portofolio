<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'header.php';
?>
<style>
    .footer {
        background-color: #001f3d;
        color: white;
        padding: 20px 0;
        text-align: center; /* Centrer le texte */
    }

    .footer .social-icons a {
        color: white;
        margin: 0 10px; /* Ajout d'espacement entre les icônes */
        font-size: 20px;
    }

    h1.text-center {
        font-weight: bold; /* Mettre en gras */
        text-transform: uppercase; /* Mettre en majuscule */
    }

    .map-container {
        height: 300px; /* Réduire la hauteur de la carte */
    }
</style>
        <!-- Section de la carte -->
        <div class="col-md-6">
            <h3>Notre emplacement</h3>
            <div class="map-container" style="height: 300px; width: 100%; border: 1px solid #ddd;">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3188.9999999999995!2d57.501222!3d-20.160891!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjDCsDA5JzM4LjIiUyA1N8KwMzAnMDQuNCJF!5e0!3m2!1sfr!2smu!4v1680000000000!5m2!1sfr!2smu" 
                    width="100%" 
                    height="100%" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </div>

        <!-- Section des coordonnées -->
        <div class="col-md-6">
            <h3>Nos coordonnées</h3>
            <ul class="list-unstyled">
                <li><strong>Adresse :</strong> Showroom, Port Louis, Île Maurice</li>
                <li><strong>Téléphone :</strong> +230 59253478 </li>
                <li><strong>Email :</strong> contact@supercar.com</li>
            </ul>
        </div>
    </div>
</div>
<footer class="footer text-center">
    <div class="container">
        <p>&copy; Supercar. Tous droits réservés.</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
    </div>
</footer>

<!-- Lien vers le JavaScript de Bootstrap et FontAwesome -->
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="app.js"></script>
</body>