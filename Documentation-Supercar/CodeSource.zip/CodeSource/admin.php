<?php
session_start();
if ($_SESSION['role'] != 'admin') {
    header("Location: login.php"); // Si l'utilisateur n'est pas admin, rediriger vers la page de connexion
    exit();
}

// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Récupérer les demandes d'essai
$query = "SELECT * FROM demandes_essai";
$result = $mysqli->query($query);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Demandes d'Essai</title>
</head>
<body>
    <h1>Demandes d'Essai</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Utilisateur</th>
                <th>Marque</th>
                <th>Modèle</th>
                <th>Date</th>
                <th>Heure</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['utilisateur_id']; ?></td>
                    <td><?php echo $row['marque']; ?></td>
                    <td><?php echo $row['modele']; ?></td>
                    <td><?php echo $row['date']; ?></td>
                    <td><?php echo $row['heure']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
