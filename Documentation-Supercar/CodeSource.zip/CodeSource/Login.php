<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Traitement du formulaire de connexion
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Préparer la requête pour éviter les injections SQL
    $query = "SELECT id, nom, prenom, email, mot_de_passe, role FROM users WHERE email = ?";
    $stmt = $mysqli->prepare($query);
    
    if ($stmt === false) {
        $error = "Erreur de préparation de la requête : " . $mysqli->error;
    } else {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            // Vérifier le mot de passe
            if (password_verify($password, $user['mot_de_passe'])) {
                // Connexion réussie
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nom'] = $user['nom'];
                $_SESSION['user_prenom'] = $user['prenom'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                
                // Rediriger vers le dashboard si admin
                if ($user['role'] === 'admin') {
                    header("Location: dashboard.php");
                } else {
                    // Si on vient de la page demande-essai et qu'on a des paramètres sauvegardés
                    if (isset($_SESSION['redirect_after_login']) && $_SESSION['redirect_after_login'] === 'demande-essai.php' && isset($_SESSION['essai_params'])) {
                        $params = http_build_query($_SESSION['essai_params']);
                        header("Location: demande-essai.php?" . $params);
                    } else {
                        // Sinon, redirection normale
                        $redirect = isset($_SESSION['redirect_after_login']) ? $_SESSION['redirect_after_login'] : 'index.php';
                        header("Location: " . $redirect);
                    }
                }
                exit();
            } else {
                $error = "Mot de passe incorrect.";
            }
        } else {
            $error = "Email non trouvé.";
        }
        $stmt->close();
    }
}

// Inclure le header
include 'header.php';
?>

<style>
    body {
        background-image: url('Image/bg-con.webp');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        font-family: 'Lato', sans-serif;
    }

    .login-container {
        max-width: 400px;
        margin: 50px auto;
        padding: 30px;
        background-color: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        margin-bottom: 100px;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .login-title, label {
        color: white;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
    }

    .login-title {
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        text-align: center;
        margin-bottom: 30px;
    }

    .form-control {
        border-radius: 20px;
        padding: 12px 20px;
        margin-bottom: 20px;
        border: 2px solid #e9ecef;
    }

    .form-control:focus {
        border-color: #d4af37;
        box-shadow: none;
    }

    .btn-login {
        background-color: #d4af37;
        color: white;
        border: none;
        border-radius: 20px;
        padding: 12px 30px;
        width: 100%;
        font-weight: 600;
        text-transform: uppercase;
        transition: background-color 0.3s ease;
    }

    .btn-login:hover {
        background-color: #8b0000;
        color: white;
    }

    .register-link {
        text-align: center;
        margin-top: 20px;
    }

    .register-link a {
        color: #d4af37;
        text-decoration: none;
    }

    .register-link a:hover {
        color: #8b0000;
    }

    .error-message {
        color: #dc3545;
        text-align: center;
        margin-bottom: 20px;
    }

    .success-message {
        color: #28a745;
        text-align: center;
        margin-bottom: 20px;
    }

    .footer {
        background-color: #001f3d;
        color: white;
        padding: 20px 0;
        position: fixed;
        bottom: 0;
        width: 100%;
        z-index: 1000;
    }

    .footer .social-icons a {
        color: white;
        margin-right: 10px;
        font-size: 20px;
    }
</style>

<!-- Formulaire de connexion -->
<div class="container">
    <div class="login-container">
        <h2 class="login-title">Connexion</h2>
        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="form-group">
                <label>Mot de passe</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <button type="submit" class="btn btn-login">Se connecter</button>
        </form>
        <div class="register-link">
            <p>Pas encore de compte ? <a href="inscription.php">Inscrivez-vous</a></p>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="footer text-center">
    <div class="container">
        <p>&copy; Supercar. Tous droits réservés.</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
