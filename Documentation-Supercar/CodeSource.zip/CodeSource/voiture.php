<?php
session_start();

// Connexion à la base de données
$mysqli = new mysqli("localhost", "root", "", "vehicules");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Inclure le header
include 'header.php';
?>

<style>
    body {
        background-color: #f8f9fa;
        font-family: 'Lato', sans-serif;
    }

    .car-container {
        max-width: 1200px;
        margin: 50px auto;
        padding: 30px;
        background-color: white;
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 100px;
    }

    .car-title {
        color: #001f3d;
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        text-align: center;
        margin-bottom: 30px;
    }

    .car-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        padding: 20px;
    }

    .car-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
    }

    .car-card:hover {
        transform: translateY(-5px);
    }

    .car-image {
        width: 100%;
        height: 200px;
        object-fit: cover;
    }

    .car-info {
        padding: 20px;
    }

    .car-brand {
        color: #001f3d;
        font-family: 'Montserrat', sans-serif;
        font-weight: 600;
        margin-bottom: 10px;
    }

    .car-model {
        color: #666;
        font-size: 1.1em;
        margin-bottom: 15px;
    }

    .car-price {
        color: #d4af37;
        font-weight: 600;
        font-size: 1.2em;
        margin-bottom: 15px;
    }

    .car-type {
        color: #666;
        font-size: 0.9em;
        margin-bottom: 15px;
    }

    .btn-primary {
        background-color: #d4af37;
        border: none;
        border-radius: 20px;
        padding: 10px 20px;
        color: white;
        font-weight: 600;
        transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #8b0000;
        color: white;
    }

    .filters {
        margin-bottom: 30px;
        padding: 20px;
        background-color: white;
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .filter-group {
        margin-bottom: 15px;
    }

    .filter-label {
        display: block;
        margin-bottom: 5px;
        color: #001f3d;
        font-weight: 600;
    }

    .filter-input {
        width: 100%;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    .footer {
        background-color: #001f3d;
        color: white;
        padding: 20px 0;
        position: fixed;
        bottom: 0;
        width: 100%;
        z-index: 1000;
    }

    .footer .social-icons a {
        color: white;
        margin-right: 10px;
        font-size: 20px;
    }
</style>

<!-- Filtres -->
<div class="container">
    <div class="filters">
        <div class="row">
            <div class="col-md-4">
                <div class="filter-group">
                    <label class="filter-label">Marque</label>
                    <select class="filter-input" id="brandFilter">
                        <option value="">Tous</option>
                        <option value="BMW">BMW</option>
                        <option value="Porsche">Porsche</option>
                        <option value="Mercedes">Mercedes</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="filter-group">
                    <label class="filter-label">Prix maximum</label>
                    <input type="number" class="filter-input" id="priceFilter" placeholder="Prix maximum">
                </div>
            </div>
            <div class="col-md-4">
                <div class="filter-group">
                    <label class="filter-label">Type</label>
                    <select class="filter-input" id="typeFilter">
                        <option value="">Tous</option>
                        <option value="Berline">Berline</option>
                        <option value="SUV">SUV</option>
                        <option value="Sport">Sport</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-12 text-center">
                <button class="btn btn-primary" onclick="showFilteredCars()">Rechercher</button>
            </div>
        </div>
    </div>
</div>

<!-- Liste des voitures -->
<div class="container">
    <div class="car-container">
        <h2 class="car-title">Nos Véhicules</h2>
        <div class="car-grid" id="carGrid">
            <!-- Les voitures seront affichées ici via JavaScript -->
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="footer text-center">
    <div class="container">
        <p>&copy; Supercar. Tous droits réservés.</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
    </div>
</footer>

<script>
// Données des voitures
const carModels = {
    BMW: [
        {
            name: "BMW M3",
            type: "Berline",
            price: 85000,
            image: "image/bmw-m3.jpg"
        },
        {
            name: "BMW X5",
            type: "SUV",
            price: 95000,
            image: "image/bmw-x5.jpg"
        }
    ],
    Porsche: [
        {
            name: "Porsche 911",
            type: "Sport",
            price: 120000,
            image: "image/porsche-911.jpg"
        },
        {
            name: "Porsche Cayenne",
            type: "SUV",
            price: 110000,
            image: "image/porsche-cayenne.jpg"
        }
    ],
    Mercedes: [
        {
            name: "Mercedes Classe S",
            type: "Berline",
            price: 100000,
            image: "image/mercedes-s.jpg"
        },
        {
            name: "Mercedes GLE",
            type: "SUV",
            price: 90000,
            image: "image/mercedes-gle.jpg"
        }
    ]
};

// Fonction pour afficher les voitures filtrées
function showFilteredCars() {
    const brandFilter = document.getElementById('brandFilter').value;
    const priceFilter = document.getElementById('priceFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    const carGrid = document.getElementById('carGrid');
    carGrid.innerHTML = '';

    let allCars = [];
    if (brandFilter) {
        allCars = carModels[brandFilter] || [];
    } else {
        Object.values(carModels).forEach(cars => {
            allCars = allCars.concat(cars);
        });
    }

    allCars = allCars.filter(car => {
        const priceMatch = !priceFilter || car.price <= parseFloat(priceFilter);
        const typeMatch = !typeFilter || car.type === typeFilter;
        return priceMatch && typeMatch;
    });

    allCars.forEach(car => {
        const carCard = document.createElement('div');
        carCard.className = 'car-card';
        carCard.innerHTML = `
            <img src="${car.image}" alt="${car.name}" class="car-image">
            <div class="car-info">
                <h3 class="car-brand">${car.name}</h3>
                <p class="car-type">${car.type}</p>
                <p class="car-price">${car.price.toLocaleString()} €</p>
                <a href="demande-essai.php?marque=${encodeURIComponent(car.name.split(' ')[0])}&modele=${encodeURIComponent(car.name)}&type=${encodeURIComponent(car.type)}" class="btn btn-primary">Réserver un essai</a>
            </div>
        `;
        carGrid.appendChild(carCard);
    });
}

// Ajouter des écouteurs d'événements pour les filtres
document.getElementById('brandFilter').addEventListener('change', showFilteredCars);
document.getElementById('priceFilter').addEventListener('input', showFilteredCars);
document.getElementById('typeFilter').addEventListener('change', showFilteredCars);

// Afficher toutes les voitures au chargement de la page
showFilteredCars();
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
